"""Five static placement policies over the 3-stage chain, one frozen cost table per regime (stdlib only).

Cost table (measured in the calibration phase, frozen before any evaluation request):
  proc[(stage, host)]      closed-loop stage processing time (worker receipt worker_wall_ms, no queue; warm-up excluded)
  link[(src, dst, edge)]   median application-path probe RTT: src POSTs the EXACT task payload of that edge from its own
                           network position to a sink on dst over the regime's route and receives a small sink reply.
                           HTTP/relay overhead is included: an application path cost, never a pure network time. Same-host
                           pairs are probed (local HTTP loopback), never assumed zero.
  edges: 0 S->T1 raw NPY, 1 T1->T2 PNG (bytes of T1's host), 2 T2->T3 VLM JSON (bytes of T2's backend).
Return path: the executed chain is nested synchronous RPC, so the final answer travels back T3 -> T2 host -> T1 host -> S
as the replies of the open hops. Each hop's probe RTT already contains that hop's reverse leg with a small reply; the extra
reply bytes (final JSON + slim receipts, a few KB) are NOT separately modeled (small-response approximation). There is no
direct T3 -> S transfer in the model or in the execution.
Policies (generic baselines; exact enumeration of 8 placements is a baseline, not a new algorithm):
  static_gpu GGG | static_npu NNN | task_fastest: per stage min proc (transfers ignored) |
  network_greedy: stage by stage min(incoming hop RTT from the previous choice + proc); at T3 the hop RTT carries the
                  terminal reply leg T3 -> T2 host (earlier reverse legs are fixed by earlier choices) |
  dag: min over all 8 of RTT(S->T1) + T1 + RTT(T1->T2) + T2 + RTT(T2->T3) + T3.
Ties: hosts in chain_design.HOSTS order (G before N); dag ties by placement string. Predicted costs are selection inputs,
never results.
"""
import time

import chain_design as D


class PolicyError(RuntimeError):
    pass


def parts(table, placement):
    """Per-leg predicted costs of one placement: [(name, ms)] in execution order."""
    a, b, c = placement
    try:
        return [('S->T1', table['link'][(D.ORIGIN, a, 0)]), ('T1', table['proc'][('image_pack', a)]),
                ('T1->T2', table['link'][(a, b, 1)]), ('T2', table['proc'][('vlm', b)]),
                ('T2->T3', table['link'][(b, c, 2)]), ('T3', table['proc'][('result_format', c)])]
    except KeyError as error:
        raise PolicyError(f'cost table lacks {error.args[0]!r} for {placement}') from None


def total(table, placement):
    return sum(ms for _, ms in parts(table, placement))


def _argmin(options):
    """options: [(score, host)] in HOSTS order; the first minimum wins (deterministic tie)."""
    best = min(score for score, _ in options)
    return next(h for score, h in options if score == best)


def select(policy, table):
    proc, link = table['proc'], table['link']
    if policy == 'static_gpu':
        return 'GGG'
    if policy == 'static_npu':
        return 'NNN'
    if policy == 'task_fastest':
        return ''.join(_argmin([(proc[(stage, h)], h) for h in D.HOSTS]) for stage in D.STAGES)
    if policy == 'network_greedy':
        a = _argmin([(link[(D.ORIGIN, h, 0)] + proc[('image_pack', h)], h) for h in D.HOSTS])
        b = _argmin([(link[(a, h, 1)] + proc[('vlm', h)], h) for h in D.HOSTS])
        c = _argmin([(link[(b, h, 2)] + proc[('result_format', h)], h) for h in D.HOSTS])
        return a + b + c
    if policy == 'dag':
        return min(D.PLACEMENTS, key=lambda p: (total(table, p), p))
    raise PolicyError(f'unknown policy {policy!r}')


def decide(table):
    """Every policy's frozen choice for one table, with the predicted total of every placement and selection times."""
    started = time.perf_counter()
    choices = {}
    for policy in D.POLICIES:
        t0 = time.perf_counter()
        placement = select(policy, table)
        choices[policy] = dict(placement=placement, predicted_ms=total(table, placement), selection_ms=(time.perf_counter()-t0)*1000)
    return dict(choices=choices, predicted_ms={p: total(table, p) for p in D.PLACEMENTS},
                parts={p: parts(table, p) for p in D.PLACEMENTS}, decide_ms=(time.perf_counter()-started)*1000)


def aliases(decision):
    """{placement: [policy labels]}: one executed plan per distinct placement (alias labels share one observation)."""
    out = {}
    for policy, choice in decision['choices'].items():
        out.setdefault(choice['placement'], []).append(policy)
    return {p: sorted(labels) for p, labels in out.items()}


def required_probes(sizes):
    """sizes = {'npy': n, 'png': {G: n, N: n}, 'vlm': {G: n, N: n}} (measured task payload bytes) -> the 10 probes that
    cover every link key any of the 8 placements reads: [dict(src, dst, edge, kind, bytes)]."""
    out = [dict(src=D.ORIGIN, dst=h, edge=0, kind='npy', bytes=int(sizes['npy'])) for h in D.HOSTS]
    for edge, kind in ((1, 'png'), (2, 'vlm')):
        for src in D.HOSTS:
            for dst in D.HOSTS:
                out.append(dict(src=src, dst=dst, edge=edge, kind=kind, bytes=int(sizes[kind][src])))
    return out


def table_from(proc, probes):
    """proc {(stage, host): ms}; probes [dict(src, dst, edge, median_ms)] -> cost table (tuple keys)."""
    return dict(proc=dict(proc), link={(p['src'], p['dst'], p['edge']): float(p['median_ms']) for p in probes})


def table_to_json(table):
    return dict(proc={f'{s}@{h}': v for (s, h), v in table['proc'].items()},
                link={f'{a}->{b}#{e}': v for (a, b, e), v in table['link'].items()})
