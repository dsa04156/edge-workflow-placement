"""Frozen design of the simple GPU/Mobilint three-stage placement comparison (stdlib only; collector, analyzer, tests).

Real DAG (a chain; one request = the frozen input image + its frozen question):
  source S (edge dev0003) -raw NPY-> T1 image_pack -lossless PNG-> T2 vlm -VLM JSON-> T3 result_format -final JSON-> S
Hosts: G = ser0003 GB10 server GPU (Qwen3-VL-2B-Instruct BF16 on CUDA), N = ser0004 (vendor W4V8 MXQ Qwen3-VL-2B on Mobilint ARIES).
Staged native-only variant (2026-10-29): both hosts are servers (zone cloud), the source dev0003 is edge; only the native
regime runs, one request per unique placement (1 block x 1 repeat); no relay/shaped regime and no shared-link claim.
T1/T3 are host-CPU support stages (Pillow/numpy, json) on G or N; only T2 runs neural inference (CUDA or Mobilint, never CPU).
Different precisions (BF16 vs W4V8): no same-precision or quality-equivalence claim; quality is not evaluated here.

Simple topology with repeated evidence (user 2026-10-29): one process block (one fresh G Pod + one fresh N Pod), one input,
three regimes, sequential single requests (source in-flight 1). Calibration/qualification first; then plans and the whole
schedule are frozen; evaluation runs MEASUREMENT_BLOCKS temporal blocks, each with REPEAT_COUNT sequential requests per
unique selected placement per regime (8 x 8 = 64 observations per placement/regime by default). The same warm model
processes serve every block: temporal blocks on the same devices, never independent process/hardware repetitions.

Zones are logical: S and G 'edge', N 'cloud'. Same-zone hops are direct Pod-IP HTTP. In the relay regimes every cross-zone
hop goes through the one owned gateway Pod; 'shaped2' applies the unchanged real-topology-live net_control.py: one 2 Mbit/s
tbf toward cloud peers and a separate one toward edge peers on the gateway's egress (a shared PER-DIRECTION gateway
bottleneck; never a combined bidirectional cap, never a measured physical topology).
"""
import hashlib
import itertools
import json
import random

EXPERIMENT = 'gpu-mobilint-placement'
SEED = 20261029
STAGES = ('image_pack', 'vlm', 'result_format')
SUPPORT_STAGES = ('image_pack', 'result_format')
HOSTS = ('G', 'N')                       # deterministic tie order everywhere: G before N
ORIGIN = 'S'
ARM = {'G': 'cuda', 'N': 'mobilint'}     # gpu-mobilint-vlm protocol.ARMS keys
ZONE = {'S': 'edge', 'G': 'cloud', 'N': 'cloud'}
ORIGIN_NODE = 'etri-dev0003-raspi5'
PRECISION = {'G': 'Qwen/Qwen3-VL-2B-Instruct@89644892 BF16 on cuda:0 (torch)',
             'N': 'mobilint/Qwen3-VL-2B-Instruct@f4be563 W4V8 MXQ (vision+text) on ARIES via qbruntime'}
PLACEMENTS = tuple(''.join(p) for p in itertools.product(HOSTS, repeat=3))  # GGG, GGN, ..., NNN (all legal)

INPUT = 'cal-3733440'                     # 426x640 RGB uint8, raw NPY 818048 B
ALL_INPUTS = ('smoke-1713820', 'cal-3733440', 'cal-4556100', 'cal-3355890')  # all pass the in-Pod T1 roundtrip check

REGIMES = ('native',)                    # staged variant: relay/shaped2 stay defined below but are never scheduled
NETWORK = {
    'native': dict(relay=False, net=None, label='native direct Pod-IP routes (no gateway)'),
    'relay': dict(relay=True, net=dict(action='shape', mbps=None, delay_ms=0), label='unshaped relay control (gateway, no qdisc)'),
    'shaped2': dict(relay=True, net=dict(action='shape', mbps=2, delay_ms=0),
                    label='shared 2 Mbit/s per-direction gateway egress (net_control cloud band / edge band)'),
}
SLO_S = 5.0          # diagnostic SLO (deadline_met)
TIMEOUT_S = 40.0     # absolute request cancel budget from the scheduled arrival
MAX_INFLIGHT = 1     # sequential requests
REPEAT_COUNT = 1     # sequential requests per unique placement per regime per measurement block (release-bound)
MEASUREMENT_BLOCKS = 1  # temporal blocks over all regimes inside the same Pods (release-bound)
# No predeclared significance comparison in the native-only single-observation variant (descriptive only).
PRIMARY = None
SECONDARY = None

POLICIES = ('static_gpu', 'static_npu', 'task_fastest', 'network_greedy', 'dag')

BUDGETS = dict(
    campaign_s=30 * 60 + 900,    # whole run wall budget (30 min work + cleanup reserve); every Pod lifetime derives from it
    cleanup_reserve_s=900,       # kept at the end of the budget for UID-owned cleanup and verification
    helper_ready_s=300,          # gateway/generator readiness
    upload_s=1800,
    control_timeout_s=30,
    control_max_body_bytes=16 * 1024 * 1024,
    corpus_s=300,
    profile_warmup=1,            # warm qualification call per (stage, host, variant), kept and labelled, never a cost
    profile_reps=1,              # measured profile calls per (stage, host, variant)
    profile_job_s=1800,
    stage_call_s=320,            # one profiling call (VlmStage call deadline 300 s + margin)
    probe_reps=1,
    probe_timeout_s=60,
    probe_job_s=900,
    two_flow_bytes=262144,       # bounded concurrent two-flow probe, both flows toward N (cloud band)
    two_flow_reps=2,
    drain_s=90,                  # drain barrier before every request / regime change; failure aborts the run
    settle_s=2,
    poll_s=1,
    trace_slack_s=30,
    dag_max_active=96,           # worker HTTP admission (existing nested-forwarding baseline)
    gateway_upstream_cap_s=60,
    gateway_slots=96,
    net_exec_s=60,
)


def regime_orders(measurement_blocks):
    """Counterbalanced regime order per measurement block: the 6 permutations in a seeded order, reused cyclically."""
    perms = list(itertools.permutations(REGIMES))
    random.Random(f'{SEED}-regime-orders').shuffle(perms)
    return [list(perms[(m - 1) % len(perms)]) for m in range(1, measurement_blocks + 1)]


def cells(choices, repeat_count=REPEAT_COUNT, measurement_blocks=MEASUREMENT_BLOCKS):
    """choices[regime] = {placement: [policy labels]} (chain_policy.aliases of that regime's frozen table). The complete
    frozen evaluation schedule: one request per cell. Per measurement block the regimes follow regime_orders(); inside a
    regime the unique placements follow a seeded shuffle (SEED, block, regime) and the REPEAT_COUNT requests interleave
    round-robin over them. Aliases ride as labels of the same observation. Nothing here depends on any result."""
    out = []
    for m, order in enumerate(regime_orders(measurement_blocks), 1):
        for regime in order:
            unique = sorted(choices[regime].items())
            random.Random(f'{SEED}-{m}-{regime}').shuffle(unique)
            for r in range(1, repeat_count + 1):
                for placement, labels in unique:
                    out.append(dict(measurement_block=m, repeat=r, regime=regime, input_id=INPUT, placement=placement,
                                    policies=sorted(labels), arrivals=[dict(index=0, offset_s=0.0)]))
    for n, cell in enumerate(out):
        cell['label'] = f"c{n:04d}-m{cell['measurement_block']}-{cell['regime']}-{cell['placement']}-r{cell['repeat']}"
    return out


def design_dict(repeat_count=REPEAT_COUNT, measurement_blocks=MEASUREMENT_BLOCKS):
    """Everything the release binds besides code/assets: the conditions fixed before any result."""
    return dict(experiment=EXPERIMENT, seed=SEED, stages=STAGES, support_stages=SUPPORT_STAGES, hosts=HOSTS, arm=ARM, zone=ZONE,
                origin_node=ORIGIN_NODE, precision=PRECISION, placements=PLACEMENTS, input=INPUT, all_inputs=ALL_INPUTS,
                regimes=REGIMES, network=NETWORK, slo_s=SLO_S, timeout_s=TIMEOUT_S, max_inflight=MAX_INFLIGHT, policies=POLICIES,
                primary=PRIMARY, secondary=SECONDARY, budgets=BUDGETS, process_blocks=1, repeat_count=repeat_count, measurement_blocks=measurement_blocks)


def design_sha256(**kw):
    return hashlib.sha256(json.dumps(design_dict(**kw), sort_keys=True).encode()).hexdigest()
