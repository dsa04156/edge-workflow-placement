"""Staged GB10/Mobilint native-only variant (no cluster): non-prepared release/plan/preflight without any PVC or dev0009
access, CUDA RuntimeClass on ser0003, Mobilint/cache/gateway on ser0004, source dev0003, native single-observation schedule
with same-placement sharing, rebound frozen contract/manifest, existing pyroute2 wheel.

Run (this directory):
  .scratch/gpu-mobilint-vlm-20261028/env/mblt-x86/bin/python -m unittest -v test_staged_native
"""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import chain_live as L  # first: puts the staged sibling experiments on sys.path
import chain_design as D  # noqa: E402
import chain_generator as CG  # noqa: E402
import chain_policy as CP
from test_chain import NATIVE

SER3, SER4, DEV3 = 'etri-ser0003-cg0ms0', 'etri-ser0004-cgnms0', 'etri-dev0003-raspi5'
ORIGINAL_FROZEN = L.REPO/'.scratch/gpu-mobilint-vlm-20261028/developer-frozen-r1'


def plan_items():
    out = io.StringIO()
    with mock.patch.object(L.G, 'load_prepared', side_effect=AssertionError('prepared')), \
            mock.patch.object(L.collect.Session, 'call', side_effect=AssertionError('kubectl')), contextlib.redirect_stdout(out):
        L.main(['--plan'])
    return out.getvalue(), {i['metadata']['name']: i for i in json.loads(out.getvalue())['manifests']}


def node_of(pod):
    return pod['spec']['affinity']['nodeAffinity']['requiredDuringSchedulingIgnoredDuringExecution']['nodeSelectorTerms'][0]['matchFields'][0]['values']


class Topology(unittest.TestCase):
    def test_nodes_and_zones(self):
        self.assertEqual((L.P.SERVER, L.P.JETSON, D.ORIGIN_NODE), (SER4, SER3, DEV3))
        self.assertEqual((L.P.ARMS['cuda']['node'], L.P.ARMS['mobilint']['node']), (SER3, SER4))
        self.assertEqual(L.NODE, dict(cache=SER4, gateway=SER4, mobilint=SER4, cuda=SER3, generator=DEV3))
        self.assertEqual(D.ZONE, dict(S='edge', G='cloud', N='cloud'))
        self.assertEqual(CG.ZONE, D.ZONE)

    def test_frozen_contract_rebound_and_manifest_consistent(self):
        frozen = L.DEFAULTS['frozen']
        contract = json.loads((frozen/'contract.json').read_text())
        self.assertEqual({a: contract['arms'][a]['node'] for a in ('cuda', 'mobilint')}, dict(cuda=SER3, mobilint=SER4))
        old = json.loads((ORIGINAL_FROZEN/'contract.json').read_text())
        old['arms']['cuda']['node'] = SER3
        self.assertEqual(contract, old)  # only the CUDA node is rebound
        manifest = json.loads((frozen/'assets-manifest.json').read_text())
        entry = next(f for f in manifest['files'] if f['path'] == 'contract.json')
        sha = L.P.file_sha(frozen/'contract.json')
        self.assertEqual((entry['sha256'], manifest['contract_sha256'], entry['bytes']), (sha, sha, (frozen/'contract.json').stat().st_size))
        original = json.loads((ORIGINAL_FROZEN/'assets-manifest.json').read_text())
        strip = lambda m: [{k: v for k, v in f.items() if k != 'source'} for f in m['files'] if f['path'] != 'contract.json']
        self.assertEqual(strip(manifest), strip(original))  # every model/wheel entry unchanged (size, sha, path, group)
        self.assertEqual([{k: v for k, v in i.items() if k != 'source'} for i in manifest['inputs']],
                         [{k: v for k, v in i.items() if k != 'source'} for i in original['inputs']])
        self.assertTrue(all(Path(f['source']).is_absolute() for f in manifest['files'] + manifest['inputs']))
        self.assertTrue(all(Path(i['source']).is_file() for i in manifest['inputs']))

    def test_pyroute2_is_the_existing_repository_wheel(self):
        self.assertTrue(L.PYROUTE2.is_file())
        self.assertEqual(L.P.file_sha(L.PYROUTE2), L.PYROUTE2_SHA256)


class UnpreparedPlan(unittest.TestCase):
    def test_gpu_only_ser0003_npu_only_ser0004_no_pvc_no_dev0009(self):
        raw, items = plan_items()
        pods = [i for i in items.values() if i['kind'] == 'Pod']
        objects = json.dumps([json.loads(raw)['design'], pods])  # the code ConfigMap only carries source comments naming dev0009
        self.assertNotIn('dev0009', objects)
        self.assertNotIn('persistentVolumeClaim', objects)
        self.assertNotIn('PREPARED_', objects)
        gpu = [p['metadata']['name'] for p in pods for c in p['spec']['containers'] if any('nvidia.com' in r for r in c['resources'].get('limits', {}))]
        npu = [p['metadata']['name'] for p in pods for c in p['spec']['containers'] if any('mobilint.com' in r for r in c['resources'].get('limits', {}))]
        self.assertEqual((gpu, npu), (['gmp-plan-cuda'], ['gmp-plan-mobilint']))
        cuda, npu_pod = items['gmp-plan-cuda'], items['gmp-plan-mobilint']
        self.assertEqual((node_of(cuda), node_of(npu_pod)), ([SER3], [SER4]))
        self.assertEqual(cuda['spec']['runtimeClassName'], 'nvidia-spark')
        self.assertNotIn('runtimeClassName', npu_pod['spec'])
        res = cuda['spec']['containers'][0]['resources']
        self.assertEqual((res['requests']['nvidia.com/gpu'], res['limits']['nvidia.com/gpu']), ('1', '1'))
        self.assertEqual((res['requests']['cpu'], res['requests']['memory'], res['limits']['memory']), ('4', '8Gi', '12Gi'))
        self.assertEqual(cuda['spec']['containers'][0]['command'], ['python3', '-u', '/config/vlm_bootstrap.py'])
        self.assertEqual(npu_pod['spec']['containers'][0]['command'], ['python3', '-u', '/config/bootstrap.py'])
        env = {e['name']: e.get('value') for e in cuda['spec']['containers'][0]['env']}
        self.assertEqual(env['RECIPE'], 'cu130-aarch64-cp311')
        self.assertEqual((node_of(items['gmp-plan-cache']), node_of(items['gmp-plan-gateway']), node_of(items['gmp-plan-generator'])),
                         ([SER4], [SER4], [DEV3]))
        self.assertTrue(all(p['spec']['activeDeadlineSeconds'] == D.BUDGETS['campaign_s'] for p in pods))
        self.assertEqual(D.BUDGETS['campaign_s'], 30 * 60 + D.BUDGETS['cleanup_reserve_s'])

    def test_prepared_flags_must_come_together(self):
        for argv in (['--plan', '--prepared', 'x'], ['--plan', '--cuda-cache-pvc', 'y'], ['--plan', '--io-profile', 'sd-adaptive-v1']):
            with self.assertRaisesRegex(SystemExit, 'go together'):
                L.main(argv)


class UnpreparedRelease(unittest.TestCase):
    def test_release_binds_no_prepared_state_and_dry_run_passes_without_kubectl(self):
        draft = L.release_draft(L.DEFAULTS['frozen'], None, D.REPEAT_COUNT, D.MEASUREMENT_BLOCKS)
        self.assertEqual((draft['prepared'], draft['cuda_cache_pvc'], draft['prepared_deadlines'], draft['io_profile']), (None,) * 4)
        self.assertEqual((draft['design']['regimes'], draft['design']['repeat_count'], draft['design']['measurement_blocks']), (['native'], 1, 1))
        self.assertEqual((draft['design']['primary'], draft['design']['secondary']), (None, None))
        self.assertFalse(any('.scratch' in k for k in draft['code']))
        self.assertIn('experiments/gpu-mobilint-vlm/vlm_bootstrap.py', draft['code'])
        tmp = Path(tempfile.mkdtemp())
        (tmp/'release.json').write_text(json.dumps(dict(draft, approved_by='coordinator-test')))
        kubectl = mock.Mock(side_effect=AssertionError('kubectl must not run'))
        out = io.StringIO()
        with mock.patch.object(L.collect.Session, 'call', kubectl), mock.patch.object(L.G, 'load_prepared', side_effect=AssertionError('prepared')), \
                contextlib.redirect_stdout(out):
            L.main(['--dry-run', '--release', str(tmp/'release.json')])
        kubectl.assert_not_called()
        self.assertEqual(json.loads(out.getvalue())['release'], 'ok')
        prepared_release = dict(draft, approved_by='x', prepared={'manifest_sha256': 'p'})
        self.assertIn('prepared differs from the release', L.release_problems(prepared_release, draft))

    def test_release_binds_dynamically_loaded_vlm_live_and_rejects_a_stale_one(self):
        live = L.GMV/'live.py'
        self.assertEqual(Path(L.G.__file__).resolve(), live.resolve())
        draft = L.release_draft(L.DEFAULTS['frozen'], None, D.REPEAT_COUNT, D.MEASUREMENT_BLOCKS)
        self.assertEqual(draft['code']['experiments/gpu-mobilint-vlm/live.py'], L.P.file_sha(live))
        release = dict(draft, approved_by='coordinator-test')
        self.assertEqual(L.release_problems(release, draft), [])
        real_sha = L.P.file_sha  # simulate an edited live.py without touching the staged file
        changed = lambda p: '0' * 64 if Path(p).resolve() == live.resolve() else real_sha(p)
        with mock.patch.object(L.P, 'file_sha', side_effect=changed):
            fresh = L.release_draft(L.DEFAULTS['frozen'], None, D.REPEAT_COUNT, D.MEASUREMENT_BLOCKS)
        self.assertEqual(fresh['code']['experiments/gpu-mobilint-vlm/live.py'], '0' * 64)
        self.assertEqual(L.release_problems(release, fresh), ['code differs from the release'])


class UnpreparedPreflight(unittest.TestCase):
    def test_preflight_reads_no_pvc_and_checks_ser0003_gpu_ser0004_npu(self):
        s = L.Session(tempfile.mkdtemp(), 'gmp-pre')
        ready = [dict(type='Ready', status='True')]
        nodes = [dict(metadata=dict(name=n), spec={}, status=dict(conditions=ready, allocatable={r: '1'} if r else {}))
                 for n, r in ((SER3, 'nvidia.com/gpu'), (SER4, 'mobilint.com/npu'), (DEV3, None))]
        verbs = []

        def kubectl(stem, args, stdin=None, timeout=60):
            verbs.append(args[:2])
            if args[:2] == ['get', 'nodes']:
                return json.dumps(dict(items=nodes))
            if args[:3] == ['get', 'pods', '-A']:
                return json.dumps(dict(items=[]))
            raise AssertionError(f'unexpected kubectl {args}')
        run = L.Run(s, L.DEFAULTS['frozen'], None, dict(design=dict(repeat_count=1, measurement_blocks=1)), http=mock.Mock())
        with mock.patch.object(s, 'call', side_effect=kubectl), mock.patch.object(L.collect, 'protected_snapshot'), \
                mock.patch.object(L.prepare, 'verify_manifest', return_value=[]):
            run.preflight()
        self.assertEqual(verbs, [['get', 'nodes'], ['get', 'pods']])
        saved = json.loads((s.out/'preflight.json').read_text())
        self.assertEqual((saved['problems'], saved['prepared'], saved['pvc_uid']), ([], False, None))
        nodes[0]['status']['allocatable'] = {}
        s2 = L.Session(tempfile.mkdtemp(), 'gmp-pre2')
        run.s = s2
        with mock.patch.object(s2, 'call', side_effect=kubectl), mock.patch.object(L.collect, 'protected_snapshot'), \
                mock.patch.object(L.prepare, 'verify_manifest', return_value=[]):
            with self.assertRaisesRegex(RuntimeError, f'{SER3}: no allocatable nvidia.com/gpu'):
                run.preflight()

    def test_cache_bundle_has_no_prepared_entries(self):
        self.assertEqual(L.G.bundle_groups(None, None), {'common', 'mobilint-x86_64-cp311', 'cu130-aarch64-cp311'})
        run = L.Run(L.Session(tempfile.mkdtemp(), 'gmp-id'), L.DEFAULTS['frozen'], None, dict(design={}), http=mock.Mock())
        run.health = {'G': {}}
        self.assertFalse(run.prepared and L.G.prepared_event_problem(run.health['G'], run.prepared))


class NativeSchedule(unittest.TestCase):
    def test_one_request_per_unique_placement_aliases_share(self):
        self.assertEqual(D.REGIMES, ('native',))
        choices = {'native': CP.aliases(CP.decide(NATIVE))}  # GGG static_gpu, NNN dag/static_npu/task_fastest, GNN network_greedy
        cells = D.cells(choices, D.REPEAT_COUNT, D.MEASUREMENT_BLOCKS)
        self.assertEqual(len(cells), 3)
        self.assertEqual({c['placement']: c['policies'] for c in cells}, choices['native'])
        self.assertTrue(all(c['regime'] == 'native' and c['measurement_block'] == 1 and c['repeat'] == 1 for c in cells))
        self.assertEqual(sorted(p for c in cells for p in c['policies']), sorted(D.POLICIES))
        self.assertEqual(D.BUDGETS['probe_reps'], 1)
        self.assertEqual((D.BUDGETS['profile_warmup'], D.BUDGETS['profile_reps']), (1, 1))

    def test_native_network_spec_follows_zones_and_no_two_flow(self):
        run = L.Run(L.Session(tempfile.mkdtemp(), 'gmp-net'), L.DEFAULTS['frozen'], None, dict(design={}), http=mock.Mock())
        run.ips = {'S': '10.0.0.1', 'G': '10.0.0.2', 'N': '10.0.0.3'}
        with mock.patch.object(run, 'drain'), mock.patch.object(L.Session, 'net', return_value={}) as net:
            run.apply_network('native')
        spec = net.call_args[0][0]
        self.assertEqual((spec['cloud'], spec['edge'], spec['mbps']), (['10.0.0.2', '10.0.0.3'], ['10.0.0.1'], None))
        self.assertFalse(D.NETWORK['native']['relay'])


if __name__ == '__main__':
    unittest.main()
