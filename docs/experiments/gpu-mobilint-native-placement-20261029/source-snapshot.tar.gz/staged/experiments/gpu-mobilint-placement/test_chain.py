"""Pure tests: real support stages on the four frozen inputs (lossless roundtrip), hand-computed policy costs/aliases/ties,
the frozen schedule, and the analyzer's denominator/quantile/paired-test rules. The VLM stand-in only checks plumbing
(it is never accelerator evidence).

Run (repo root):
  PYTHONPATH=experiments/gpu-mobilint-placement .scratch/gpu-mobilint-vlm-20261028/env/mblt-x86/bin/python -m unittest -v test_chain
"""
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import chain_analyze as A
import chain_design as D
import chain_policy as CP
import chain_stages as S

ROOT = Path(__file__).resolve().parents[2]
FROZEN = ROOT.parent/'frozen'  # staged: the rebound ser0003/ser0004 frozen contract
OLD_DESIGN = dict(REGIMES=('native', 'relay', 'shaped2'), PRIMARY=('shaped2', 'dag', 'task_fastest'),
                  SECONDARY=('shaped2', 'dag', 'network_greedy'))  # original 8x8 three-regime design (analyzer logic kept)


def old_design(test):
    for name, value in OLD_DESIGN.items():
        patcher = mock.patch.object(D, name, value)
        patcher.start()
        test.addCleanup(patcher.stop)


def frozen():
    contract = json.loads((FROZEN/'contract.json').read_text())
    manifest = json.loads((FROZEN/'assets-manifest.json').read_text())
    return contract, {i['id']: Path(i['source']).read_bytes() for i in manifest['inputs']}


class StandInVlm:
    """Plumbing stand-in with VlmStage's run/describe interface: requires the frozen NPY bytes, answers a fixed caption."""

    def __init__(self, contract, device='cuda:0', backend='cuda'):
        self.inputs = {i['image_sha256']: i for i in contract['inputs']}
        self.device, self.backend, self.calls = device, backend, []

    def describe(self):
        return dict(backend=self.backend, device=self.device, model_sha256={'stand-in': 'not a model'}, contract_sha256='x',
                    process=dict(state='ready'))

    def run(self, data):
        item = self.inputs[hashlib.sha256(data).hexdigest()]
        self.calls.append(item['id'])
        device = dict(output_device=self.device) if self.backend == 'cuda' else dict(output_tensor_device='cpu', output_tensor_note='host tensor')
        out = dict(input_id=item['id'], text='stand-in', token_ids=[1, 2], prompt_tokens=3, processor_sha256='p', timing={}, host={}, device=device)
        extra = {'output_device': device['output_device']} if 'output_device' in device else {}  # VlmStage.run's timing shape
        return json.dumps(out, sort_keys=True).encode(), dict(generate_ms=1.0, host={}, device_stats=device, **extra)


class SupportStages(unittest.TestCase):
    def test_four_frozen_inputs_roundtrip_through_real_t1_t2_adapter_t3(self):
        contract, inputs = frozen()
        self.assertEqual(sorted(inputs), sorted(D.ALL_INPUTS))
        vlm = StandInVlm(contract)
        t1, t2, t3 = S.ImagePack('cuda'), S.VlmPng(vlm, contract), S.ResultFormat('cuda')
        for item in contract['inputs']:
            npy = inputs[item['id']]
            self.assertEqual(hashlib.sha256(npy).hexdigest(), item['image_sha256'])
            png, timing = t1.run(npy)
            self.assertTrue(png.startswith(b'\x89PNG') and timing['roundtrip_identical'] and timing['output_bytes'] == len(png))
            self.assertLess(len(png), len(npy))
            out, timing2 = t2.run(png)
            self.assertEqual(timing2['reconstructed_npy_sha256'], item['image_sha256'])
            self.assertEqual(timing2['reconstructed_npy_bytes'], len(npy))
            final = json.loads(t3.run(out)[0])
            self.assertEqual((final['input_id'], final['token_ids']), (item['id'], [1, 2]))
            self.assertEqual(final['vlm_output_sha256'], hashlib.sha256(out).hexdigest())
        self.assertEqual(vlm.calls, [i['id'] for i in contract['inputs']])
        evaluation = inputs[D.INPUT]
        self.assertEqual((len(evaluation), len(t1.run(evaluation)[0])), (818048, 593966))  # coordinator precheck sizes

    def test_altered_pixel_or_non_canonical_input_is_refused(self):
        import numpy as np
        from PIL import Image
        contract, inputs = frozen()
        png, _ = S.ImagePack('cuda').run(inputs[D.INPUT])
        array = S.decode_png(png)
        array[0, 0, 0] ^= 1
        buf = io.BytesIO()
        Image.fromarray(array).save(buf, format='PNG')
        with self.assertRaisesRegex(ValueError, 'not byte-identical'):
            S.VlmPng(StandInVlm(contract), contract).run(buf.getvalue())
        fortran = io.BytesIO()
        np.save(fortran, np.asfortranarray(np.load(io.BytesIO(inputs[D.INPUT]))))
        with self.assertRaisesRegex(ValueError, 'byte-identical'):
            S.ImagePack('cuda').run(fortran.getvalue())
        with self.assertRaisesRegex(ValueError, 'RGB PNG'):
            Image.fromarray(array[:, :, 0]).save(buf := io.BytesIO(), format='PNG')
            S.decode_png(buf.getvalue())

    def test_support_stages_describe_host_cpu(self):
        for stage in (S.ImagePack('mobilint'), S.ResultFormat('mobilint')):
            self.assertEqual((stage.describe()['device'], stage.describe()['backend']), ('host-cpu', 'mobilint'))


def table(link0, link1, link2):
    proc = {('image_pack', 'G'): 50, ('image_pack', 'N'): 20, ('vlm', 'G'): 19000, ('vlm', 'N'): 300,
            ('result_format', 'G'): 5, ('result_format', 'N'): 2}
    link = {('S', 'G', 0): link0[0], ('S', 'N', 0): link0[1]}
    for (src, dst), v in link1.items():
        link[(src, dst, 1)] = v
    for (src, dst), v in link2.items():
        link[(src, dst, 2)] = v
    return dict(proc=proc, link=link)


NATIVE = table((30, 60), {('G', 'G'): 10, ('G', 'N'): 40, ('N', 'G'): 40, ('N', 'N'): 10},
               {('G', 'G'): 5, ('G', 'N'): 8, ('N', 'G'): 8, ('N', 'N'): 5})
SHAPED = table((30, 3300), {('G', 'G'): 10, ('G', 'N'): 2400, ('N', 'G'): 2400, ('N', 'N'): 10},
               {('G', 'G'): 5, ('G', 'N'): 50, ('N', 'G'): 50, ('N', 'N'): 5})


class Policies(unittest.TestCase):
    def test_hand_computed_native(self):
        d = CP.decide(NATIVE)
        got = {p: c['placement'] for p, c in d['choices'].items()}
        # task_fastest: N wins every stage. greedy T1: G 30+50=80 vs N 60+20=80 -> tie -> G; T2 from G: G 10+19000, N 40+300 -> N;
        # T3 from N: G 8+5, N 5+2 -> N. dag: NNN 60+20+10+300+5+2=397 < GNN 427 < NNG 403? no: NNG 60+20+10+300+8+5=403.
        self.assertEqual(got, dict(static_gpu='GGG', static_npu='NNN', task_fastest='NNN', network_greedy='GNN', dag='NNN'))
        self.assertEqual((d['predicted_ms']['NNN'], d['predicted_ms']['GNN'], d['predicted_ms']['NNG']), (397, 427, 403))
        self.assertEqual(CP.aliases(d), {'GGG': ['static_gpu'], 'NNN': ['dag', 'static_npu', 'task_fastest'], 'GNN': ['network_greedy']})

    def test_hand_computed_shaped(self):
        d = CP.decide(SHAPED)
        got = {p: c['placement'] for p, c in d['choices'].items()}
        # task_fastest NNN = 3300+20+10+300+5+2 = 3637; greedy GNN = 30+50+2400+300+5+2 = 2787 (= dag minimum; GNG 2835)
        self.assertEqual((got['task_fastest'], got['network_greedy'], got['dag']), ('NNN', 'GNN', 'GNN'))
        self.assertEqual((d['predicted_ms']['NNN'], d['predicted_ms']['GNN'], d['predicted_ms']['GNG']), (3637, 2787, 2835))
        self.assertEqual(CP.aliases(d)['GNN'], ['dag', 'network_greedy'])
        self.assertEqual([n for n, _ in CP.parts(SHAPED, 'GNN')], ['S->T1', 'T1', 'T1->T2', 'T2', 'T2->T3', 'T3'])  # no direct T3->S leg

    def test_dag_tie_breaks_by_placement_string(self):
        t = table((10, 10), {k: 0 for k in (('G', 'G'), ('G', 'N'), ('N', 'G'), ('N', 'N'))},
                  {k: 0 for k in (('G', 'G'), ('G', 'N'), ('N', 'G'), ('N', 'N'))})
        t['proc'] = {k: 1 for k in t['proc']}
        self.assertEqual(CP.select('dag', t), 'GGG')
        self.assertEqual(CP.select('task_fastest', t), 'GGG')

    def test_required_probes_cover_every_placement(self):
        probes = CP.required_probes(dict(npy=818048, png={'G': 593966, 'N': 593966}, vlm={'G': 700, 'N': 710}))
        self.assertEqual(len(probes), 10)
        fake = CP.table_from(NATIVE['proc'], [dict(p, median_ms=1.0) for p in probes])
        for placement in D.PLACEMENTS:
            CP.total(fake, placement)
        self.assertEqual({p['bytes'] for p in probes if p['edge'] == 2 and p['src'] == 'N'}, {710})


class Schedule(unittest.TestCase):
    setUp = old_design

    def test_frozen_schedule_is_complete_counterbalanced_and_reproducible(self):
        choices = {'native': {'GGG': ['static_gpu'], 'NNN': ['dag', 'static_npu', 'task_fastest'], 'GNN': ['network_greedy']},
                   'relay': {'GGG': ['static_gpu'], 'NNN': ['dag', 'network_greedy', 'static_npu', 'task_fastest']},
                   'shaped2': {'GGG': ['static_gpu'], 'NNN': ['static_npu', 'task_fastest'], 'GNN': ['dag', 'network_greedy']}}
        cells = D.cells(choices, 8, 8)
        self.assertEqual(len(cells), (3 + 2 + 3) * 8 * 8)
        self.assertEqual(cells, D.cells(choices, 8, 8))
        for regime, unique in choices.items():
            for placement in unique:
                self.assertEqual(sum(c['regime'] == regime and c['placement'] == placement for c in cells), 64)
        orders = D.regime_orders(8)
        self.assertEqual(len({tuple(o) for o in orders}), 6)
        self.assertTrue(all(sorted(o) == sorted(D.REGIMES) for o in orders))
        self.assertTrue(all(c['arrivals'] == [dict(index=0, offset_s=0.0)] and c['input_id'] == D.INPUT for c in cells))
        self.assertEqual(len({c['label'] for c in cells}), len(cells))


class Analyzer(unittest.TestCase):
    setUp = old_design

    def run_dir(self, cells, rows):
        d = Path(tempfile.mkdtemp())/'gmp-test'
        d.mkdir()
        dec = {r: CP.decide(SHAPED) for r in D.REGIMES}
        plans = dict(cells=cells, decisions=dec, aliases={r: CP.aliases(v) for r, v in dec.items()}, sizes={}, tables={},
                     shared_bottleneck=None, sha256='x')
        (d/'plans.json').write_text(json.dumps(plans))
        for cell, row in zip(cells, rows):
            if row is not None:
                (d/f"ledger-{cell['label']}.json").write_text(json.dumps(dict(rows=[row])))
        return d

    def test_denominator_quantiles_and_paired_test(self):
        choices = {r: CP.aliases(CP.decide(SHAPED)) for r in D.REGIMES}  # shaped2: task_fastest NNN vs dag GNN; greedy = dag alias
        cells = [c for c in D.cells(choices, 8, 8) if c['regime'] == 'shaped2']
        rows = []
        for n, c in enumerate(cells):
            if c['placement'] == 'GNN':
                rows.append(dict(status='ok', latency_ms=2500.0 + c['repeat'], deadline_met=True, request_id=c['label']))
            elif c['placement'] == 'NNN':
                rows.append(None if c['measurement_block'] == 8 and c['repeat'] == 8 else
                            dict(status='timeout', latency_ms=40000.0, deadline_met=False) if c['repeat'] == 1 else
                            dict(status='late_ok', latency_ms=6000.0 + c['repeat'], deadline_met=False, request_id=c['label']))
            else:
                rows.append(dict(status='ok', latency_ms=20000.0, deadline_met=False))
        out = Path(tempfile.mkdtemp())/'out'
        summary = A.analyze(self.run_dir(cells, rows), out)
        self.assertEqual(summary['scheduled_requests'], len(cells))
        self.assertEqual(sum(summary['counts'].values()), len(cells))
        self.assertEqual(summary['counts']['not_sent'], 1)       # a missing ledger stays in the denominator
        stats = {s['placement']: s for s in summary['plan_stats']}
        self.assertEqual((stats['NNN']['scheduled'], stats['NNN']['n_timeout'], stats['NNN']['success_n']), (64, 8, 55))
        self.assertEqual(stats['GNN']['p50_success_ms'], 2504.5)  # repeats 1..8 in every block -> median 2504.5
        self.assertAlmostEqual(stats['GNN']['p95_success_ms'], A.quantile([2500.0 + r for r in range(1, 9)] * 8, 0.95))
        self.assertGreater(min(r for r in [stats['NNN']['p95_success_ms']]), 6000)  # the timeout never became a 40 s success
        primary, secondary = summary['comparisons']
        self.assertTrue(primary['tested'])
        self.assertEqual(primary['p_raw'], 2 / 256)
        self.assertEqual(primary['p_holm'], 2 / 256)              # the secondary (greedy = dag alias) is not tested
        self.assertIn('GNN lower block-median E2E than NNN', primary['verdict'])
        self.assertFalse(secondary['tested'])
        self.assertIn('identical placement', secondary['verdict'])

    def test_sign_flip_and_holm(self):
        self.assertEqual(A.sign_flip_p([1, 1, 1, 1]), 2 / 16)
        self.assertEqual(A.sign_flip_p([1, -1]), 1.0)
        results = A.holm([dict(tested=True, p_raw=0.01, mean_block_diff_ms=-1, placement_a='A', placement_b='B', failures=dict(A=3, B=0),
                               deadline_met=dict(A=0, B=0)),
                          dict(tested=True, p_raw=0.04, mean_block_diff_ms=1, placement_a='C', placement_b='D', failures=dict(C=0, D=0),
                               deadline_met=dict(C=0, D=0))])
        self.assertEqual([r['p_holm'] for r in results], [0.02, 0.04])
        self.assertIn('imbalance', results[0]['verdict'])       # lower latency but more failures: not supported
        self.assertIn('D lower', results[1]['verdict'])


if __name__ == '__main__':
    unittest.main()
