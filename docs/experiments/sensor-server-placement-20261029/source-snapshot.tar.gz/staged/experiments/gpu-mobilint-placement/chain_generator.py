"""Edge source of the whole-server sensor job (one owned CPU Pod on dev0003; stdlib only; shipped next to bounded_http/http_runtime).

The whole job runs on ONE server: placement GGG or NNN only (a mixed placement or an inter-server probe is refused at entry).
The source emits the raw frozen NPY bytes of the request's input to the chosen server (through the owned gateway in the
relay conditions: S is zone edge, both servers zone cloud). The stages then forward on that same server (dag_worker
forwarding, binary framing, direct local HTTP). The final JSON returns as the nested HTTP reply. The collector never carries data.
Latency is measured on this Pod's monotonic clock only, from the request's SCHEDULED arrival; hop rpc times nest and are
never summed. Every completed reply is checked here: three receipts (stage order, host Pod UID/node, device, backend, the
qualified per-stage model/static hashes, run/request id), the backend-specific T2 output evidence, the expected hop routes and
the linked payload hashes/bytes source -> T1 -> hop -> T2 -> hop -> T3 -> final; any break is integrity_failed.

Open loop: arrivals fire at their scheduled offsets; a request finding max_inflight open is admission_drop. Terminal
states (every scheduled arrival gets exactly one): ok | late_ok | failed | integrity_failed | worker_rejected | timeout |
admission_drop | not_sent.
HTTP: GET /ready /status /ledger?label= /job?name=
      POST /configure {run_id, hosts{G,N:{url,pod_uid,node,vlm_device,backend,stages{stage:{model_sha256,static_sha256}}}},
                       gateway_url, origin_url}
           /corpus {cache_url, files[{id, path, sha256}], budget_s}
           /profile {inputs, roundtrip_inputs, warmup, reps, call_s}            (job 'profile', closed loop, direct routes)
           /probes {job, relay, probes[{src,dst,edge,kind,bytes,input_id}], reps, timeout_s}   (S->server or same-host only)
           /trace {label, relay, placement, input_id, arrivals[{index,offset_s}], slo_s, timeout_s, max_inflight}
           /stop   /run (mode=sink: probe sink for worker -> source routes)
"""
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
import base64
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import socket
import statistics
import sys
import threading
import time
import urllib.error
import urllib.parse

sys.path.insert(0, str(Path(__file__).resolve().parent))
from bounded_http import DeadlineExceeded, exchange, post as bounded_post  # noqa: E402
from http_runtime import decode_body, payload  # noqa: E402

STAGES = ('image_pack', 'vlm', 'result_format')
ZONE = {'S': 'edge', 'G': 'cloud', 'N': 'cloud'}  # = chain_design.ZONE (staged: G is the ser0003 server GPU)
COLOCATED = ('GGG', 'NNN')  # = chain_design.PLACEMENTS: the whole job on one server
TERMINAL = ('ok', 'late_ok', 'failed', 'integrity_failed', 'worker_rejected', 'timeout', 'admission_drop', 'not_sent')
SUPPORT_DEVICE = 'host-cpu'
READ_DEADLINE_S = 90.0
FUTURE_SLACK_S = 5.0
MAX_ARRIVALS = 64


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fetch(url, expected, timeout=120, limit=64 * 1024 * 1024):
    status, data, _ = exchange(url, None, None, timeout, max_body=limit)
    if status != 200 or digest(data) != expected:
        raise ValueError(f'{url}: status {status} or sha256 mismatch')
    return data


def classify_http(code, text):
    """HTTP error of the first hop -> terminal state (503 admission / 429 gateway slots = rejected; 504 = an inner budget)."""
    if (code == 503 and 'admission' in text) or code == 429:
        return 'worker_rejected'
    return 'timeout' if code == 504 else 'failed'


def static_sha256(description):
    """dag_worker.slim's hash of a receipt's static load description; applied to the /health stage description verified at
    identity time it is the per-request expected value (same dict, both JSON-encoded with default=str)."""
    return digest(json.dumps(description, sort_keys=True, default=str).encode())


def output_evidence_problems(backend, timing):
    """gpu-mobilint-vlm receipt_problems output check on the T2 receipt (VlmStage.run puts result['device'] into
    timing.device_stats): CUDA = the generated tensor's cuda device, equal in timing.output_device; Mobilint = the labeled
    host output tensor."""
    device = timing.get('device_stats') or {}
    if backend == 'cuda':
        if not str(device.get('output_device')).startswith('cuda') or timing.get('output_device') != device.get('output_device'):
            return [f"vlm output_device={device.get('output_device')!r} is not the CUDA generated-tensor device"]
    elif device.get('output_tensor_device') != 'cpu' or not device.get('output_tensor_note'):
        return [f"vlm output_tensor_device={device.get('output_tensor_device')!r} is not the labeled host output tensor"]
    return []


def link_problems(placement, npy, final, receipts, hops, hosts, run_id, request_id, input_id, routes):
    """Receipt/hop linkage of one completed chain against the qualified identity of each host (UID/node/device/backend and
    per-stage model/static hashes), the backend-specific T2 output evidence and the expected hop routes. Returns a list
    of problems (empty = intact)."""
    problems = []
    if [r.get('stage') for r in receipts] != list(STAGES) or len(hops) != 2:
        return [f"stages {[r.get('stage') for r in receipts]} hops {len(hops)}"]
    for i, (stage, host, r) in enumerate(zip(STAGES, placement, receipts)):
        qualified = hosts[host]['stages'][stage]
        want = dict(pod_uid=hosts[host]['pod_uid'], node=hosts[host]['node'], run_id=run_id, request_id=request_id,
                    device=hosts[host]['vlm_device'] if stage == 'vlm' else SUPPORT_DEVICE, backend=hosts[host]['backend'],
                    model_sha256=qualified['model_sha256'], static_sha256=qualified['static_sha256'])
        problems += [f'{stage}.{k}={r.get(k)!r}' for k, v in want.items() if r.get(k) != v]
        if stage == 'vlm':
            timing = r.get('timing') or {}
            problems += output_evidence_problems(hosts[host]['backend'], timing)
            if timing.get('input_id') != input_id:
                problems.append(f"vlm input_id={timing.get('input_id')!r}")
    for i, (h, route) in enumerate(zip(hops, routes)):
        if h.get('route') != route:
            problems.append(f"hop {i} route {h.get('route')!r}, expected {route!r}")
    chain = [digest(npy)] + [h.get('output_sha256') for h in hops] + [digest(final)]
    for i, r in enumerate(receipts):
        if r.get('input_sha256') != chain[i]:
            problems.append(f'{STAGES[i]} input_sha256 does not match the received payload')
        if r.get('output_sha256') != chain[i + 1]:
            problems.append(f'{STAGES[i]} output_sha256 does not match the forwarded payload')
    for i, h in enumerate(hops):
        if h.get('payload_bytes') != receipts[i].get('output_bytes') or (h.get('src'), h.get('dst')) != (placement[i], placement[i + 1]):
            problems.append(f'hop {i} bytes/src/dst differ from the receipt or plan')
    try:
        answer = json.loads(final)
        if answer.get('input_id') != input_id:
            problems.append(f"final input_id {answer.get('input_id')!r}")
    except ValueError:
        problems.append('final answer is not JSON')
    return problems


class Generator:
    def __init__(self, post=None, clock=time.monotonic, sleep=time.sleep, fetcher=fetch):
        self.post, self.clock, self.sleep, self.fetcher = post or bounded_post, clock, sleep, fetcher
        self.lock, self.stop_flag = threading.Lock(), threading.Event()
        self.config, self.inputs, self.traces, self.jobs = None, {}, {}, {}
        self.node, self.pod_uid = os.environ.get('NODE_NAME'), os.environ.get('POD_UID')

    # ------------------------------------------------------------------ configuration
    def configure(self, body):
        hosts = body['hosts']
        if set(hosts) != {'G', 'N'} or any(not h.get(k) for h in hosts.values() for k in ('url', 'pod_uid', 'node', 'vlm_device', 'backend')):
            raise ValueError('hosts G and N need url, pod_uid, node, vlm_device, backend')
        if any(set(h.get('stages') or {}) != set(STAGES) or not h['stages']['vlm'].get('model_sha256') or
               any(not s.get('static_sha256') for s in h['stages'].values()) for h in hosts.values()):
            raise ValueError('hosts need qualified stages{image_pack,vlm,result_format: model_sha256, static_sha256}')
        with self.lock:
            if any(t['state'] == 'running' for t in self.traces.values()):
                raise ValueError('a trace is running')
            self.config = dict(run_id=body['run_id'], hosts=hosts, gateway_url=body.get('gateway_url'), origin_url=body['origin_url'])
        return dict(status='configured', node=self.node, pod_uid=self.pod_uid)

    def url(self, key):
        return self.config['origin_url'] if key == 'S' else self.config['hosts'][key]['url']

    def route(self, src, dst, relay):
        """-> (url, route). Same zone (or relay off): direct Pod IP; cross-zone in a relay regime: the owned gateway."""
        if relay and ZONE[src] != ZONE[dst]:
            if not self.config.get('gateway_url'):
                raise ValueError(f'{src}->{dst} crosses zones and no gateway is configured')
            return f"{self.config['gateway_url']}/to/{dst}/run", 'gateway'
        return self.url(dst) + '/run', 'direct'

    def load_corpus(self, body):
        until = self.clock() + float(body.get('budget_s', 300))
        for item in body['files']:
            remaining = until - self.clock()
            if remaining <= 0:
                raise DeadlineExceeded(float(body.get('budget_s', 300)))
            self.inputs[item['id']] = self.fetcher(body['cache_url'] + '/' + item['path'], item['sha256'], timeout=min(120.0, remaining))
        return dict(status='ok', inputs=sorted(self.inputs), bytes={k: len(v) for k, v in self.inputs.items()})

    # ------------------------------------------------------------------ calibration jobs (closed loop, sequential)
    def job(self, name, fn, body):
        with self.lock:
            if any(j['state'] == 'running' for j in self.jobs.values()) or any(t['state'] == 'running' for t in self.traces.values()):
                raise ValueError('another job or trace is running')
            if name in self.jobs:
                raise ValueError(f'job name {name} reused')
            self.jobs[name] = dict(state='running')

        def target():
            try:
                self.jobs[name].update(state='done', result=fn(body))
            except Exception as error:
                self.jobs[name].update(state='error', error=repr(error)[:500])
        threading.Thread(target=target, daemon=True).start()
        return dict(status='started', job=name)

    def call_stage(self, host, stage, data, request_id, timeout):
        """One stage alone on `host` over the direct route (forward=[]): its reply carries the one receipt."""
        body = dict(mode='dag', run_id=self.config['run_id'], request_id=request_id, stage=stage, input='raw', data=data, forward=[],
                    budget_s=timeout)
        sent = self.clock()
        reply = self.post(self.url(host) + '/run', body, timeout=timeout + 5)
        return reply, (self.clock() - sent) * 1000

    def profile(self, body):
        """Per input and host, the host's own job: T1 (raw NPY), T2 on that host's own PNG, T3 on that host's own VLM output
        (no cross-host variant: the whole job runs on one server); `warmup` calls per (stage, host, input) are kept and labelled. All four frozen inputs
        additionally pass T1 once per host (in-Pod lossless/byte-identical roundtrip). Receipts are returned whole."""
        warmup, reps, timeout = int(body.get('warmup', 1)), int(body.get('reps', 3)), float(body.get('call_s', 320))
        rows, outputs = [], {}

        def run(stage, host, input_id, variant, data, n, is_warmup, purpose='profile'):
            rid = f'profile-{stage}-{host}-{input_id}-{variant[:8]}-{n}'
            row = dict(stage=stage, host=host, input_id=input_id, variant=variant, warmup=is_warmup, purpose=purpose, request_id=rid,
                       input_bytes=len(data), input_sha256=digest(data))
            try:
                reply, rpc_ms = self.call_stage(host, stage, data, rid, timeout)
                out = base64.b64decode(reply['data'], validate=True)
                receipt = (reply.get('receipts') or [None])[0]
                row.update(status=reply.get('status'), rpc_ms=rpc_ms, receipt=receipt, output_bytes=len(out), output_sha256=digest(out))
                if reply.get('status') == 'ok':
                    outputs[(stage, host, input_id, variant)] = out
            except urllib.error.HTTPError as error:
                row.update(status='error', code=error.code, error=error.read(4000).decode(errors='replace')[:1000])
            except Exception as error:
                row.update(status='error', error=repr(error)[:500])
            rows.append(row)

        def series(stage, host, input_id, variant, data):
            for n in range(warmup + reps):
                run(stage, host, input_id, variant, data, n, n < warmup)

        for input_id in body.get('roundtrip_inputs', []):
            for host in ('G', 'N'):
                run('image_pack', host, input_id, 'npy', self.inputs[input_id], 0, False, purpose='roundtrip')
        for input_id in body['inputs']:
            npy = self.inputs[input_id]
            for host in ('G', 'N'):
                series('image_pack', host, input_id, 'npy', npy)
            for host in ('G', 'N'):
                for (s, h, i, _), png in sorted(outputs.items()):
                    if (s, h, i) == ('image_pack', host, input_id):
                        series('vlm', host, input_id, digest(png), png)
            for host in ('G', 'N'):
                for (s, h, i, _), out in sorted(outputs.items()):
                    if (s, h, i) == ('vlm', host, input_id):
                        series('result_format', host, input_id, digest(out), out)
        return dict(rows=rows, warmup=warmup, reps=reps, inputs=body['inputs'], roundtrip_inputs=body.get('roundtrip_inputs', []))

    def probe_rows(self, src, dst, size, reps, timeout, relay):
        url, route = self.route(src, dst, relay)
        if src == 'S':
            data, rows = os.urandom(size), []
            for _ in range(reps):
                sent = self.clock()
                try:
                    reply = self.post(url, dict(mode='sink', run_id=self.config['run_id'], request_id='probe', data=data), timeout=timeout)
                    rows.append(dict(rtt_ms=(self.clock()-sent)*1000, ok=reply.get('sha256') == digest(data) and reply.get('bytes') == size))
                except Exception as error:
                    rows.append(dict(rtt_ms=(self.clock()-sent)*1000, ok=False, error=repr(error)[:200]))
            return route, rows
        # control leg S -> src is direct (not measured); the measured transfer starts at src's own network position
        reply = self.post(self.url(src) + '/run', dict(mode='probe', run_id=self.config['run_id'], request_id='probe', url=url, bytes=size,
                                                       reps=reps, timeout_s=timeout), timeout=timeout * reps + 10)
        return route, reply['rows']

    def start_probes(self, body):
        """Only source -> server or same-host (local stage HTTP) probes: an inter-server probe is refused before any send."""
        for p in body['probes']:
            if p['dst'] not in ('G', 'N') or p['src'] not in ('S', p['dst']):
                raise ValueError(f"probe {p['src']}->{p['dst']} refused: only source -> server or same-host (no inter-server data edge)")
        return self.job(body['job'], self.probes, body)

    def probes(self, body):
        reps, timeout, relay = int(body.get('reps', 3)), float(body.get('timeout_s', 60)), bool(body['relay'])
        out = []
        for p in body['probes']:
            item = dict(p)
            try:
                route, rows = self.probe_rows(p['src'], p['dst'], int(p['bytes']), reps, timeout, relay)
                good = [r['rtt_ms'] for r in rows if r.get('ok')]
                item.update(route=route, rows=rows, complete=len(good) == len(rows) == reps,
                            median_ms=statistics.median(good) if len(good) == len(rows) == reps else None)
            except Exception as error:
                item.update(complete=False, median_ms=None, error=repr(error)[:300])
            out.append(item)
        return dict(probes=out, reps=reps, relay=relay)

    # ------------------------------------------------------------------ one request
    def request(self, trace, row, t_sched):
        placement, label, relay = trace['placement'], trace['label'], trace['relay']
        cancel_at = t_sched + trace['timeout_s']
        budget = cancel_at - self.clock()
        if budget <= 0:
            row.update(status='timeout', error='cancel budget exhausted before send', deadline_met=False)
            return
        a, b, c = placement
        npy = self.inputs[trace['input_id']]

        def hop(src, dst, stage):
            url, route = self.route(src, dst, relay)
            return dict(url=url, route=route, src=src, dst=dst, stage=stage, input='raw')
        first, forward = hop('S', a, 'image_pack'), [hop(a, b, 'vlm'), hop(b, c, 'result_format')]
        body = dict(mode='dag', run_id=self.config['run_id'], request_id=row['request_id'], stage='image_pack', input='raw', data=npy,
                    budget_s=budget, forward=forward)
        row.update(first_route=first['route'], first_payload_bytes=len(npy), send_offset_s=self.clock() - trace['t0'])
        sent = self.clock()
        reply = None
        try:
            reply = self.post(first['url'], body, timeout=budget)
            status = 'ok' if reply.get('status') == 'ok' else 'failed'
        except urllib.error.HTTPError as error:
            text = error.read(16000).decode(errors='replace')
            try:
                reply = json.loads(text)
            except ValueError:
                reply = dict(error=text[:500])
            status = classify_http(error.code, text)
            row['http_status'] = error.code
        except Exception as error:
            status = 'timeout' if ('timed out' in repr(error).lower() or isinstance(error, TimeoutError)) else 'failed'
            row['error'] = repr(error)[:300]
        done = self.clock()
        row.update(first_rpc_ms=(done - sent) * 1000, completed_offset_s=done - trace['t0'], latency_ms=(done - t_sched) * 1000)
        reply = reply or {}
        row.update(receipts=reply.get('receipts', []), hops=reply.get('hops', []))
        if status != 'ok':
            row.update(status=status, deadline_met=False, failed_stage=reply.get('failed_stage') or reply.get('stage'),
                       error=row.get('error') or reply.get('error'))
            return
        try:
            final = base64.b64decode(reply['data'], validate=True)
            problems = link_problems(placement, npy, final, row['receipts'], row['hops'], self.config['hosts'], self.config['run_id'],
                                     row['request_id'], trace['input_id'], [h['route'] for h in forward])
        except (KeyError, TypeError, ValueError) as error:
            final, problems = b'', [f'malformed reply {error!r}'[:300]]
        if problems:
            row.update(status='integrity_failed', deadline_met=False, error='; '.join(problems)[:1000])
            return
        answer = json.loads(final)
        met = row['latency_ms'] <= trace['slo_s'] * 1000
        row.update(status='ok' if met else 'late_ok', deadline_met=met, final_bytes=len(final), final_sha256=digest(final),
                   text=answer['text'], token_ids=answer['token_ids'])

    # ------------------------------------------------------------------ trace (open loop, fixed schedule)
    def start_trace(self, body):
        if not self.config:
            raise ValueError('not configured')
        arrivals = sorted(body['arrivals'], key=lambda a: a['offset_s'])
        if not arrivals or len(arrivals) > MAX_ARRIVALS or [a['index'] for a in arrivals] != list(range(len(arrivals))):
            raise ValueError('arrivals must be indexed 0..n-1 in offset order and bounded')
        if body['input_id'] not in self.inputs:
            raise ValueError(f"input {body['input_id']} not loaded")
        placement = body['placement']
        if placement not in COLOCATED:
            raise ValueError(f'placement {placement!r} refused: the whole job on one server (only {COLOCATED})')
        label = body['label']
        with self.lock:
            if label in self.traces or any(t['state'] == 'running' for t in self.traces.values()) or \
                    any(j['state'] == 'running' for j in self.jobs.values()):
                raise ValueError('trace label reused or another trace/job running')
            trace = dict(label=label, state='running', placement=placement, input_id=body['input_id'], relay=bool(body['relay']),
                         slo_s=float(body['slo_s']), timeout_s=float(body['timeout_s']), max_inflight=int(body['max_inflight']),
                         policies=body.get('policies'), arrivals=arrivals, inflight=0, max_seen_inflight=0,
                         rows=[dict(index=a['index'], request_id=f"{label}-{a['index']}", scheduled_offset_s=float(a['offset_s']), status=None)
                               for a in arrivals])
            self.traces[label] = trace
        self.stop_flag.clear()
        threading.Thread(target=self.run_trace, args=(trace,), daemon=True).start()
        return dict(status='started', label=label, requests=len(arrivals))

    def run_trace(self, trace):
        cap = trace['max_inflight']
        try:
            with ThreadPoolExecutor(max_workers=cap) as pool:
                trace['t0'] = t0 = self.clock() + 0.2
                futures = []
                for arrival in trace['arrivals']:
                    row = trace['rows'][arrival['index']]
                    t_sched = t0 + arrival['offset_s']
                    while not self.stop_flag.is_set() and self.clock() < t_sched:
                        self.sleep(min(0.02, max(0.0, t_sched - self.clock())))
                    if self.stop_flag.is_set():
                        row.update(status='not_sent', deadline_met=False)
                        continue
                    row['dispatch_lag_ms'] = (self.clock() - t_sched) * 1000
                    with self.lock:
                        if trace['inflight'] >= cap:
                            row.update(status='admission_drop', deadline_met=False, inflight_at_arrival=trace['inflight'])
                            continue
                        trace['inflight'] += 1
                        trace['max_seen_inflight'] = max(trace['max_seen_inflight'], trace['inflight'])
                        row['inflight_at_arrival'] = trace['inflight'] - 1
                    futures.append((row, t_sched, pool.submit(self.handle, trace, row, t_sched)))
                for row, t_sched, f in futures:
                    try:
                        f.result(timeout=max(0.0, t_sched + trace['timeout_s'] - self.clock()) + FUTURE_SLACK_S)
                    except FutureTimeout:
                        if row.get('status') is None:
                            row.update(status='timeout', deadline_met=False, error='request thread exceeded its absolute budget')
            trace['state'] = 'done'
        except Exception as error:
            trace.update(state='error', error=repr(error)[:500])
        for row in trace['rows']:
            if row.get('status') is None:  # accounted, never silently missing
                row.update(status='failed', deadline_met=False, error=row.get('error') or 'no terminal state recorded')
        trace['finished_offset_s'] = self.clock() - trace.get('t0', self.clock())

    def handle(self, trace, row, t_sched):
        try:
            self.request(trace, row, t_sched)
        except Exception as error:
            row.update(status='failed', deadline_met=False, error=repr(error)[:300])
        finally:
            with self.lock:
                trace['inflight'] -= 1

    def status(self):
        out = dict(configured=bool(self.config), node=self.node, pod_uid=self.pod_uid, inputs=sorted(self.inputs),
                   jobs={k: dict(state=v['state'], error=v.get('error')) for k, v in self.jobs.items()}, traces={})
        for label, t in self.traces.items():
            counts = {}
            for r in t['rows']:
                counts[r['status']] = counts.get(r['status'], 0) + 1
            out['traces'][label] = dict(state=t['state'], counts=counts, inflight=t['inflight'], error=t.get('error'))
        out['busy'] = any(t['state'] == 'running' or t['inflight'] for t in self.traces.values()) or \
            any(j['state'] == 'running' for j in self.jobs.values())
        return out

    def ledger(self, label):
        t = self.traces[label]
        return dict(label=label, state=t['state'], placement=t['placement'], input_id=t['input_id'], relay=t['relay'], policies=t['policies'],
                    slo_s=t['slo_s'], timeout_s=t['timeout_s'], max_inflight=t['max_inflight'], max_seen_inflight=t['max_seen_inflight'],
                    inflight=t['inflight'], finished_offset_s=t.get('finished_offset_s'), generator=dict(node=self.node, pod_uid=self.pod_uid),
                    rows=t['rows'], error=t.get('error'))

    def sink(self, body):
        data = payload(body['data'])
        return dict(status='ok', bytes=len(data), sha256=digest(data))


def serve(gen, host='0.0.0.0', port=8080):
    class Handler(BaseHTTPRequestHandler):
        timeout = 60

        def setup(self):
            super().setup()
            self.read_done = threading.Event()
            self.read_timer = threading.Timer(READ_DEADLINE_S, self._expire)
            self.read_timer.daemon = True
            self.read_timer.start()

        def _expire(self):
            if not self.read_done.is_set():
                try:
                    self.connection.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

        def finish(self):
            self.read_timer.cancel()
            try:
                super().finish()
            except OSError:
                pass

        def _send(self, status, value):
            raw = json.dumps(value, separators=(',', ':'), default=str).encode()
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(raw)))
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            self.read_done.set()
            url = urllib.parse.urlparse(self.path)
            query = urllib.parse.parse_qs(url.query)
            try:
                if url.path == '/ready':
                    self._send(200, dict(ready=True))
                elif url.path == '/status':
                    self._send(200, gen.status())
                elif url.path == '/ledger':
                    self._send(200, gen.ledger(query['label'][0]))
                elif url.path == '/job':
                    self._send(200, gen.jobs[query['name'][0]])
                else:
                    self._send(404, dict(error='unknown path'))
            except (KeyError, ValueError) as error:
                self._send(400, dict(error=repr(error)[:300]))

        def do_POST(self):
            try:
                size = int(self.headers.get('Content-Length', 0))
                if not 0 < size <= 32 * 1024 * 1024:
                    raise ValueError('body size')
                raw = self.rfile.read(size)
                self.read_done.set()
                if len(raw) != size:
                    return
                body = decode_body(raw, self.headers.get('Content-Type'))
                routes = {'/configure': gen.configure, '/corpus': gen.load_corpus, '/trace': gen.start_trace,
                          '/profile': lambda b: gen.job('profile', gen.profile, b),
                          '/probes': gen.start_probes,
                          '/stop': lambda b: (gen.stop_flag.set(), dict(status='stopping'))[1], '/run': gen.sink}
                if self.path not in routes:
                    raise KeyError(self.path)
                self._send(200, routes[self.path](body))
            except (KeyError, ValueError, TypeError) as error:
                self._send(400, dict(error=repr(error)[:500]))
            except Exception as error:
                self._send(500, dict(error=repr(error)[:500]))

        def log_message(self, *args):
            pass

    class Server(ThreadingHTTPServer):
        daemon_threads = True
    return Server((host, port), Handler)


def main():
    gen = Generator()
    server = serve(gen, port=int(os.environ.get('GENERATOR_PORT', '8080')))
    print(json.dumps(dict(event='generator_ready', node=gen.node, pod_uid=gen.pod_uid)), flush=True)
    server.serve_forever()


if __name__ == '__main__':
    main()
