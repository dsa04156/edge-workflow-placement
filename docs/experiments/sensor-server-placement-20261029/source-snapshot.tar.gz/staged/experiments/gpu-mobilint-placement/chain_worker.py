"""WORKER_MODULE for the unchanged quality-network-heterogeneous bootstrap.py (Mobilint arm) and gpu-mobilint-vlm
vlm_prepared_bootstrap.py (CUDA arm): quality-network-baselines dag_worker forwarding with two execution lanes.

- accelerator lane: the 'vlm' stage on the Worker's one-unit lock (one model call at a time on the allocated device);
- support lane: 'image_pack' and 'result_format' on a second, independent heterogeneous Worker (own lock and queue), so
  host-CPU support work never waits behind, nor holds, the accelerator lock.
Both lanes are unchanged worker.Worker instances; dag_worker.DagWorker (binary forwarding to the next hop, nested receipts,
mode queue/sink/probe, admission cap DAG_MAX_ACTIVE) is reused as is. A hop to the same worker is a real HTTP loopback;
no lock is held while forwarding, so self-forwarding cannot deadlock (only admission slots, sized for 3 per request).
The bounded vlm_stage.LoadFailed record is attached to the public load error, as gpu-mobilint-vlm vlm_worker.py does.
"""
import worker as base
import dag_worker
import chain_stages

SUPPORT = ('image_pack', 'result_format')
serve = dag_worker.serve


class Lanes(base.Worker):
    """Routes support stages to self.support; everything else is the unchanged accelerator-lane Worker."""

    def run(self, body):
        if body.get('stage') in SUPPORT:
            return self.support.run(body)
        return base.Worker.run(self, body)

    def health(self):
        out = base.Worker.health(self)
        support = self.support.health()
        out['stages'] = dict(out['stages'], **support['stages'])
        out['errors'] = dict(out['errors'], **support['errors'])
        out['status'] = 'ready' if not out['errors'] else ('partial' if out['stages'] else 'failed')
        out['support_queue'] = support['queue']
        return out


class Worker(dag_worker.DagWorker, Lanes):
    def __init__(self, backend, stage_names, **kwargs):
        records = {}

        def load(name, *args, **kw):
            try:
                return chain_stages.load(name, *args, **kw)
            except Exception as error:
                if getattr(error, 'record', None) is not None:
                    records[name] = error.record
                raise
        kwargs['loader'] = load
        self.support = base.Worker(backend, [s for s in stage_names if s in SUPPORT], **kwargs)
        super().__init__(backend, [s for s in stage_names if s not in SUPPORT], **kwargs)
        for errors in (self.errors, self.support.errors):
            for name, record in records.items():
                if name in errors:
                    errors[name]['record'] = record
