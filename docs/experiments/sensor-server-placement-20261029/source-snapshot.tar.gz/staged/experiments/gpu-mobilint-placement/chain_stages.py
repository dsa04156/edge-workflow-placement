"""Stage loader of the placement worker (heterogeneous Worker `loader=` seam): the three real chain stages.

  image_pack     (T1, host CPU)  frozen RGB uint8 NPY bytes -> lossless PNG (Pillow, fixed parameters). Before answering it
                 decodes its own PNG and requires the exact array and the byte-identical canonical NPY (np.save) back.
  vlm            (T2)  PNG -> canonical NPY reconstructed on this host (PNG decode is host CPU, timed separately); the NPY
                 sha256 must be one of the frozen contract inputs, then the UNCHANGED gpu-mobilint-vlm VlmStage/Engine runs
                 it (CUDA BF16 or Mobilint W4V8; its device/parameter/output checks and fail-closed child are untouched).
  result_format  (T3, host CPU)  VLM JSON -> compact final answer JSON {input_id, text, token_ids, prompt_tokens,
                 processor_sha256, vlm_output_sha256}.
T1/T3 are host CPU support work on the G or N host, never accelerator kernels; their describe() says device 'host-cpu'
(backend is the worker's, as the Worker requires). numpy/Pillow are the pinned ones already in each worker's runtime.
"""
import hashlib
import io
import json
from pathlib import Path
import time

PNG_PARAMS = dict(format='PNG', compress_level=6, optimize=False)
SUPPORT_DEVICE = 'host-cpu'


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def npy_bytes(array):
    import numpy as np
    buf = io.BytesIO()
    np.save(buf, array, allow_pickle=False)
    return buf.getvalue()


def decode_png(png):
    """PNG bytes -> uint8 HxWx3 array; anything but an RGB PNG is refused (no conversion that could hide a change)."""
    import numpy as np
    from PIL import Image
    image = Image.open(io.BytesIO(png))
    if image.format != 'PNG' or image.mode != 'RGB':
        raise ValueError(f'expected an RGB PNG, got {image.format} {image.mode}')
    image.load()
    return np.array(image)


def versions():
    import numpy
    import PIL
    return dict(numpy=numpy.__version__, pillow=PIL.__version__)


class ImagePack:
    def __init__(self, backend):
        self.backend = backend

    def describe(self):
        return dict(backend=self.backend, device=SUPPORT_DEVICE, role='host CPU support (not an accelerator kernel)', stage='image_pack',
                    model_sha256=None, codec=dict(PNG_PARAMS), libraries=versions())

    def run(self, data):
        import numpy as np
        from PIL import Image
        t0 = time.perf_counter()
        array = np.load(io.BytesIO(data), allow_pickle=False)
        if array.dtype != np.uint8 or array.ndim != 3 or array.shape[2] != 3:
            raise ValueError(f'input must be uint8 HxWx3, got {array.dtype} {list(array.shape)}')
        t1 = time.perf_counter()
        buf = io.BytesIO()
        Image.fromarray(array).save(buf, **PNG_PARAMS)  # uint8 HxWx3 -> RGB (vlm_stage's own conversion)
        png = buf.getvalue()
        t2 = time.perf_counter()
        back = decode_png(png)
        if back.shape != array.shape or not np.array_equal(back, array) or npy_bytes(back) != data:
            raise ValueError('PNG roundtrip is not lossless/byte-identical to the input NPY; refused')
        t3 = time.perf_counter()
        return png, dict(load_ms=(t1-t0)*1000, encode_ms=(t2-t1)*1000, verify_ms=(t3-t2)*1000, total_ms=(t3-t0)*1000,
                         input_bytes=len(data), output_bytes=len(png), shape=list(array.shape), roundtrip_identical=True,
                         device=SUPPORT_DEVICE)


class VlmPng:
    """T2: PNG -> canonical frozen NPY -> unchanged VlmStage.run. `vlm` is the loaded VlmStage (or, in plumbing tests only,
    a stand-in with the same run/describe interface)."""

    def __init__(self, vlm, contract):
        self.vlm = vlm
        self.inputs = {item['image_sha256']: item for item in contract['inputs']}

    def describe(self):
        return dict(self.vlm.describe(), adapter=dict(input='lossless PNG', reconstruct='canonical NPY (np.save)', decode_device=SUPPORT_DEVICE))

    def run(self, png):
        t0 = time.perf_counter()
        array = decode_png(png)
        npy = npy_bytes(array)
        item = self.inputs.get(sha256(npy))
        if item is None:
            raise ValueError('reconstructed NPY is not byte-identical to any frozen contract input')
        if list(array.shape) != list(item['shape']):
            raise ValueError(f"reconstructed shape {list(array.shape)} differs from the frozen {item['shape']}")
        t1 = time.perf_counter()
        out, timing = self.vlm.run(npy)
        result = json.loads(out)
        if result.get('input_id') != item['id']:
            raise ValueError(f"VLM answered input {result.get('input_id')!r}, expected {item['id']!r}")
        return out, dict(timing, png_decode_ms=(t1-t0)*1000, reconstructed_npy_sha256=sha256(npy), reconstructed_npy_bytes=len(npy),
                         input_id=item['id'])


class ResultFormat:
    def __init__(self, backend):
        self.backend = backend

    def describe(self):
        return dict(backend=self.backend, device=SUPPORT_DEVICE, role='host CPU support (not an accelerator kernel)', stage='result_format',
                    model_sha256=None)

    def run(self, data):
        t0 = time.perf_counter()
        result = json.loads(data)
        tokens = result['token_ids']
        if not isinstance(result['text'], str) or not isinstance(tokens, list) or not all(isinstance(t, int) for t in tokens):
            raise ValueError('VLM result lacks text/token_ids')
        final = dict(input_id=result['input_id'], text=result['text'], token_ids=tokens, prompt_tokens=result['prompt_tokens'],
                     processor_sha256=result['processor_sha256'], vlm_output_sha256=sha256(data))
        out = json.dumps(final, sort_keys=True, separators=(',', ':')).encode()
        return out, dict(total_ms=(time.perf_counter()-t0)*1000, input_bytes=len(data), output_bytes=len(out), device=SUPPORT_DEVICE)


def vlm_load(backend, model_root):
    """The unchanged gpu-mobilint-vlm loader (shipped vlm_stage.py)."""
    import vlm_stage
    return vlm_stage.load('vlm', backend, model_root=model_root)


def load(name, backend, model_root=None, **_):
    if name == 'image_pack':
        return ImagePack(backend)
    if name == 'result_format':
        return ResultFormat(backend)
    if name == 'vlm':
        stage = vlm_load(backend, model_root)
        return VlmPng(stage, json.loads((Path(model_root).parent/'contract.json').read_text()))
    raise ValueError(f'unknown stage {name!r}')
