"""Regressions for the round-1 review defects (no cluster): repeated network transitions keep exclusive artifact names;
integrity_failed is persisted then aborts; per-request qualified model/static hashes and backend-specific output evidence on
the ACTUAL frozen gpu-mobilint-vlm reply shape (artifacts/gpu-mobilint-vlm/gmv-20261028t-bench1, read only); expected hop
routes in whole-server qualification; exact block-bootstrap quantile intervals; outcome_unknown (dispatched or attempted,
not collected) kept apart from proven not_sent, all in the denominator. 2026-10-29: converted from mixed GNG/NGN chains and
native/relay/shaped2 to whole-server GGG/NNN and relay/npu_slow2 (route_problems itself: test_whole_server.Qualification).

Run (repo root):
  PYTHONPATH=experiments/gpu-mobilint-placement:experiments/quality-network-baselines:experiments/quality-network-heterogeneous:experiments/real-topology-live \
    .scratch/gpu-mobilint-vlm-20261028/env/mblt-x86/bin/python -m unittest -v test_chain_r1
"""
import base64
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import chain_analyze as A
import chain_design as D
import chain_live as L
import chain_generator as CG
import chain_policy as CP
import chain_stages
import dag_worker
from test_chain import SHAPED

BENCH = Path(__file__).resolve().parents[5]/'artifacts/gpu-mobilint-vlm/gmv-20261028t-bench1'
CELL = dict(label='m1-npu_slow2-NNN-r1', regime='npu_slow2', placement='NNN', input_id=D.INPUT, arrivals=[dict(index=0, offset_s=0.0)],
            policies=['dag'], measurement_block=1, repeat=1)


def sha(data):
    return hashlib.sha256(data).hexdigest()


class Fleet:
    """Control-plane seam: idle workers/gateway/generator; /trace, /status, /ledger as configured."""

    def __init__(self, rows=(), status_error_after_trace=False, counters=None):
        self.rows, self.status_error, self.counters, self.posted = list(rows), status_error_after_trace, counters or {}, []

    def __call__(self, url, body=None, timeout=None):
        if url.endswith('/reset'):
            return dict(label=body['label'], counters={})
        if url.endswith('/run'):
            return dict(waiting=0, active=0, joins_open=0, inflight=0, completed=1, dag_requests=1)
        if url.startswith('http://gw'):
            return dict(active=0, counters=self.counters)
        if url.endswith('/trace'):
            self.posted.append(body['label'])
            return dict(status='started', label=body['label'])
        if url.endswith('/status'):
            if self.status_error and self.posted:
                raise TimeoutError('status read timed out')
            return dict(busy=False, traces={label: dict(state='done') for label in self.posted})
        if '/ledger' in url:
            return dict(label=self.posted[-1], state='done', rows=self.rows)
        if url.endswith('/health'):
            host = 'G' if url.startswith('http://g') else 'N'
            return dict(pod_uid='u'+host, status='ready', stages=dict(vlm=dict(process=dict(state='ready'))))
        raise AssertionError(url)


def make_run(http):
    clock = [0.0]
    s = L.Session(tempfile.mkdtemp(), 'gmp-r1')  # real collect.Session.save: exclusive creation ('x')
    run = L.Run(s, L.DEFAULTS['frozen'], None, dict(design=dict(repeat_count=8, measurement_blocks=8)), http=http,
                clock=lambda: clock[0], sleep=lambda dt: clock.__setitem__(0, clock[0] + dt))
    run.urls = {'G': 'http://g', 'N': 'http://n', 'gateway': 'http://gw', 'generator': 'http://gen'}
    run.ids = {h: dict(pod_uid='u'+h) for h in D.HOSTS}
    run.ips = {'S': '10.0.0.1', 'G': '10.0.0.2', 'N': '10.0.0.3'}
    return run


class NetworkTransitions(unittest.TestCase):
    def test_revisited_regimes_get_unique_exclusive_artifacts(self):
        """Calibration visits both conditions, then the seeded evaluation order revisits them (old names collided with
        FileExistsError: drain-before-network-relay.json on the first evaluation transition)."""
        run = make_run(Fleet())
        sequence = list(D.REGIMES) + ['relay', 'npu_slow2', 'relay', 'relay']

        def applied(spec, *_):
            summary = [dict(handle=0x10000, kind='prio', bytes=0), dict(parent=0x10001, kind='tbf', bytes=0)] if spec['mbps'] else []
            return dict(spec=spec, netns='net:[1]', qdisc_summary=summary)
        with mock.patch.object(L.Session, 'net', side_effect=applied) as net:
            for regime in sequence:
                run.apply_network(regime)
        self.assertEqual(net.call_count, 5)  # the repeated 'relay' at the end is no transition
        nets = sorted(p.name for p in run.s.out.glob('network-*.json'))
        drains = sorted(p.name for p in run.s.out.glob('drain-before-network-*.json'))
        self.assertEqual(len(nets), 5)
        self.assertEqual(len(drains), 5)
        self.assertEqual(nets[2], 'network-003-relay.json')
        with self.assertRaises(FileExistsError):  # saves stay exclusive (existing artifacts are never overwritten)
            run.save(nets[0], {})


class IntegrityAbort(unittest.TestCase):
    def test_integrity_failed_is_persisted_then_aborts(self):
        row = dict(index=0, request_id=CELL['label']+'-0', status='integrity_failed', deadline_met=False, error='vlm.static_sha256=...')
        fleet = Fleet(rows=[row])
        run = make_run(fleet)
        with self.assertRaisesRegex(RuntimeError, 'integrity_failed.*run aborted'):
            run.request(CELL)
        saved = json.loads((run.s.out/f"ledger-{CELL['label']}.json").read_text())
        self.assertEqual(saved['rows'][0]['status'], 'integrity_failed')
        self.assertTrue((run.s.out/f"gateway-{CELL['label']}.json").exists())

    def test_ordinary_failure_does_not_abort(self):
        fleet = Fleet(rows=[dict(index=0, status='timeout', deadline_met=False)])
        self.assertEqual(make_run(fleet).request(CELL)['rows'][0]['status'], 'timeout')


class FrozenReplyShape(unittest.TestCase):
    """The actual frozen VLM receipts/health (one per arm) placed into a chain reply exactly as dag_worker builds it."""

    @classmethod
    def setUpClass(cls):
        cls.replies = {r['arm']: r for r in json.loads((BENCH/'ledger-probe.json').read_text())}
        cls.health = {arm: json.loads((BENCH/f'health-{arm}.json').read_text()) for arm in ('cuda', 'mobilint')}

    def chain(self, arm):
        """The whole job on `arm`'s server: NNN (Mobilint T2) or GGG (CUDA T2); T1/T3 are that server's host-CPU stages."""
        frozen = copy.deepcopy(self.replies[arm])  # the frozen file content is never mutated across tests
        vlm_host = other = 'N' if arm == 'mobilint' else 'G'
        placement = vlm_host * 3
        vlm_receipt = dag_worker.slim(frozen['receipt'])
        vlm_out = base64.b64decode(frozen['data'])
        npy, png = b'npy-bytes', b'png-bytes'
        final = json.dumps(dict(input_id=frozen['input'], text='x', token_ids=[1])).encode()
        vlm_receipt.update(input_sha256=sha(png), timing=dict(vlm_receipt['timing'], input_id=frozen['input']))  # VlmPng adds input_id
        support = {s: chain_stages.ImagePack(D.ARM[other]).describe() if s == 'image_pack' else chain_stages.ResultFormat(D.ARM[other]).describe()
                   for s in ('image_pack', 'result_format')}
        other_ids = dict(pod_uid=vlm_receipt['pod_uid'], node=vlm_receipt['node'])

        def support_receipt(stage, data_in, data_out):
            return dag_worker.slim(dict(stage=stage, backend=D.ARM[other], device='host-cpu', run_id=vlm_receipt['run_id'],
                                        request_id=vlm_receipt['request_id'], input_sha256=sha(data_in), output_sha256=sha(data_out),
                                        output_bytes=len(data_out), model_sha256=None, timing={}, static=support[stage], **other_ids))
        receipts = [support_receipt('image_pack', npy, png), vlm_receipt, support_receipt('result_format', vlm_out, final)]
        hops = [dict(src=placement[0], dst=placement[1], route='direct', stage='vlm', payload_bytes=len(png), output_sha256=sha(png)),
                dict(src=placement[1], dst=placement[2], route='direct', stage='result_format', payload_bytes=len(vlm_out),
                     output_sha256=sha(vlm_out))]
        vlm_desc = self.health[arm]['stages']['vlm']
        hosts = {vlm_host: dict(pod_uid=vlm_receipt['pod_uid'], node=vlm_receipt['node'], vlm_device=vlm_receipt['device'], backend=arm,
                                stages={'vlm': dict(static_sha256=CG.static_sha256(vlm_desc), model_sha256=vlm_desc['model_sha256']),
                                        **{s: dict(static_sha256=CG.static_sha256(support[s]), model_sha256=None) for s in support}})}
        args = dict(placement=placement, npy=npy, final=final, receipts=receipts, hops=hops, hosts=hosts, run_id=vlm_receipt['run_id'],
                    request_id=vlm_receipt['request_id'], input_id=frozen['input'], routes=['direct', 'direct'])
        return args

    def problems(self, args):
        return CG.link_problems(**args)

    def test_genuine_frozen_receipts_link_and_bind_static_from_health(self):
        for arm in ('cuda', 'mobilint'):
            self.assertEqual(self.problems(self.chain(arm)), [], arm)

    def test_wrong_model_static_output_device_or_route_is_rejected(self):
        for arm in ('cuda', 'mobilint'):
            for name, mutate, expect in (
                    ('model', lambda a: a['receipts'][1].update(model_sha256={'other': 'weights'}), 'vlm.model_sha256'),
                    ('static', lambda a: a['receipts'][1].update(static_sha256='0' * 64), 'vlm.static_sha256'),
                    ('support-static', lambda a: a['receipts'][2].update(static_sha256='0' * 64), 'result_format.static_sha256'),
                    ('backend', lambda a: a['receipts'][1].update(backend='cpu'), 'vlm.backend'),
                    ('route', lambda a: [h.update(route='gateway') for h in a['hops']], 'hop 0 route')):
                args = copy.deepcopy(self.chain(arm))
                mutate(args)
                self.assertTrue(any(expect in p for p in self.problems(args)), (arm, name, self.problems(args)))
        cuda = copy.deepcopy(self.chain('cuda'))
        cuda['receipts'][1]['timing']['output_device'] = 'cpu'  # the reviewer's reproduction
        self.assertTrue(any('output_device' in p for p in self.problems(cuda)))
        cuda = copy.deepcopy(self.chain('cuda'))
        cuda['receipts'][1]['timing']['device_stats']['output_device'] = 'cpu'
        cuda['receipts'][1]['timing']['output_device'] = 'cpu'
        self.assertTrue(any('output_device' in p for p in self.problems(cuda)))
        npu = copy.deepcopy(self.chain('mobilint'))
        npu['receipts'][1]['timing']['device_stats'].pop('output_tensor_note')
        self.assertTrue(any('output_tensor_device' in p for p in self.problems(npu)))

    def test_generator_classifies_bad_evidence_as_integrity_failed(self):
        args = self.chain('mobilint')
        args['receipts'][1]['timing']['device_stats']['output_tensor_device'] = 'npu'
        reply = dict(status='ok', data=base64.b64encode(args['final']).decode(), receipts=args['receipts'], hops=args['hops'])
        gen = CG.Generator(post=lambda url, body, timeout=None: reply)
        gen.config = dict(run_id=args['run_id'], hosts={h: dict(v, url='http://'+h) for h, v in args['hosts'].items()},
                          gateway_url='http://gw', origin_url='http://s')
        gen.inputs[args['input_id']] = args['npy']
        trace = dict(placement=args['placement'], label='t', relay=True, timeout_s=40.0, slo_s=5.0, input_id=args['input_id'], t0=gen.clock())
        row = dict(index=0, request_id=args['request_id'])
        gen.request(trace, row, gen.clock())
        self.assertEqual(row['status'], 'integrity_failed')
        self.assertIn('output_tensor_device', row['error'])

    def test_configure_requires_qualified_stage_identity(self):
        gen = CG.Generator()
        hosts = {h: dict(url='u', pod_uid='p', node='n', vlm_device='d', backend='b') for h in D.HOSTS}
        with self.assertRaisesRegex(ValueError, 'backend|stages'):
            gen.configure(dict(run_id='r', hosts=hosts, origin_url='o'))

    def test_collector_qualified_stages_from_frozen_health(self):
        health = dict(stages=dict(self.health['cuda']['stages'], image_pack=chain_stages.ImagePack('cuda').describe(),
                                  result_format=chain_stages.ResultFormat('cuda').describe()))
        want = L.qualified_stages(health, dict(model_sha256=health['stages']['vlm']['model_sha256']))
        self.assertEqual(want['vlm']['static_sha256'], dag_worker.slim(self.replies['cuda']['receipt'])['static_sha256'])
        with self.assertRaisesRegex(RuntimeError, 'model_sha256'):
            L.qualified_stages(health, dict(model_sha256='other'))


class RouteQualification(unittest.TestCase):
    def test_qualify_route_saves_verdict_and_aborts_on_mismatch(self):
        row = dict(index=0, status='ok', first_route='gateway', first_payload_bytes=818048, receipts=[dict(pod_uid='uG')] * 3,
                   hops=[dict(src='G', dst='G', route='gateway', payload_bytes=593966), dict(src='G', dst='G', route='direct', payload_bytes=700)])
        run = make_run(Fleet(rows=[row], counters={}))
        with mock.patch.object(L.Session, 'net', return_value=dict(qdisc_summary=[])):
            with self.assertRaisesRegex(RuntimeError, 'route qualification relay'):
                run.qualify_route('relay')
        saved = json.loads((run.s.out/'qualification-relay.json').read_text())
        self.assertFalse(saved['qualified'])
        self.assertTrue(any('hop routes' in p for p in saved['problems']))


class BlockBootstrap(unittest.TestCase):
    def test_hand_computed_two_blocks(self):
        out = A.block_bootstrap([[1.0, 2.0], [3.0, 4.0]])  # AA w=1/4 -> 1.5, AB w=1/2 -> 2.5, BB w=1/4 -> 3.5
        self.assertEqual((out['resamples'], out[0.5]), (3, [1.5, 3.5]))

    def test_eight_blocks_enumerate_every_resample_and_handle_empty_blocks(self):
        out = A.block_bootstrap([[float(b * 10 + r) for r in range(8)] for b in range(8)])
        self.assertEqual((out['blocks'], out['resamples'], out['empty_weight']), (8, 6435, 0.0))
        lo, hi = out[0.95]
        self.assertLess(lo, hi)
        sparse = A.block_bootstrap([[5.0]] + [[]] * 7)
        self.assertAlmostEqual(sparse['empty_weight'], (7 / 8) ** 8)
        self.assertEqual(sparse[0.95], [5.0, 5.0])
        self.assertEqual(A.block_bootstrap([[]] * 2)[0.5], [None, None])
        self.assertEqual(A.block_bootstrap([[1.0, 2.0]])[0.95], [None, None])  # 1x1 pilot: no zero-width interval


class OutcomeAccounting(unittest.TestCase):
    def test_collection_failure_is_outcome_unknown_not_not_sent(self):
        run = make_run(Fleet(status_error_after_trace=True))
        with self.assertRaises(TimeoutError):
            run.request(CELL)
        out = run.s.out
        self.assertTrue(json.loads((out/f"trace-{CELL['label']}.dispatch.json").read_text())['acknowledged'])
        self.assertFalse(json.loads((out/f"trace-{CELL['label']}.collection.json").read_text())['collected'])
        never = dict(CELL, label='m1-npu_slow2-GGG-r1', placement='GGG')
        partial = dict(CELL, label='m1-relay-NNN-r1', regime='relay')
        (out/f"trace-{partial['label']}.request.json").write_text('{}')
        (out/f"ledger-{partial['label']}.json").write_text(json.dumps(dict(rows=[dict(index=0, status=None)])))
        dec = {r: CP.decide(SHAPED) for r in D.REGIMES}
        (out/'plans.json').write_text(json.dumps(dict(cells=[CELL, never, partial], decisions=dec, aliases={}, sizes={}, tables={}, sha256='x')))
        summary = A.analyze(out, Path(tempfile.mkdtemp())/'analysis')
        self.assertEqual(summary['scheduled_requests'], 3)
        self.assertEqual((summary['counts']['outcome_unknown'], summary['counts']['not_sent']), (2, 1))
        self.assertEqual(summary['unaccounted'], [])
        stats = {(s['regime'], s['placement']): s for s in summary['plan_stats']}
        self.assertEqual(sum(s['n_outcome_unknown'] for k, s in stats.items() if k[1] == 'NNN'), 2)
        self.assertEqual(sum(s['success_n'] for s in stats.values()), 0)


if __name__ == '__main__':
    unittest.main()
