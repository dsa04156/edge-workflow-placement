"""Compact result tables of one whole-server sensor job selection run (stdlib only; never alters the run directory).

Decision unit: the WHOLE job on one server (GGG = GPU server, NNN = Mobilint NPU server); not DAG placement.
  python3 chain_analyze.py <run dir> <out dir>
Outputs (out dir must not exist):
  requests.csv   one row per scheduled request: condition, server, alias policy labels, terminal status, deadline outcome,
                 measured E2E from the scheduled arrival, per-stage host/device/queue/processing, task payload bytes, gateway
                 transport bytes of the request's cell, recorded route verdict and shaped-band byte delta, failure, answer.
  policies.csv   one row per (condition, policy): frozen server, the policy's own predicted objective, predicted processing and
                 source->server network cost, tie flag, selection time, the request it shares (aliases = ONE observation).
  stages.csv     one row per (request, stage) receipt and per same-host hop record (hop rpc_ms CONTAINS downstream work).
  plans.csv      one row per (condition, server): all scheduled requests and outcome counts. One observation (n=1) each: the
                 inherited quantile fields are singleton values, not distributions; no interval or significance test.
Request accounting: a scheduled request whose cell was never dispatched (no trace-<label>.request.json) is not_sent; one
whose cell was dispatched or attempted but whose ledger was not collected, or whose ledger row had no terminal state, is
outcome_unknown (it may have run). Both stay in the denominator.
  summary.json   counts by status over ALL scheduled requests, frozen tables and decisions, the observed compute_only vs
                 compute_network choice per condition (reported as observed, never forced), probe evidence, limitations.
The inherited significance machinery (block bootstrap / sign-flip / Holm) is kept as library code but NOT applied: with one
observation per (condition, server) there is no superiority, p95 or goodput claim.
"""
import itertools
import statistics
import csv
import json
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import chain_design as D  # noqa: E402

STATUSES = ('ok', 'late_ok', 'failed', 'integrity_failed', 'worker_rejected', 'timeout', 'admission_drop', 'not_sent', 'outcome_unknown')
BOOTSTRAP_LEVEL = 0.95
LIMITATIONS = [
    'Whole-server decision: the whole job (image_pack, VLM, result_format) runs on one server, GGG or NNN; not DAG placement, '
    'no inter-server stage partitioning, no mixed route. The earlier GNG/GNN DAG pilot is separate frozen evidence.',
    'G = ser0003 GB10 GPU (BF16), N = ser0004 Mobilint ARIES (W4V8), source dev0003 (JPEG/NPY replay from an edge Pod, not a '
    'verified live sensor stream). Different precisions; quality not evaluated.',
    'One process block (one GPU Pod, one Mobilint Pod), one input cal-3733440, one observation per (condition, server), at most '
    'four main jobs: a low-load single-request diagnosis; no statistical superiority, p95, capacity or goodput claim.',
    'fixed_gpu is a fixed GPU-first rule over the resource-eligible servers, not the actual kube-scheduler; fixed_npu is a '
    'reference. compute_only/compute_network are simple argmin baselines over two servers, not a new algorithm.',
    'npu_slow2 is the unchanged net_control.py 2 Mbit/s tbf on the owned gateway egress toward the NPU Pod IP only (cloud=[N], '
    'edge=[]); G and source replies unshaped; both servers reached through the same gateway in both conditions. Not a '
    'measured physical WAN/topology; no shared-bottleneck claim.',
    'Network cost is the application-path probe RTT of a size-matched synthetic payload (random bytes, the raw NPY byte '
    'count; not the sensor content) over the request route (HTTP/relay processing included), not a pure network time; '
    'derived effective throughput is not a link capacity or the configured rate. Main jobs used the frozen sensor input.',
    'Same-host stage HTTP is part of the server processing estimate; T1/T3 are host-CPU support stages, only T2 runs '
    'neural inference on CUDA or Mobilint (no CPU fallback).',
    'Policy labels selecting the same server share ONE observation (aliases), never independent samples. The chooser was '
    'not forced to switch: an unchanged choice across conditions is reported as observed.',
]


def load(path):
    return json.loads(Path(path).read_text())


def stage_fields(rows_receipts):
    out = {}
    for r in rows_receipts:
        s, t = r.get('stage'), r.get('timing') or {}
        out.update({f'{s}_host_node': r.get('node'), f'{s}_device': r.get('device'), f'{s}_queue_wait_ms': r.get('queue_wait_ms'),
                    f'{s}_worker_wall_ms': r.get('worker_wall_ms'), f'{s}_output_bytes': r.get('output_bytes')})
        if s == 'vlm':
            out.update(vlm_generate_ms=t.get('generate_ms'), vlm_ttft_ms=t.get('ttft_ms'), vlm_preprocess_ms=t.get('preprocess_ms'),
                       vlm_png_decode_ms=t.get('png_decode_ms'))
    return out


def quantile(values, q):
    """Type-7 (linear interpolation) empirical quantile; None for no values."""
    x = sorted(values)
    if not x:
        return None
    h = (len(x) - 1) * q
    lo = math.floor(h)
    return x[lo] + (h - lo) * (x[min(lo + 1, len(x) - 1)] - x[lo])


def block_bootstrap(blocks, qs=(0.5, 0.95), level=BOOTSTRAP_LEVEL):
    """Exact block bootstrap: every multiset of B blocks drawn with replacement from the B observed blocks (multinomial
    weight B!/prod(c!)/B^B), pooled successful values of the resample -> type-7 quantile; percentile interval of the weighted
    distribution. Resamples without any success carry `empty_weight` and are left out of the interval. Fewer than 2 blocks
    (e.g. a 1x1 pilot): no interval at all, never a zero-width one. -> dict."""
    b = len(blocks)
    if b < 2:
        return dict({q: [None, None] for q in qs}, blocks=b, resamples=0, empty_weight=None)
    draws = {q: [] for q in qs}
    empty, count = 0.0, 0
    for combo in itertools.combinations_with_replacement(range(b), b):
        count += 1
        weight = math.factorial(b) / math.prod(math.factorial(combo.count(i)) for i in set(combo)) / b ** b
        pooled = [v for i in combo for v in blocks[i]]
        if not pooled:
            empty += weight
            continue
        for q in qs:
            draws[q].append((quantile(pooled, q), weight))
    out = dict(blocks=b, resamples=count, empty_weight=empty)
    for q in qs:
        values, total = sorted(draws[q]), sum(w for _, w in draws[q])
        bounds = []
        for target in ((1 - level) / 2, (1 + level) / 2):
            cum, chosen = 0.0, None
            for v, w in values:
                cum += w
                if cum >= target * total - 1e-12:
                    chosen = v
                    break
            bounds.append(chosen)
        out[q] = bounds if values else [None, None]
    return out


def success(r):
    return r['status'] in ('ok', 'late_ok') and r['e2e_ms'] is not None


def plan_stats(requests):
    out = []
    for (regime, placement), rows in sorted(group(requests, ('regime', 'placement')).items()):
        ok = [r['e2e_ms'] for r in rows if success(r)]
        blocks = group(rows, ('measurement_block',))
        boot = block_bootstrap([[r['e2e_ms'] for r in v if success(r)] for _, v in sorted(blocks.items())])
        out.append(dict(regime=regime, placement=placement, policies=rows[0]['policies'], scheduled=len(rows),
                        **{f'n_{s}': sum(r['status'] == s for r in rows) for s in STATUSES},
                        deadline_met=sum(r['deadline_met'] is True for r in rows), deadline_met_rate_all_scheduled=
                        sum(r['deadline_met'] is True for r in rows) / len(rows), success_n=len(ok),
                        p50_success_ms=quantile(ok, 0.5), p95_success_ms=quantile(ok, 0.95),
                        p50_block_boot95_lo_ms=boot[0.5][0], p50_block_boot95_hi_ms=boot[0.5][1],
                        p95_block_boot95_lo_ms=boot[0.95][0], p95_block_boot95_hi_ms=boot[0.95][1],
                        uncertainty_blocks=boot['blocks'], uncertainty_resamples=boot['resamples'],
                        uncertainty_empty_resample_weight=boot['empty_weight'],
                        uncertainty_note=(f"exact block bootstrap over {boot['blocks']} temporal blocks of the same warm processes; "
                                          'coarse, may under-cover; p95 interval especially rough; not process/hardware replication')
                        if boot['blocks'] >= 2 else 'fewer than 2 temporal blocks: no uncertainty estimate; singleton values only',
                        latency_note='conditional on success (ok/late_ok); failures/timeouts excluded, never assigned a latency',
                        block_success_medians_ms='|'.join(f"{b[0]}:{quantile([r['e2e_ms'] for r in v if success(r)], 0.5)}"
                                                          for b, v in sorted(blocks.items()))))
    return out


def group(rows, keys):
    out = {}
    for r in rows:
        out.setdefault(tuple(r[k] for k in keys), []).append(r)
    return out


def sign_flip_p(diffs):
    """Exact two-sided sign-flip permutation p-value of the mean paired difference (all 2^B sign assignments)."""
    observed = abs(statistics.fmean(diffs))
    hits = total = 0
    for signs in itertools.product((1, -1), repeat=len(diffs)):
        total += 1
        hits += abs(statistics.fmean(s * d for s, d in zip(signs, diffs))) >= observed - 1e-12
    return hits / total


def compare(requests, decisions, spec):
    regime, a, b = spec
    pa, pb = decisions[regime]['choices'][a]['placement'], decisions[regime]['choices'][b]['placement']
    out = dict(regime=regime, policy_a=a, policy_b=b, placement_a=pa, placement_b=pb)
    if pa == pb:
        return dict(out, tested=False, verdict='identical placement: aliases share one observation; no superiority test')
    rows = {p: [r for r in requests if r['regime'] == regime and r['placement'] == p] for p in (pa, pb)}
    fails = {p: sum(not success(r) for r in v) for p, v in rows.items()}
    hits = {p: sum(r['deadline_met'] is True for r in v) for p, v in rows.items()}
    blocks, diffs = sorted({r['measurement_block'] for v in rows.values() for r in v}), []
    excluded = []
    for m in blocks:
        med = {p: quantile([r['e2e_ms'] for r in rows[p] if r['measurement_block'] == m and success(r)], 0.5) for p in (pa, pb)}
        if None in med.values():
            excluded.append(m)
        else:
            diffs.append(med[pa] - med[pb])
    out.update(failures={pa: fails[pa], pb: fails[pb]}, deadline_met={pa: hits[pa], pb: hits[pb]}, block_diffs_ms=diffs,
               blocks_excluded_no_success=excluded)
    if len(diffs) < 2:
        return dict(out, tested=False, verdict='inconclusive: fewer than 2 blocks with successes on both placements')
    return dict(out, tested=True, mean_block_diff_ms=statistics.fmean(diffs), p_raw=sign_flip_p(diffs), blocks=len(diffs))


def holm(results):
    tested = sorted((r for r in results if r.get('tested')), key=lambda r: r['p_raw'])
    running = 0.0
    for i, r in enumerate(tested):
        running = max(running, min(1.0, (len(tested) - i) * r['p_raw']))
        r['p_holm'] = running
    for r in tested:
        lower, higher = (r['placement_a'], r['placement_b']) if r['mean_block_diff_ms'] < 0 else (r['placement_b'], r['placement_a'])
        guard = r['failures'][lower] <= r['failures'][higher] and r['deadline_met'][lower] >= r['deadline_met'][higher]
        if r['p_holm'] < 0.05 and guard:
            r['verdict'] = f'{lower} lower block-median E2E than {higher} (Holm p={r["p_holm"]:.4f}; failures/deadline not worse)'
        elif r['p_holm'] < 0.05:
            r['verdict'] = 'latency difference with failure/deadline imbalance: latency-only superiority not supported'
        else:
            r['verdict'] = f'inconclusive (Holm p={r["p_holm"]:.4f})'
    return results


def missing_outcome(run_dir, label):
    """Row for a scheduled request without a ledger row: proven not_sent only if the collector never attempted the cell."""
    if not (run_dir/f'trace-{label}.request.json').exists():
        return dict(status='not_sent', deadline_met=False, error='cell never dispatched (no trace request saved; run aborted before it)')
    dispatch = run_dir/f'trace-{label}.dispatch.json'
    collection = run_dir/f'trace-{label}.collection.json'
    if not dispatch.exists() or not load(dispatch).get('acknowledged'):
        evidence = 'dispatch attempted, generator acknowledgement not received'
    else:
        evidence = 'dispatched (generator acknowledged); ledger not collected'
    if collection.exists():
        evidence += f"; collection error {load(collection).get('error')}"
    return dict(status='outcome_unknown', deadline_met=False, error=evidence+' (may have run)')


def analyze(run_dir, out_dir):
    run_dir, out_dir = Path(run_dir), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=False)
    plans = load(run_dir/'plans.json')
    requests, stages = [], []
    for cell in plans['cells']:
        route = run_dir/f"route-{cell['label']}.json"
        route = load(route) if route.exists() else {}
        path = run_dir/f"ledger-{cell['label']}.json"
        ledger = load(path) if path.exists() else None
        missing = missing_outcome(run_dir, cell['label'])
        gateway = load(run_dir/f"gateway-{cell['label']}.json") if (run_dir/f"gateway-{cell['label']}.json").exists() else {}
        transport = {k: sum(v.get(k, 0) for v in (gateway.get('counters') or {}).values()) for k in ('request_body_bytes', 'response_body_bytes')}
        predicted = plans['decisions'][cell['regime']]['predicted_ms'][cell['placement']]
        for i, arrival in enumerate(cell['arrivals']):
            row = ledger['rows'][i] if ledger and i < len(ledger['rows']) else missing
            if row.get('status') is None:
                row = dict(row, status='outcome_unknown', deadline_met=False,
                           error='ledger row had no terminal state when collected: '+str(row.get('error') or ''))
            hops = row.get('hops') or []
            rec = dict(label=cell['label'], request_id=row.get('request_id'), measurement_block=cell['measurement_block'], repeat=cell['repeat'],
                       regime=cell['regime'], network=D.NETWORK[cell['regime']]['label'], placement=cell['placement'],
                       server=D.host_of(cell['placement']),
                       policies='|'.join(cell['policies']), alias_count=len(cell['policies']), status=row.get('status'),
                       deadline_met=row.get('deadline_met'), slo_s=D.SLO_S, e2e_ms=row.get('latency_ms'), predicted_ms=predicted,
                       dispatch_lag_ms=row.get('dispatch_lag_ms'), npy_bytes=row.get('first_payload_bytes'),
                       png_bytes=hops[0].get('payload_bytes') if len(hops) > 0 else None,
                       vlm_json_bytes=hops[1].get('payload_bytes') if len(hops) > 1 else None, final_bytes=row.get('final_bytes'),
                       first_route=row.get('first_route'), hop_routes='|'.join(str(h.get('route')) for h in hops),
                       gateway_request_body_bytes=transport['request_body_bytes'], gateway_response_body_bytes=transport['response_body_bytes'],
                       route_verified=(not route['problems']) if 'problems' in route else None,
                       route_problems='; '.join(route.get('problems') or [])[:300],
                       shaped_band_bytes_delta=route.get('shaped_band_bytes_delta'),
                       failed_stage=row.get('failed_stage'), error=(row.get('error') or '')[:300], text=row.get('text'))
            rec.update(stage_fields(row.get('receipts') or []))
            requests.append(rec)
            for r in row.get('receipts') or []:
                stages.append(dict(label=cell['label'], kind='receipt', stage=r.get('stage'), node=r.get('node'), device=r.get('device'),
                                   queue_wait_ms=r.get('queue_wait_ms'), worker_wall_ms=r.get('worker_wall_ms'), input_sha256=r.get('input_sha256'),
                                   output_sha256=r.get('output_sha256'), output_bytes=r.get('output_bytes')))
            for h in hops:
                stages.append(dict(label=cell['label'], kind='hop', stage=h.get('stage'), src=h.get('src'), dst=h.get('dst'), route=h.get('route'),
                                   payload_bytes=h.get('payload_bytes'), output_sha256=h.get('output_sha256'),
                                   rpc_ms_nested_not_summed=h.get('rpc_ms'), status=h.get('status')))
    policies = []
    for regime, decision in plans['decisions'].items():
        for policy, choice in decision['choices'].items():
            shared = [r for r in requests if r['regime'] == regime and r['placement'] == choice['placement']]
            policies.append(dict(regime=regime, policy=policy, placement=choice['placement'], predicted_ms=choice['predicted_ms'],
                                 predicted_processing_ms=choice.get('processing_ms'), predicted_network_ms=choice.get('network_ms'),
                                 tie=choice.get('tie'), selection_ms=choice['selection_ms'], aliases=shared[0]['policies'] if shared else None,
                                 shared_observation=bool(shared) and shared[0]['alias_count'] > 1, scheduled_requests=len(shared)))
    stats = plan_stats(requests)
    comparisons = []  # significance summaries disabled: one observation per (condition, server)
    for name, rows in (('requests.csv', requests), ('policies.csv', policies), ('stages.csv', stages), ('plans.csv', stats)):
        keys = []
        for r in rows:
            keys += [k for k in r if k not in keys]
        with (out_dir/name).open('x', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=keys)
            writer.writeheader()
            writer.writerows(rows)
    counts = {s: sum(r['status'] == s for r in requests) for s in STATUSES}
    unknown = [r['label'] for r in requests if r['status'] not in STATUSES]
    observed_choice = {}
    for regime, decision in plans['decisions'].items():
        c = decision['choices']
        observed_choice[regime] = dict(compute_only=c['compute_only']['placement'], compute_network=c['compute_network']['placement'],
                                       network_changed_choice=c['compute_only']['placement'] != c['compute_network']['placement'])
    summary = dict(run=run_dir.name, decision_unit='whole job on one server (GGG or NNN); not DAG placement',
                   scheduled_requests=len(requests), counts=counts, unaccounted=unknown,
                   deadline_met=sum(r['deadline_met'] is True for r in requests), plans_sha256=plans['sha256'], aliases=plans['aliases'],
                   observed_choice=observed_choice, sizes=plans['sizes'], tables=plans['tables'], probe_evidence=plans.get('probe_evidence'),
                   route_unverified=[r['label'] for r in requests if r['route_verified'] is False],
                   network_claim='relay: unshaped gateway control; npu_slow2: 2 Mbit/s tbf toward the NPU Pod only (owned gateway netns); '
                                 'no physical WAN/topology or shared-bottleneck claim',
                   precision=D.PRECISION, quality='not evaluated (system diagnostic, not quality-eligible goodput)',
                   comparisons=comparisons, plan_stats=stats,
                   statistics='descriptive only: one observation per (condition, server); singleton values, no interval, no '
                              'significance test, no superiority/p95/goodput claim',
                   limitations=LIMITATIONS)
    (out_dir/'summary.json').write_text(json.dumps(summary, indent=1))
    return summary


if __name__ == '__main__':
    print(json.dumps(analyze(sys.argv[1], sys.argv[2]), indent=1)[:4000])
