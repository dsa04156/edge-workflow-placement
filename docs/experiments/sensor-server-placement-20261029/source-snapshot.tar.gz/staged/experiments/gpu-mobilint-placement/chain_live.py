"""Collector of the whole-server sensor job selection: GPU server (G) vs Mobilint NPU server (N), one process block, only
after a coordinator release. The whole image_pack/VLM/result_format job runs on ONE server (GGG or NNN); this is a whole-server
decision, never DAG placement and never a mixed route (not even in qualification).

  python3 chain_live.py --print-release-draft                                             (pure; prints the release draft)
  python3 chain_live.py --plan                                                            (pure; manifests + design)
  python3 chain_live.py --dry-run --release <json>                                        (pure; release check, no kubectl)
  python3 chain_live.py --runs <dir> --release <json> [--run-id gmp-...]                  (cluster run)
Frozen inputs default to the spec paths (--frozen/--prepared/--cuda-cache-pvc override them; the release binds them).
Staged GB10/Mobilint variant (2026-10-29): the default is NON-prepared (prepared=None): no prepared runtime
release, cache bundle entry, PVC/preflight, prepared event or dev0009 access; the CUDA worker runs the original
vlm_bootstrap (offline wheels from the owned cache) on ser0003 and Mobilint the original bootstrap on ser0004. The old
prepared path is kept only behind an explicit --prepared + --cuda-cache-pvc pair.

Reused, unchanged: gpu-mobilint-vlm live.py (cache/worker Pod manifests incl. prepared CUDA + SD PVC mode, load_prepared,
PVC/preflight/occupancy/identity/prepared-event checks), multi-edge-sensors collect.Session (create-only, UID records also
on partial create, unresolved accounting, UID-precondition delete, per-call stdout/stderr/event files, phase events,
protected snapshot), quality-network-baselines dag_worker/gateway/bounded_http, real-topology-live http_runtime and
net_control.py (in the gateway's NET_ADMIN-only netctl sidecar), quality-network-heterogeneous bootstrap/worker.
Streams: exec only into the owned server cache (bundle upload) and the owned gateway netctl container, each after a fresh
GET binding this run's creation UID, labels and the server node; logs only for server Pods; edge-node Pods never streamed.
Order: preflight (incl. accelerator occupancy refusal) -> cache -> 2 workers + gateway + generator -> identity -> profile
(once per stage/server, same-host variants) -> per condition (relay, npu_slow2): network (net_control cloud=[N IP], edge=[];
qdisc/filter/counters + netns saved and checked) -> probes (source -> server via the gateway, same-host local HTTP) ->
colocated qualification GGG and NNN (routes + gateway byte counters + shaped-band qdisc byte deltas) -> frozen cost
tables/decisions/cells (at most 4 main jobs) -> sequential requests, each behind a 90 s drain barrier (abort on failure) ->
final checks; finally UID-owned cleanup, absence verification, protected snapshot. No shared-bottleneck/two-flow check.
"""
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import statistics
import subprocess
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
GMV, QNB, LIVE = (ROOT/'experiments'/d for d in ('gpu-mobilint-vlm', 'quality-network-baselines', 'real-topology-live'))
_spec = importlib.util.spec_from_file_location('gmv_live', GMV/'live.py')
G = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(G)  # puts gpu-mobilint-vlm, heterogeneous, real-topology-live, multi-edge-sensors, baselines on sys.path
sys.path.insert(0, str(HERE))
import chain_design as D  # noqa: E402
import chain_generator  # noqa: E402
import chain_policy  # noqa: E402

P, C, collect, bounded_http, prepare = G.P, G.C, G.collect, G.bounded_http, G.prepare
NS = P.NS
REPO = ROOT.parents[2]  # staged ROOT = <repo>/.scratch/sensor-server-placement-20261029/staged
DEFAULTS = dict(frozen=ROOT.parent/'frozen', prepared=None, pvc=None, io_profile=None)
PYROUTE2 = REPO/'artifacts/topology-profile-live/network-wheels/pyroute2-0.9.6-py3-none-any.whl'
PYROUTE2_SHA256 = '3334091326e560a506635449af03b26920d22d4e5a7996aed354363d106fcef8'
SHIPPED = dict(G.SHIPPED, **G.SHIPPED_PREPARED, **{'dag_worker.py': QNB/'dag_worker.py', 'bounded_http.py': QNB/'bounded_http.py',
               'gateway.py': QNB/'gateway.py', 'net_control.py': LIVE/'net_control.py', 'chain_stages.py': HERE/'chain_stages.py',
               'chain_worker.py': HERE/'chain_worker.py', 'chain_generator.py': HERE/'chain_generator.py'})
EXPECTED_DEVICE = {'G': 'cuda:0', 'N': 'npu:aries-rb'}
NODE = {'cache': P.SERVER, 'gateway': P.SERVER, 'mobilint': P.SERVER, 'cuda': P.JETSON, 'generator': D.ORIGIN_NODE}
EDGE_KEYS = {k for k, n in NODE.items() if n != P.SERVER}
STREAM_EXEC = {('cache', 'worker'), ('gateway', 'netctl')}
STAGE_LIST = ','.join(D.STAGES)


def utc():
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------- manifests (pure)
def meta(run, name, component):
    return dict(name=name, namespace=NS, labels={'experiment': D.EXPERIMENT, 'run-id': run, 'component': component})


def config_map(run):
    return dict(apiVersion='v1', kind='ConfigMap', metadata=meta(run, run+'-code', 'code'),
                data={name: path.read_text() for name, path in SHIPPED.items()})


def cache_pod(run, footprint, lifetime):
    pod = G.cache_pod(run, footprint, lifetime)
    pod['metadata'] = meta(run, run+'-cache', 'cache')
    return pod


def worker_pod(run, host, cache_url, manifest_sha, prepared, lifetime):
    arm = D.ARM[host]
    pod = G.worker_pod(run, arm, cache_url, manifest_sha, prepared)
    pod['metadata'] = meta(run, f'{run}-{arm}', arm)
    pod['spec']['activeDeadlineSeconds'] = lifetime
    env = pod['spec']['containers'][0]['env']
    values = dict(WORKER_MODULE='chain_worker', STAGES=STAGE_LIST)
    for item in env:
        if item['name'] in values:
            item['value'] = values.pop(item['name'])
    if values:
        raise ValueError(f'worker manifest lacks {sorted(values)}')
    env.append(dict(name='DAG_MAX_ACTIVE', value=str(D.BUDGETS['dag_max_active'])))
    return pod


def helper_pod(run, key, node, command, resources, lifetime, extra_containers=(), env=()):
    """quality-network-baselines live.helper_pod shape (non-root, read-only root fs, no service account token)."""
    container = dict(name='worker', image=P.PY_IMAGE, imagePullPolicy='IfNotPresent', command=command,
                     env=[dict(name='NODE_NAME', valueFrom={'fieldRef': {'fieldPath': 'spec.nodeName'}}),
                          dict(name='POD_UID', valueFrom={'fieldRef': {'fieldPath': 'metadata.uid'}}),
                          dict(name='PYTHONDONTWRITEBYTECODE', value='1'), *env],
                     resources=resources, ports=[dict(containerPort=P.PORT)],
                     readinessProbe={'httpGet': {'path': '/ready' if key == 'generator' else '/health', 'port': P.PORT},
                                     'periodSeconds': 5, 'timeoutSeconds': 3},
                     volumeMounts=[dict(name='work', mountPath='/work'), dict(name='config', mountPath='/config', readOnly=True)],
                     securityContext={'runAsUser': 65532, 'runAsGroup': 65532, 'runAsNonRoot': True, 'allowPrivilegeEscalation': False,
                                      'readOnlyRootFilesystem': True, 'capabilities': {'drop': ['ALL']}})
    spec = dict(restartPolicy='Never', activeDeadlineSeconds=lifetime, terminationGracePeriodSeconds=3, automountServiceAccountToken=False,
                enableServiceLinks=False, securityContext={'seccompProfile': {'type': 'RuntimeDefault'}}, affinity=G.affinity(node),
                containers=[container, *extra_containers],
                volumes=[{'name': 'work', 'emptyDir': {'sizeLimit': '1Gi'}}, {'name': 'config', 'configMap': {'name': run+'-code'}}])
    return dict(apiVersion='v1', kind='Pod', metadata=meta(run, f'{run}-{key}', key), spec=spec)


def generator_pod(run, lifetime):
    return helper_pod(run, 'generator', D.ORIGIN_NODE, ['python3', '-u', '/config/chain_generator.py'],
                      {'requests': {'cpu': '250m', 'memory': '384Mi', 'ephemeral-storage': '256Mi'},
                       'limits': {'cpu': '1', 'memory': '1Gi', 'ephemeral-storage': '1Gi'}}, lifetime)


def gateway_pod(run, cache_url, lifetime):
    """Relay (non-root) + netctl sidecar (root with ONLY NET_ADMIN, read-only root fs, no privilege escalation; pyroute2
    fetched sha-verified from the owned cache); tc acts only in this Pod's own netns (quality-network-baselines pattern)."""
    setup = ("import urllib.request,io,zipfile,hashlib,time;op=urllib.request.build_opener(urllib.request.ProxyHandler({}));"
             f"b=op.open({cache_url+'/netctl/'+PYROUTE2.name!r},timeout=120).read();assert hashlib.sha256(b).hexdigest()=={PYROUTE2_SHA256!r};"
             f"zipfile.ZipFile(io.BytesIO(b)).extractall('/work/net');print('netctl-ready',flush=True);time.sleep({lifetime})")
    netctl = dict(name='netctl', image=P.PY_IMAGE, imagePullPolicy='IfNotPresent', command=['python3', '-u', '-c', setup],
                  env=[dict(name='RESEARCH_LINK_CONTROL', value='owned-pod-netns'), dict(name='PYTHONPATH', value='/work/net:/config')],
                  volumeMounts=[dict(name='work', mountPath='/work'), dict(name='config', mountPath='/config', readOnly=True)],
                  resources={'requests': {'cpu': '10m', 'memory': '32Mi'}, 'limits': {'cpu': '1', 'memory': '96Mi'}},
                  securityContext={'runAsUser': 0, 'runAsNonRoot': False, 'allowPrivilegeEscalation': False, 'readOnlyRootFilesystem': True,
                                   'capabilities': {'drop': ['ALL'], 'add': ['NET_ADMIN']}})
    return helper_pod(run, 'gateway', P.SERVER, ['python3', '-u', '/config/gateway.py'],
                      {'requests': {'cpu': '500m', 'memory': '256Mi', 'ephemeral-storage': '128Mi'},
                       'limits': {'cpu': '2', 'memory': '1Gi', 'ephemeral-storage': '1Gi'}}, lifetime, extra_containers=[netctl],
                      env=[dict(name='GATEWAY_UPSTREAM_CAP_S', value=str(D.BUDGETS['gateway_upstream_cap_s'])),
                           dict(name='GATEWAY_SLOTS', value=str(D.BUDGETS['gateway_slots']))])


def input_files(manifest):
    return [dict(id=i['id'], source=i['source'], sha256=i['sha256'], path=f"inputs/{i['id']}.npy") for i in manifest['inputs']
            if i['id'] in D.ALL_INPUTS]


def footprint(manifest, prepared):
    extra = sum(Path(i['source']).stat().st_size for i in input_files(manifest)) + PYROUTE2.stat().st_size
    return dict(total=G.selected_footprint(manifest['footprint_bytes'], None, prepared)['total'] + extra)


def plan(run, frozen, prepared, lifetime):
    manifest = json.loads((Path(frozen)/'assets-manifest.json').read_text())
    sha = P.file_sha(Path(frozen)/'assets-manifest.json')
    cache = 'http://<cache-pod-ip>:8080'
    return [config_map(run), cache_pod(run, footprint(manifest, prepared), lifetime),
            worker_pod(run, 'G', cache, sha, prepared, lifetime), worker_pod(run, 'N', cache, sha, prepared, lifetime),
            gateway_pod(run, cache, lifetime), generator_pod(run, lifetime)]


# ---------------------------------------------------------------- release (pure)
def dependency_hashes():
    """sha256 of every repository module a fresh collector process loads plus every Pod-shipped file."""
    probe = ("import json,sys;sys.path.insert(0,sys.argv[1]);import chain_live;"
             "print(json.dumps(sorted({m.__file__ for m in list(sys.modules.values()) if getattr(m,'__file__',None)})))")
    loaded = json.loads(subprocess.run([sys.executable, '-c', probe, str(HERE)], capture_output=True, text=True, check=True, timeout=120,
                                       env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}).stdout)
    files = {Path(f).resolve() for f in loaded if f.endswith('.py') and Path(f).resolve().is_relative_to(ROOT/'experiments')}
    files |= {p.resolve() for p in SHIPPED.values()}
    files.add(Path(G.__file__).resolve())  # exec_module-loaded, never registered in sys.modules
    return {str(f.relative_to(ROOT)): P.file_sha(f) for f in sorted(files)}


def release_draft(frozen, prepared, repeat_count, measurement_blocks):
    manifest = json.loads((Path(frozen)/'assets-manifest.json').read_text())
    return json.loads(json.dumps(dict(  # JSON-normal form (tuples -> lists), exactly what a saved release file holds
                experiment=D.EXPERIMENT, design=D.design_dict(repeat_count=repeat_count, measurement_blocks=measurement_blocks),
                design_sha256=D.design_sha256(repeat_count=repeat_count, measurement_blocks=measurement_blocks),
                frozen={n: P.file_sha(Path(frozen)/n) for n in ('contract.json', 'assets-manifest.json')},
                inputs={i['id']: i['sha256'] for i in input_files(manifest)}, pyroute2_sha256=PYROUTE2_SHA256,
                prepared=prepared and prepared['binding'], cuda_cache_pvc=prepared and prepared['pvc'],
                prepared_deadlines=prepared and prepared['deadlines'], io_profile=prepared and prepared['io_profile'],
                code=dependency_hashes(), approved_by=None)))


def release_problems(release, draft):
    """Every bound key must equal the freshly computed draft (code, design/schedule, assets, prepared/PVC, inputs)."""
    problems = [f'{k} differs from the release' for k in draft if k != 'approved_by' and release.get(k) != draft[k]]
    if not release.get('approved_by'):
        problems.append('release needs approved_by')
    if PYROUTE2.is_file() and P.file_sha(PYROUTE2) != PYROUTE2_SHA256:
        problems.append('pyroute2 wheel differs from the bound sha256')
    return problems


# ---------------------------------------------------------------- session (kubectl seam)
class Session(collect.Session):
    """collect.Session for this experiment: own labels/run ids; fail-closed stream guard (server Pods only)."""

    def __init__(self, out_root, run_id):
        if not re.fullmatch(r'gmp-[a-z0-9][a-z0-9-]{0,35}', run_id):
            raise ValueError('run-id must match gmp-[a-z0-9-], at most 40 characters')
        self.run, self.out = run_id, Path(out_root)/run_id
        self.out.mkdir(parents=True, exist_ok=False)
        self.counter, self.resources, self.unresolved = 0, [], []

    def call(self, stem, args, stdin=None, timeout=60):
        if args and args[0] in G.STREAM_VERBS:
            reason = self.stream_problem(args)
            if reason:
                self.counter += 1
                self.save(f'{self.counter:04d}-{stem}.{"skipped" if args[0] == "logs" else "refused"}.json',
                          dict(at=utc(), verb=args[0], args=args[:8], reason=reason + f'; kubectl {args[0]} not invoked'))
                if args[0] == 'logs':
                    return ''
                raise RuntimeError(f'refused: {args[0]} ({reason})')
        return collect.Session.call(self, stem, args, stdin, timeout)

    def stream_problem(self, args):
        name = next((a for a in args[1:] if a.startswith(self.run+'-')), None)
        key = name.removeprefix(self.run+'-') if name else None
        container = args[args.index('-c') + 1] if '-c' in args else None
        if name is None or self.record(name) is None:
            return f'stream target {name!r} is not an owned Pod of this run'
        if key in EDGE_KEYS or key not in NODE:
            return 'kubelet stream to an edge-node Pod is outside the control boundary'
        if not (args[0] == 'logs' or (args[0] == 'exec' and (key, container) in STREAM_EXEC)):
            return f'{args[0]} into {key}/{container} is not part of this collector'
        try:
            obj = self.pod_state(name)  # refuses a replaced object (UID differs from the creation record)
        except Exception as error:
            return f'fresh GET refused the target: {error!r}'[:500]
        labels, want = obj['metadata'].get('labels') or {}, meta(self.run, name, key)['labels']
        if {k: labels.get(k) for k in want} != want or not self.record(name).get('owned_labels'):
            return f'fresh GET: labels {labels} are not this run\'s {key}'
        if obj['spec'].get('nodeName') != P.SERVER:
            return f"fresh GET: actual node {obj['spec'].get('nodeName')!r} is not the server {P.SERVER}"
        return None

    def create(self, stem, items):
        """gpu-mobilint-vlm Session.create semantics with this experiment's owned-label check."""
        value = dict(apiVersion='v1', kind='List', items=items)
        self.save(stem+'.manifest.json', value)
        self.call(stem+'-dry-run', ['create', '--dry-run=server', '-f', '-', '-o', 'json'], json.dumps(value))
        error = None
        try:
            raw = self.call(stem, ['create', '-f', '-', '-o', 'json'], json.dumps(value))
        except Exception as exc:
            error = exc
            raw = (self.out/f'{self.counter:04d}-{stem}.stdout').read_text(errors='replace')
        objects, complete = collect.created_objects(raw)
        records = []
        for obj in objects:
            m, labels = obj['metadata'], obj['metadata'].get('labels', {})
            record = dict(kind=obj['kind'], name=m['name'], uid=m['uid'], created_at=m.get('creationTimestamp'),
                          owned_labels=labels.get('experiment') == D.EXPERIMENT and labels.get('run-id') == self.run)
            records.append(record)
            self.resources.append(record)
        confirmed = {(r['kind'], r['name']) for r in records}
        unresolved = [dict(kind=i['kind'], name=i['metadata']['name'], stem=stem) for i in items if (i['kind'], i['metadata']['name']) not in confirmed]
        if error is not None or not complete:
            self.unresolved += unresolved
        self.save(stem+'.created.json', dict(confirmed=records, unresolved=unresolved if (error is not None or not complete) else [],
                                             stdout_complete=complete))
        if error is not None:
            raise RuntimeError(f'{stem}: create failed after {len(records)}/{len(items)} confirmed') from error
        if not complete or len(records) != len(items) or not all(r['owned_labels'] for r in records):
            raise RuntimeError(f'{stem}: create confirmed {len(records)}/{len(items)} owned objects')

    def ip(self, key):
        return self.pod_state(f'{self.run}-{key}')['status']['podIP']

    def net(self, spec, stem, timeout):
        """unchanged net_control.py inside the owned gateway Pod's netctl container (server Pod, fresh-GET guarded)."""
        raw = self.call(stem, ['exec', '-i', '-n', NS, self.run+'-gateway', '-c', 'netctl', '--', 'python3', '-u', '-c',
                               "import runpy;runpy.run_path('/config/net_control.py',run_name='__main__')"], json.dumps(spec), timeout=timeout)
        return json.loads(raw)


def verify_cleanup(session):
    return G.verify_cleanup(session)


# ---------------------------------------------------------------- run
class Budget:
    def __init__(self, total_s, reserve_s, clock=time.monotonic):
        self.clock, self.until, self.reserve = clock, clock() + total_s, reserve_s

    def remaining(self):
        return self.until - self.reserve - self.clock()

    def lifetime(self):
        """activeDeadlineSeconds for an object created now: it expires by the end of the whole budget."""
        return max(60, math.ceil(self.until - self.clock()))


class Run:
    def __init__(self, session, frozen, prepared, release, http=None, clock=time.monotonic, sleep=time.sleep):
        self.s, self.frozen, self.prepared, self.release = session, Path(frozen), prepared, release
        self.design, self.b = release['design'], D.BUDGETS
        self.clock, self.sleep = clock, sleep
        self.http = http or (lambda url, body=None, timeout=None: bounded_http.control(url, body, timeout=timeout,
                                                                                      max_body=self.b['control_max_body_bytes']))
        self.budget = Budget(self.b['campaign_s'], self.b['cleanup_reserve_s'], clock)
        self.urls, self.progress_state = {}, dict(phase='init', done=0, total=None, statuses={})
        self.network, self.transitions, self.last_gateway = None, 0, None

    # -- helpers
    def save(self, name, value):
        self.s.save(name, value)

    def progress(self, **fields):
        self.progress_state.update(fields, updated_utc=utc())
        tmp = self.s.out/'progress.json.tmp'
        tmp.write_text(json.dumps(self.progress_state, indent=1))
        os.replace(tmp, self.s.out/'progress.json')

    def control(self, url, body=None, timeout=None):
        budget = min(timeout or self.b['control_timeout_s'], self.budget.remaining())
        if budget <= 0:
            raise bounded_http.DeadlineExceeded(budget)
        return self.http(url, body, timeout=budget)

    def job(self, path, body, name, timeout):
        until = self.clock() + timeout
        self.control(self.urls['generator']+path, body)
        while self.clock() < until:
            state = self.control(self.urls['generator']+'/job?name='+name)
            if state['state'] != 'running':
                return state
            self.sleep(self.b['poll_s'])
        return dict(state='timeout', timeout_s=timeout)

    # -- phases
    def preflight(self):
        manifest = json.loads((self.frozen/'assets-manifest.json').read_text())
        problems = prepare.verify_manifest(manifest)
        problems += [f"input {i['id']} differs" for i in input_files(manifest) if P.file_sha(i['source']) != i['sha256']]
        collect.protected_snapshot(self.s, 'protected-before')
        nodes = json.loads(self.s.call('nodes', ['get', 'nodes', '-o', 'json']))['items']
        pods = json.loads(self.s.call('pods', ['get', 'pods', '-A', '-o', 'json']))['items']
        problems += G.preflight_problems(nodes, pods, self.s.run)
        origin = next((n for n in nodes if n['metadata']['name'] == D.ORIGIN_NODE), None)
        ready = origin and next((c['status'] for c in origin['status'].get('conditions', []) if c['type'] == 'Ready'), None)
        if ready != 'True' or any(t.get('effect') in ('NoSchedule', 'NoExecute') for t in (origin or {}).get('spec', {}).get('taints') or []):
            problems.append(f'{D.ORIGIN_NODE}: not Ready/untainted')
        pvc_uid = None
        if self.prepared:  # non-prepared (staged default): no PVC/PV read at all
            want = self.prepared['pvc']
            pvc = json.loads(self.s.call('pvc', ['get', 'pvc', '-n', NS, want['name'], '-o', 'json']))
            pv = json.loads(self.s.call('pv', ['get', 'pv', want['pv'], '-o', 'json']))
            need = self.prepared['binding']['total_bytes'] + 4096*self.prepared['binding']['file_count'] + 256*1024**2
            node = next((n for n in nodes if n['metadata']['name'] == P.JETSON), dict(metadata={}))
            problems += G.pvc_problems(pvc, pv, node, pods, want, need)
            pvc_uid = pvc['metadata'].get('uid')
        self.save('preflight.json', dict(problems=problems, prepared=bool(self.prepared), pvc_uid=pvc_uid))
        if problems:
            raise RuntimeError('preflight: '+'; '.join(problems))
        return manifest

    def cache(self, manifest):
        s = self.s
        s.create('cache', [config_map(s.run), cache_pod(s.run, footprint(manifest, self.prepared), self.budget.lifetime())])
        status = s.wait_ready('cache', [s.run+'-cache'], P.DEADLINES['cache_ready_s'])
        if status[s.run+'-cache']:
            raise RuntimeError('cache not Ready: '+json.dumps(status))
        self.cache_url = f"http://{s.ip('cache')}:{P.PORT}"
        tar_path = s.out/'bundle.tar'
        with tarfile.open(tar_path, 'x') as archive:
            archive.add(self.frozen/'assets-manifest.json', 'assets-manifest.json')
            for item in manifest['files']:
                if item['group'] in G.bundle_groups(None, self.prepared):
                    archive.add(item['source'], item['path'])
            if self.prepared:
                archive.add(self.prepared['manifest_path'], 'prepared/prepared-manifest.json')
                archive.add(self.prepared['tar'], 'prepared/runtime.tar')
            for item in input_files(manifest):
                archive.add(item['source'], item['path'])
            archive.add(PYROUTE2, 'netctl/'+PYROUTE2.name)
        bundle_bytes = tar_path.stat().st_size
        with tar_path.open('rb') as source:
            s.call('cache-upload', ['exec', '-i', '-n', NS, s.run+'-cache', '-c', 'worker', '--', 'python3', '-c',
                                    "import tarfile,sys;tarfile.open(fileobj=sys.stdin.buffer,mode='r|').extractall('/work',filter='data')"],
                   stdin=source, timeout=min(self.b['upload_s'], self.budget.remaining()))
        tar_path.unlink()  # reproducible from the frozen/prepared manifests; size recorded below
        checks = {'assets-manifest.json': P.file_sha(self.frozen/'assets-manifest.json'),
                  **({'prepared/prepared-manifest.json': self.prepared['binding']['manifest_sha256']} if self.prepared else {}),
                  **{i['path']: i['sha256'] for i in input_files(manifest)}, 'netctl/'+PYROUTE2.name: PYROUTE2_SHA256}
        for path, sha in checks.items():
            code, body, _ = bounded_http.exchange(self.cache_url+'/'+path, None, None, 60, C.MANIFEST_MAX)
            if code != 200 or P.sha256(body) != sha:
                raise RuntimeError(f'cache does not serve the bound {path}')
        self.save('cache.json', dict(url=self.cache_url, bundle_bytes=bundle_bytes, served=checks))

    def pods(self):
        s, lifetime = self.s, self.budget.lifetime()
        sha = P.file_sha(self.frozen/'assets-manifest.json')
        s.create('pods', [worker_pod(s.run, 'G', self.cache_url, sha, self.prepared, lifetime),
                          worker_pod(s.run, 'N', self.cache_url, sha, self.prepared, lifetime),
                          gateway_pod(s.run, self.cache_url, lifetime), generator_pod(s.run, lifetime)])
        helpers = s.wait_ready('helpers', [s.run+'-gateway', s.run+'-generator'], min(self.b['helper_ready_s'], self.budget.remaining()))
        ready_s = max(self.prepared['deadlines']['worker_ready_s'], P.DEADLINES['worker_ready_s']) if self.prepared else P.DEADLINES['worker_ready_s']
        window = min(ready_s, self.budget.remaining())
        workers = s.wait_ready('workers', [s.run+'-cuda', s.run+'-mobilint'], window)
        self.save('ready.json', dict(helpers=helpers, workers=workers, window_s=window))
        if any(helpers.values()) or any(workers.values()):
            raise RuntimeError(f'not Ready: {helpers} {workers}')
        for key in ('cuda', 'mobilint', 'gateway', 'generator'):
            self.urls[key] = f"http://{s.ip(key)}:{P.PORT}"
            self.save(f'ip-{key}.json', dict(url=self.urls[key]))
        self.urls['G'], self.urls['N'] = self.urls['cuda'], self.urls['mobilint']

    def identity(self):
        """gpu-mobilint-vlm identity (UID/node/device/contract/weights of the vlm stage) + both support stages loaded on host CPU."""
        s, contract_sha = self.s, P.file_sha(self.frozen/'contract.json')
        s.frozen = self.frozen
        self.health, self.ids = {}, {}
        for host in D.HOSTS:
            arm = D.ARM[host]
            health = self.health[host] = self.control(self.urls[host]+'/health')
            s.save(f'health-{arm}.json', health)
            self.ids[host] = G.identity(s, arm, health, contract_sha)
            support = {n: (health.get('stages') or {}).get(n, {}).get('device') for n in D.SUPPORT_STAGES}
            if support != {n: 'host-cpu' for n in D.SUPPORT_STAGES} or health.get('errors'):
                raise RuntimeError(f'{arm}: support stages {support} errors {health.get("errors")}')
        problem = self.prepared and G.prepared_event_problem(self.health['G'], self.prepared)
        if problem:
            raise RuntimeError(problem)
        G.check_occupancy(s, 'occupancy-ready')
        self.save('identities.json', self.ids)

    def configure(self):
        peers = {h: dict(url=self.urls[h], zone=D.ZONE[h]) for h in D.HOSTS}
        peers['S'] = dict(url=self.urls['generator'], zone=D.ZONE['S'])
        self.save('gateway-peers.json', self.control(self.urls['gateway']+'/peers', dict(peers=peers)))
        hosts = {h: dict(url=self.urls[h], pod_uid=self.ids[h]['pod_uid'], node=self.ids[h]['node'], vlm_device=EXPECTED_DEVICE[h],
                         backend=D.ARM[h], stages=qualified_stages(self.health[h], self.ids[h])) for h in D.HOSTS}
        self.save('generator-configure.json', self.control(self.urls['generator']+'/configure', dict(
            run_id=self.s.run, hosts=hosts, gateway_url=self.urls['gateway'], origin_url=self.urls['generator'])))
        manifest = json.loads((self.frozen/'assets-manifest.json').read_text())
        files = [dict(id=i['id'], path=i['path'], sha256=i['sha256']) for i in input_files(manifest)]
        self.save('generator-corpus.json', self.control(self.urls['generator']+'/corpus', dict(cache_url=self.cache_url, files=files,
                                                                                              budget_s=self.b['corpus_s']-10),
                                                        timeout=self.b['corpus_s']))
        self.npy_bytes = Path(next(i['source'] for i in manifest['inputs'] if i['id'] == D.INPUT)).stat().st_size

    def profile(self):
        body = dict(inputs=[D.INPUT], roundtrip_inputs=list(D.ALL_INPUTS), warmup=self.b['profile_warmup'], reps=self.b['profile_reps'],
                    call_s=self.b['stage_call_s'])
        result = self.job('/profile', body, 'profile', min(self.b['profile_job_s'], self.budget.remaining()))
        self.save('profile.json', result)
        if result['state'] != 'done':
            raise RuntimeError(f"profile job {result['state']}: {result.get('error')}")
        proc, sizes, problems = profile_table(result['result']['rows'], self.ids, self.s.run, self.npy_bytes)
        self.save('profile-qualification.json', dict(qualified=not problems, problems=problems, proc_ms={f'{k[0]}@{k[1]}': v for k, v in proc.items()},
                                                     sizes=sizes))
        if problems:
            raise RuntimeError(f'profile does not qualify: {problems[:5]}')
        self.proc, self.sizes = proc, sizes

    def apply_network(self, regime):
        """Each transition has its own numbered artifact names (the schedule revisits regimes; saves stay exclusive)."""
        if self.network == regime:
            return
        self.transitions += 1
        name = f'network-{self.transitions:03d}-{regime}'
        self.drain('before-'+name)
        spec = dict(D.NETWORK[regime]['net'], cloud=[self.ips[h] for h in D.SHAPED_HOSTS], edge=[])  # only the NPU Pod IP is shaped
        state = self.s.net(spec, name, self.b['net_exec_s'])
        problems = network_problems(spec, state)
        self.save(name+'.json', dict(state, ips=self.ips, problems=problems))  # actual qdisc/filters/routes/counters + netns
        if problems:
            raise RuntimeError(f'network {regime}: {problems}')
        self.network = regime

    def probes(self, regime):
        relay = D.NETWORK[regime]['relay']
        name = 'probes-'+regime
        result = self.job('/probes', dict(job=name, relay=relay, probes=chain_policy.required_probes(self.sizes), reps=self.b['probe_reps'],
                                          timeout_s=self.b['probe_timeout_s']), name, min(self.b['probe_job_s'], self.budget.remaining()))
        self.save(name+'.json', result)
        if result['state'] != 'done' or not all(p['complete'] for p in result['result']['probes']):
            raise RuntimeError(f'{name}: incomplete ({result["state"]})')
        return result['result']['probes']

    def quiescence(self):
        state, idle = {}, True
        for host in D.HOSTS:
            try:
                q = state[host] = self.control(self.urls[host]+'/run', dict(mode='queue', run_id=self.s.run, request_id='drain'))
                idle &= all(q.get(k) == 0 for k in ('waiting', 'active', 'joins_open', 'inflight'))
            except Exception as error:
                state[host], idle = dict(error=repr(error)[:200]), False
        for key, path in (('gateway', '/health'), ('generator', '/status')):
            try:
                state[key] = self.control(self.urls[key]+path)
            except Exception as error:
                state[key], idle = dict(error=repr(error)[:200]), False
        idle = idle and (state['gateway'].get('active') == 0) and state['generator'].get('busy') is False
        progress = {h: (state[h].get('completed'), state[h].get('dag_requests')) for h in D.HOSTS if 'error' not in state[h]}
        return idle, progress, state

    def drain(self, label):
        """Stable idle (no queued/active model call, no admitted dag/probe/sink request incl. forwarding, gateway relays
        nothing, generator idle) holding again after the settle interval, within drain_s; then the gateway counters are
        returned and reset. Not drained -> the run aborts (fail closed: no next request on a busy fleet)."""
        started, last = self.clock(), None
        while self.clock() - started < self.b['drain_s']:
            idle, progress, last = self.quiescence()
            if idle:
                self.sleep(self.b['settle_s'])
                again, after, last = self.quiescence()
                if again and after == progress:
                    reset = self.control(self.urls['gateway']+'/reset', dict(label=label))
                    self.save(f'drain-{label}.json', dict(idle=True, waited_s=self.clock()-started, state=last, gateway_reset=reset))
                    return reset
            self.sleep(1)
        self.save(f'drain-{label}.json', dict(idle=False, waited_s=self.clock()-started, state=last))
        raise RuntimeError(f'{label}: fleet not drained within {self.b["drain_s"]} s; run aborted')

    def fleet_check(self, label):
        for host in D.HOSTS:
            health = self.control(self.urls[host]+'/health')
            vlm = (health.get('stages') or {}).get('vlm') or {}
            if health.get('pod_uid') != self.ids[host]['pod_uid'] or health.get('status') != 'ready' or \
                    (vlm.get('process') or {}).get('state') != 'ready':
                self.save(f'fleet-{label}-{host}.json', health)
                raise RuntimeError(f'{label}: worker {host} changed/unhealthy after the request; run aborted')

    def request(self, cell):
        label, relay = cell['label'], D.NETWORK[cell['regime']]['relay']
        self.drain('before-'+label)
        body = dict(label=label, relay=relay, placement=cell['placement'], input_id=cell['input_id'], arrivals=cell['arrivals'],
                    slo_s=D.SLO_S, timeout_s=D.TIMEOUT_S, max_inflight=D.MAX_INFLIGHT, policies=cell['policies'])
        # Dispatch/collection evidence: request.json exists only once /trace is about to be sent; dispatch.json says whether
        # the generator acknowledged it; collection.json keeps the last observed state if the ledger could not be fetched.
        # The analyzer counts a scheduled request without request.json as not_sent, with it but no ledger as outcome_unknown.
        self.save(f'trace-{label}.request.json', body)
        try:
            started = self.control(self.urls['generator']+'/trace', body)
        except Exception as error:
            self.save(f'trace-{label}.dispatch.json', dict(at=utc(), acknowledged=False, error=repr(error)[:500]))
            raise
        self.save(f'trace-{label}.dispatch.json', dict(at=utc(), acknowledged=True, reply=started))
        until = self.clock() + cell['arrivals'][-1]['offset_s'] + D.TIMEOUT_S + self.b['trace_slack_s']
        state, stopped = None, False
        try:
            while self.clock() < until:
                state = self.control(self.urls['generator']+'/status')['traces'][label]
                if state['state'] != 'running':
                    break
                self.sleep(self.b['poll_s'])
            if state is None or state['state'] == 'running':
                stopped = True
                self.control(self.urls['generator']+'/stop', {})
                self.sleep(D.TIMEOUT_S / 4)
            ledger = self.control(self.urls['generator']+'/ledger?label='+label, timeout=60)
        except Exception as error:
            self.save(f'trace-{label}.collection.json', dict(at=utc(), collected=False, last_state=state, stop_sent=stopped,
                                                             error=repr(error)[:500]))
            raise
        self.save(f'ledger-{label}.json', dict(ledger, cell=cell))
        self.last_gateway = self.control(self.urls['gateway']+'/health')
        self.save(f'gateway-{label}.json', self.last_gateway)
        unaccounted = [r['index'] for r in ledger['rows'] if r.get('status') not in chain_generator.TERMINAL]
        if unaccounted or len(ledger['rows']) != len(cell['arrivals']):
            raise RuntimeError(f'{label}: unaccounted scheduled arrivals {unaccounted}')
        broken = [f"{r['index']}: {r.get('error')}"[:300] for r in ledger['rows'] if r['status'] == 'integrity_failed']
        if broken:  # fail closed: the failed row is persisted above; no further request runs (cleanup follows)
            raise RuntimeError(f'{label}: integrity_failed {broken}; run aborted')
        self.fleet_check(label)
        return ledger

    def qualify_route(self, regime):
        """Qualification gate (calibration, never evaluation): one real whole-server job per server (GGG, then NNN; never a
        mixed route) in this condition, each between gateway qdisc snapshots: intact answer, source -> server through the
        gateway, same-host local hops, gateway byte counters for that server only, and the shaped-band byte delta (only the
        N job may move the payload through the shaped band). Anything else aborts before the plans are frozen."""
        verdicts = {}
        for placement in D.PLACEMENTS:
            host = D.host_of(placement)
            cell = dict(label=f'qual-{regime}-{placement}', regime=regime, placement=placement, input_id=D.INPUT,
                        arrivals=[dict(index=0, offset_s=0.0)], policies=['qualification'])
            before = self.s.net(dict(action='snapshot'), f'net-{cell["label"]}-before', self.b['net_exec_s'])
            row = self.request(cell)['rows'][0]
            after = self.s.net(dict(action='snapshot'), f'net-{cell["label"]}-after', self.b['net_exec_s'])
            verdicts[placement] = dict(label=cell['label'], problems=route_problems(row, self.last_gateway, regime, host, before, after),
                                       shaped_band_bytes_delta=shaped_band_bytes(after) - shaped_band_bytes(before),
                                       gateway_counters=(self.last_gateway or {}).get('counters'))
        problems = [f'{p}: {x}' for p, v in verdicts.items() for x in v['problems']]
        self.save(f'qualification-{regime}.json', dict(qualified=not problems, problems=problems, placements=verdicts))
        if problems:
            raise RuntimeError(f'route qualification {regime}: {problems}')

    def execute(self):
        with collect.phase(self.s, 'preflight'):
            self.progress(phase='preflight')
            manifest = self.preflight()
        with collect.phase(self.s, 'cache'):
            self.progress(phase='cache')
            self.cache(manifest)
        with collect.phase(self.s, 'pods'):
            self.progress(phase='pods')
            self.pods()
        with collect.phase(self.s, 'identity'):
            self.identity()
            self.ips = {'S': self.s.ip('generator'), 'G': self.s.ip('cuda'), 'N': self.s.ip('mobilint')}
            self.configure()
        with collect.phase(self.s, 'profile'):
            self.progress(phase='profile')
            self.profile()
        tables, decisions, choices, evidence = {}, {}, {}, {}
        for regime in D.REGIMES:
            with collect.phase(self.s, 'calibrate-'+regime):
                self.progress(phase='calibrate-'+regime)
                self.apply_network(regime)
                probes = self.probes(regime)
                evidence[regime] = chain_policy.probe_evidence(probes)
                self.qualify_route(regime)
                tables[regime] = chain_policy.table_from(self.proc, probes)
                decisions[regime] = chain_policy.decide(tables[regime])
                choices[regime] = chain_policy.aliases(decisions[regime])
        cells = D.cells(choices, self.design['repeat_count'], self.design['measurement_blocks'])
        frozen = dict(decision_unit='whole job on one server (GGG or NNN); not DAG placement',
                      tables={r: chain_policy.table_to_json(t) for r, t in tables.items()}, decisions=decisions, aliases=choices,
                      probe_evidence=evidence, sizes=self.sizes, cells=cells)
        frozen['sha256'] = P.sha256(json.dumps(frozen, sort_keys=True).encode())
        self.save('plans.json', frozen)  # frozen before the first evaluation request
        self.progress(phase='evaluate', total=len(cells), done=0)
        for n, cell in enumerate(cells):
            with collect.phase(self.s, 'request-'+cell['label']):
                if self.budget.remaining() < D.TIMEOUT_S + self.b['drain_s'] + 2 * self.b['trace_slack_s']:
                    raise RuntimeError(f"budget exhausted before {cell['label']}; {len(cells)-n} requests not run")
                self.apply_network(cell['regime'])
                before = self.s.net(dict(action='snapshot'), f"net-{cell['label']}-before", self.b['net_exec_s'])
                ledger = self.request(cell)
                after = self.s.net(dict(action='snapshot'), f"net-{cell['label']}-after", self.b['net_exec_s'])
                self.save(f"route-{cell['label']}.json", dict(  # evaluation evidence, recorded (never used to drop the job)
                    problems=route_problems(ledger['rows'][0], self.last_gateway, cell['regime'], D.host_of(cell['placement']), before, after),
                    shaped_band_bytes_delta=shaped_band_bytes(after) - shaped_band_bytes(before)))
                statuses = dict(self.progress_state['statuses'])
                for row in ledger['rows']:
                    statuses[row['status']] = statuses.get(row['status'], 0) + 1
                self.progress(done=n+1, last=cell['label'], measurement_block=cell['measurement_block'], regime=cell['regime'],
                              statuses=statuses)
        with collect.phase(self.s, 'final'):
            G.check_occupancy(self.s, 'occupancy-final')
            for host in D.HOSTS:
                self.save(f'health-final-{D.ARM[host]}.json', self.control(self.urls[host]+'/health'))
        self.progress(phase='done')


def qualified_stages(health, identity):
    """Per-request expected stage identity from the /health verified at identity time: dag_worker.slim's static_sha256 of
    each loaded stage description and its model hash (T2: the contract weights G.identity verified; T1/T3: None)."""
    out = {}
    for stage in D.STAGES:
        description = health['stages'][stage]
        out[stage] = dict(static_sha256=chain_generator.static_sha256(description), model_sha256=description.get('model_sha256'))
    if out['vlm']['model_sha256'] != identity['model_sha256']:
        raise RuntimeError('vlm model_sha256 in /health differs from the verified identity')
    return out


TBF_SHAPED_PARENT = 0x10001  # net_control: band 1 (cloud = SHAPED_HOSTS) tbf under prio class 1:1
PRIO_ROOT = 0x10000


def shaped_band_bytes(snapshot):
    """Bytes the shaped band's tbf has dequeued (0 when no shaping qdisc exists)."""
    return sum(q['bytes'] for q in (snapshot or {}).get('qdisc_summary') or [] if q.get('kind') == 'tbf' and q.get('parent') == TBF_SHAPED_PARENT)


def network_problems(spec, state):
    """The owned gateway netns after net_control: the echoed spec, a namespace id, and the qdisc tree the condition needs
    (npu_slow2: prio root + a tbf under the shaped band 1:1; relay: no prio root)."""
    problems = [] if state.get('spec') == spec else [f"net_control echoed {state.get('spec')} for {spec}"]
    if not state.get('netns'):
        problems.append('gateway netns not recorded')
    summary = state.get('qdisc_summary') or []
    prio = any(q.get('handle') == PRIO_ROOT and q.get('kind') == 'prio' for q in summary)
    tbf = any(q.get('kind') == 'tbf' and q.get('parent') == TBF_SHAPED_PARENT for q in summary)
    if spec['mbps'] is not None and not (prio and tbf):
        problems.append(f'shaped condition lacks prio root / shaped-band tbf: {summary}')
    if spec['mbps'] is None and prio:
        problems.append('unshaped condition still has the prio shaping root')
    return problems


def route_problems(row, gateway, regime, host, before, after):
    """Qualification of one whole-server job on `host` (GGG or NNN): intact answer; source -> server through the owned
    gateway; both stage hops same-host direct (no inter-server hop); receipts from one Pod; gateway counters (reset by the
    drain just before) showing exactly one error-free relayed request to `host` carrying at least the source payload and
    nothing to the other server; the shaped band moved at least the payload for N under shaping and less than the payload
    otherwise (so a bypass or a misclassified destination cannot produce a fake network result)."""
    problems = [] if row.get('status') in ('ok', 'late_ok') else [f"status {row.get('status')}: {row.get('error')}"[:500]]
    hops, payload = row.get('hops') or [], row.get('first_payload_bytes')
    if row.get('first_route') != 'gateway':
        problems.append(f"first route {row.get('first_route')!r}, expected 'gateway'")
    if [h.get('route') for h in hops] != ['direct', 'direct']:
        problems.append(f"hop routes {[h.get('route') for h in hops]}, expected ['direct', 'direct']")
    if [(h.get('src'), h.get('dst')) for h in hops] != [(host, host)] * 2:
        problems.append(f"hops {[(h.get('src'), h.get('dst')) for h in hops]} are not same-host on {host}")
    if len({r.get('pod_uid') for r in row.get('receipts') or []}) != 1:
        problems.append('receipts are not from one server Pod')
    counters = {k: v for k, v in ((gateway or {}).get('counters') or {}).items() if v.get('requests')}
    if not gateway or gateway.get('active') != 0:
        problems.append(f"gateway not observed idle after the request: {gateway and gateway.get('active')}")
    if set(counters) != {host}:
        problems.append(f'gateway relayed to {sorted(counters)}, expected [{host}]')
    c = counters.get(host) or {}
    if c.get('requests') != 1 or c.get('errors') or c.get('timeouts') or not payload or c.get('request_body_bytes', 0) < payload:
        problems.append(f'gateway counter to {host} {c} does not show the source payload {payload} B')
    delta = shaped_band_bytes(after) - shaped_band_bytes(before)
    shaped = D.NETWORK[regime]['net']['mbps'] is not None and host in D.SHAPED_HOSTS
    if shaped and (not payload or delta < payload):
        problems.append(f'shaped band moved {delta} B, expected at least the {payload} B payload toward {host}')
    if not shaped and payload and delta >= payload:
        problems.append(f'shaped band moved {delta} B for an unshaped {host} job')
    return problems


def profile_table(rows, ids, run, npy_bytes):
    """Profile rows -> (proc {(stage, host): median measured worker_wall_ms}, sizes, problems). Every row must be ok and its
    receipt the verified worker's (UID/node/device/run); all four inputs must have passed the in-Pod T1 roundtrip on both
    hosts; T2 must have answered the frozen input id; every (stage, host) needs measured rows (a raw worker_wall_ms that is
    not a finite positive int/float is a problem, never converted); payload sizes must agree."""
    problems, proc, outs = [], {}, {}
    for r in rows:
        rec = r.get('receipt') or {}
        if r.get('status') != 'ok' or not rec:
            problems.append(f"{r['request_id']}: {r.get('status')} {r.get('error', '')}"[:300])
            continue
        want = dict(pod_uid=ids[r['host']]['pod_uid'], node=ids[r['host']]['node'], run_id=run, request_id=r['request_id'], stage=r['stage'],
                    device=ids[r['host']]['device'] if r['stage'] == 'vlm' else 'host-cpu', input_sha256=r['input_sha256'],
                    output_sha256=r['output_sha256'])
        wrong = [k for k, v in want.items() if rec.get(k) != v]
        if wrong:
            problems.append(f"{r['request_id']}: receipt {wrong}")
        timing = rec.get('timing') or {}
        if r['stage'] == 'image_pack' and timing.get('roundtrip_identical') is not True:
            problems.append(f"{r['request_id']}: T1 roundtrip not identical")
        if r['stage'] == 'vlm' and (timing.get('input_id') != D.INPUT or rec.get('model_sha256') != ids[r['host']]['model_sha256']):
            problems.append(f"{r['request_id']}: T2 input/model {timing.get('input_id')}")
        if r.get('purpose') == 'profile' and not r['warmup']:
            if not chain_policy.is_measurement(rec.get('worker_wall_ms')):  # raw value, before any conversion: fail closed
                problems.append(f"{r['request_id']}: worker_wall_ms={rec.get('worker_wall_ms')!r} is not a finite positive measurement"[:300])
                continue
            proc.setdefault((r['stage'], r['host']), []).append(float(rec['worker_wall_ms']))
            outs.setdefault((r['stage'], r['host']), set()).add(r['output_bytes'])
    roundtrip = {(r['input_id'], r['host']) for r in rows if r.get('purpose') == 'roundtrip' and r.get('status') == 'ok'
                 and ((r.get('receipt') or {}).get('timing') or {}).get('roundtrip_identical') is True}
    problems += [f'{i}@{h}: roundtrip missing' for i in D.ALL_INPUTS for h in D.HOSTS if (i, h) not in roundtrip]
    missing = [f'{s}@{h}' for s in D.STAGES for h in D.HOSTS if (s, h) not in proc]
    problems += [f'{m}: no measured profile row' for m in missing]
    if missing:
        return {}, {}, problems
    sizes = dict(npy=npy_bytes)
    for kind, stage in (('png', 'image_pack'), ('vlm', 'vlm'), ('final', 'result_format')):
        sizes[kind] = {}
        for h in D.HOSTS:
            if len(outs[(stage, h)]) != 1:
                problems.append(f'{stage}@{h}: output sizes differ across calls {sorted(outs[(stage, h)])}')
            sizes[kind][h] = max(outs[(stage, h)])
    return {k: statistics.median(v) for k, v in proc.items()}, sizes, problems


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--frozen', default=str(DEFAULTS['frozen']))
    ap.add_argument('--prepared', default=DEFAULTS['prepared'], help='old prepared CUDA mode only (needs --cuda-cache-pvc)')
    ap.add_argument('--cuda-cache-pvc', default=DEFAULTS['pvc'])
    ap.add_argument('--io-profile', default=DEFAULTS['io_profile'], choices=(C.SD_PROFILE['name'],))
    ap.add_argument('--repeat-count', type=int, default=D.REPEAT_COUNT)
    ap.add_argument('--measurement-blocks', type=int, default=D.MEASUREMENT_BLOCKS)
    ap.add_argument('--runs')
    ap.add_argument('--release')
    ap.add_argument('--run-id', default='gmp-'+datetime.now(timezone.utc).strftime('%Y%m%dt%H%M%S'))
    mode = ap.add_mutually_exclusive_group()
    mode.add_argument('--print-release-draft', action='store_true')
    mode.add_argument('--plan', action='store_true')
    mode.add_argument('--dry-run', action='store_true')
    a = ap.parse_args(argv)
    if (a.repeat_count, a.measurement_blocks) != (1, 1):
        raise SystemExit('repeat-count and measurement-blocks must be 1 (at most one main job per condition and server)')
    if bool(a.prepared) != bool(a.cuda_cache_pvc) or (a.io_profile and not a.prepared):
        raise SystemExit('--prepared and --cuda-cache-pvc go together; --io-profile needs --prepared')
    full = not a.plan
    prepared = a.prepared and G.load_prepared(a.prepared, a.frozen, json.loads(Path(a.cuda_cache_pvc).read_text()),
                                              hash_tar=full and not a.print_release_draft, io_profile_name=a.io_profile)
    if a.plan:
        print(json.dumps(dict(design=D.design_dict(repeat_count=a.repeat_count, measurement_blocks=a.measurement_blocks),
                              manifests=plan('gmp-plan', a.frozen, prepared, D.BUDGETS['campaign_s'])), indent=1))
        return
    draft = release_draft(a.frozen, prepared, a.repeat_count, a.measurement_blocks)
    if a.print_release_draft:
        print(json.dumps(draft, indent=1))
        return
    if not a.release:
        raise SystemExit('--release is required')
    release = json.loads(Path(a.release).read_text())
    problems = release_problems(release, draft)
    if problems:
        raise SystemExit('release check failed (no kubectl was run): '+'; '.join(problems))
    if a.dry_run:
        print(json.dumps(dict(release='ok', design_sha256=draft['design_sha256'], code_files=len(draft['code'])), indent=1))
        return
    if not a.runs:
        raise SystemExit('--runs is required')
    session = Session(a.runs, a.run_id)
    session.save('release.json', release)
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(SystemExit('SIGTERM')))
    run, error = Run(session, a.frozen, prepared, release), None
    try:
        run.execute()
    except BaseException as exc:  # SIGINT (KeyboardInterrupt) and SIGTERM included: cleanup below always runs
        error = repr(exc)
        run.progress(phase='aborted', error=error[:500])
        raise
    finally:
        problems = ['cleanup did not run']
        try:
            with collect.phase(session, 'cleanup'):
                session.delete_owned('cleanup', [r['name'] for r in session.resources])
                problems = verify_cleanup(session)
                collect.protected_snapshot(session, 'protected-after')
        except BaseException as exc:
            problems.append(f'cleanup error {exc!r}'[:500])
        finally:
            session.save('cleanup.json', dict(records=session.resources, unresolved=session.unresolved, error=error, problems=problems,
                                              verified=not problems))
            run.progress(cleanup_verified=not problems)
        if error is None and problems:
            raise SystemExit('run not complete: '+'; '.join(problems))


if __name__ == '__main__':
    main()
