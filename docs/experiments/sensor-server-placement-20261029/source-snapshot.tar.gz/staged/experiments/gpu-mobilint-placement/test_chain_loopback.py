"""Nested real loopback chain: two real chain_worker processes-in-threads (unchanged dag_worker/worker lanes, real T1/T3 and
the real PNG->NPY adapter), the unchanged gateway relay and the real edge source over localhost HTTP with the actual
frozen input bytes. The VLM is a plumbing stand-in (input hash check + optional delay/failure) -- never accelerator evidence.
2026-10-29: whole-server scope, so the former mixed GNG chains are whole-server NNN jobs (S -> N through the gateway).

Run (repo root):
  PYTHONPATH=experiments/gpu-mobilint-placement:experiments/quality-network-baselines:experiments/quality-network-heterogeneous:experiments/real-topology-live \
    .scratch/gpu-mobilint-vlm-20261028/env/mblt-x86/bin/python -m unittest -v test_chain_loopback
"""
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading
import time
import unittest

import bounded_http
import chain_design as D
import chain_generator as CG
import chain_stages
import chain_worker
import gateway
from test_chain import FROZEN, StandInVlm, frozen


class Controlled(StandInVlm):
    delay, fail = 0.0, False

    def run(self, data):
        time.sleep(self.delay)
        if self.fail:
            raise RuntimeError('stand-in VLM failure')
        return super().run(data)


def serve(server):
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return f'http://127.0.0.1:{server.server_address[1]}'


class Loopback(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp())
        (cls.tmp/'models').mkdir()
        shutil.copy(FROZEN/'contract.json', cls.tmp/'contract.json')
        contract, cls.inputs = frozen()
        cls.vlm = {'G': Controlled(contract, 'cuda:0', 'cuda'), 'N': Controlled(contract, 'npu:aries-rb', 'mobilint')}
        cls.saved = chain_stages.vlm_load
        chain_stages.vlm_load = lambda backend, model_root: cls.vlm['G' if backend == 'cuda' else 'N']
        cls.workers, cls.urls, cls.servers = {}, {}, []
        for host, backend in (('G', 'cuda'), ('N', 'mobilint')):
            os.environ.update(NODE_NAME=f'node-{host}', POD_UID=f'uid-{host}')  # identity is read once per Worker
            cls.workers[host] = chain_worker.Worker(backend, list(D.STAGES), model_root=str(cls.tmp/'models'))
            server = chain_worker.serve(cls.workers[host], host='127.0.0.1', port=0)
            cls.servers.append(server)
            cls.urls[host] = serve(server)
        relay = gateway.Relay(allowed_prefixes=('http://127.',))
        cls.gateway_server = gateway.serve(relay, host='127.0.0.1', port=0)
        cls.gateway_url = serve(cls.gateway_server)
        cls.gen = CG.Generator()
        cls.gen_server = CG.serve(cls.gen, host='127.0.0.1', port=0)
        cls.gen_url = serve(cls.gen_server)
        bounded_http.post(cls.gateway_url+'/peers', dict(peers={'G': dict(url=cls.urls['G'], zone=D.ZONE['G']), 'N': dict(url=cls.urls['N'], zone=D.ZONE['N']),
                                                                'S': dict(url=cls.gen_url, zone=D.ZONE['S'])}), timeout=5)
        cls.configure(cls.gen, cls.urls['N'])
        cls.servers += [cls.gateway_server, cls.gen_server]

    @classmethod
    def configure(cls, gen, n_url):
        hosts = {'G': dict(url=cls.urls['G'], pod_uid='uid-G', node='node-G', vlm_device='cuda:0', backend='cuda'),
                 'N': dict(url=n_url, pod_uid='uid-N', node='node-N', vlm_device='npu:aries-rb', backend='mobilint')}
        for host, h in hosts.items():  # the collector's qualified_stages, from the workers' own /health
            health = bounded_http.control(cls.urls[host]+'/health', timeout=5)
            h['stages'] = {s: dict(static_sha256=CG.static_sha256(d), model_sha256=d.get('model_sha256')) for s, d in health['stages'].items()}
        gen.configure(dict(run_id='gmp-test', hosts=hosts, gateway_url=cls.gateway_url, origin_url=cls.gen_url))
        gen.inputs[D.INPUT] = cls.inputs[D.INPUT]

    @classmethod
    def tearDownClass(cls):
        chain_stages.vlm_load = cls.saved
        for server in cls.servers:
            server.shutdown()

    def setUp(self):
        for v in self.vlm.values():
            v.delay, v.fail = 0.0, False

    def trace(self, gen, label, placement, relay=True, offsets=(0.0,), timeout_s=10.0, stop_after=None, max_inflight=1):
        gen.start_trace(dict(label=label, relay=relay, placement=placement, input_id=D.INPUT, slo_s=5.0, timeout_s=timeout_s,
                             max_inflight=max_inflight, arrivals=[dict(index=i, offset_s=o) for i, o in enumerate(offsets)]))
        if stop_after is not None:
            time.sleep(stop_after)
            gen.stop_flag.set()
        deadline = time.monotonic() + 60
        while gen.traces[label]['state'] == 'running' and time.monotonic() < deadline:
            time.sleep(0.05)
        ledger = gen.ledger(label)
        self.assertEqual(ledger['state'], 'done')
        self.assertEqual(len(ledger['rows']), len(offsets))
        self.assertTrue(all(r['status'] in CG.TERMINAL for r in ledger['rows']))  # every scheduled arrival accounted
        return ledger['rows']

    def drained(self):
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            q = [bounded_http.post(self.urls[h]+'/run', dict(mode='queue', run_id='gmp-test', request_id='drain'), timeout=5) for h in 'GN']
            if all(x['inflight'] == 0 and x['waiting'] == 0 and x['active'] == 0 for x in q):
                return True
            time.sleep(0.05)
        return False

    def test_relay_chain_crosses_gateway_with_linked_actual_bytes(self):
        row, = self.trace(self.gen, 'relay-nnn', 'NNN')
        self.assertEqual(row['status'], 'ok', row.get('error'))
        self.assertEqual([r['stage'] for r in row['receipts']], list(D.STAGES))
        self.assertEqual([r['pod_uid'] for r in row['receipts']], ['uid-N', 'uid-N', 'uid-N'])
        self.assertEqual([r['device'] for r in row['receipts']], ['host-cpu', 'npu:aries-rb', 'host-cpu'])
        self.assertEqual(row['first_payload_bytes'], 818048)
        self.assertEqual([h['payload_bytes'] for h in row['hops']][0], 593966)
        self.assertEqual([(h['src'], h['dst'], h['route']) for h in row['hops']], [('N', 'N', 'direct')] * 2)  # same-host local HTTP
        self.assertEqual(row['first_route'], 'gateway')  # S (edge) -> N (cloud) crosses zones through the owned gateway
        self.assertEqual(json.loads(row['text'] and '"ok"'), 'ok')
        self.assertTrue(self.drained())

    def test_native_self_forwarding_on_one_host(self):
        for placement in ('NNN', 'GGG'):
            row, = self.trace(self.gen, 'native-'+placement, placement, relay=False)
            self.assertEqual(row['status'], 'ok', row.get('error'))
            self.assertEqual({h['route'] for h in row['hops']}, {'direct'})
        self.assertTrue(self.drained())

    def test_error_classes_stay_in_the_denominator(self):
        self.vlm['N'].delay = 2.5
        row, = self.trace(self.gen, 'timeout', 'NNN', timeout_s=1.5)
        self.assertEqual((row['status'], row['deadline_met']), ('timeout', False))
        self.assertIsNotNone(row['latency_ms'])
        self.assertTrue(self.drained())  # the nonpreemptive stand-in call finished and every forward unwound
        self.vlm['N'].delay = 0.0
        self.vlm['N'].fail = True
        row, = self.trace(self.gen, 'failed', 'NNN')
        self.assertEqual(row['status'], 'failed')
        self.vlm['N'].fail = False
        self.vlm['N'].delay = 0.8
        rows = self.trace(self.gen, 'drop', 'NNN', offsets=(0.0, 0.1))
        self.assertEqual([r['status'] for r in rows], ['ok', 'admission_drop'])
        self.vlm['N'].delay = 0.0
        rows = self.trace(self.gen, 'stopped', 'NNN', offsets=(0.0, 3.0), stop_after=1.0)
        self.assertEqual([r['status'] for r in rows], ['ok', 'not_sent'])
        self.assertTrue(self.drained())

    def test_queue_deadline_prevents_expired_start(self):
        """Three simultaneous requests on one accelerator lane: the first fits, the second starts before its deadline and
        overruns it (nonpreemptive, drained afterwards), the third is still queued at its deadline and is never started."""
        self.vlm['N'].delay = 1.0
        before = len(self.vlm['N'].calls)
        rows = self.trace(self.gen, 'queued', 'NNN', offsets=(0.0, 0.0, 0.0), timeout_s=2.0, max_inflight=3)
        self.assertEqual(sorted(r['status'] for r in rows), ['ok', 'timeout', 'timeout'])
        self.assertTrue(self.drained())
        self.assertEqual(len(self.vlm['N'].calls) - before, 2)
        self.assertTrue(any('queue_deadline_expired' in str(r.get('error')) for r in rows), [r.get('error') for r in rows])

    def test_worker_rejected_and_integrity_failed(self):
        # explicit codes: 503 admission / 429 gateway slots -> worker_rejected; 504 inner budget -> timeout
        self.assertEqual([CG.classify_http(503, 'worker at admission capacity'), CG.classify_http(429, 'slots'),
                          CG.classify_http(504, 'forward_timeout'), CG.classify_http(500, 'boom')],
                         ['worker_rejected', 'worker_rejected', 'timeout', 'failed'])
        # a real admission-full worker answers 503 before reading the 818 KB body; the sender then sees a reset, not the
        # 503, so the request is a non-success terminal state (worker_rejected or failed), never dropped from the denominator
        rejecting = chain_worker.serve(self.workers['N'], host='127.0.0.1', port=0, max_active=0)
        self.servers.append(rejecting)
        gen = CG.Generator()
        self.configure(gen, serve(rejecting))
        row, = self.trace(gen, 'rejected', 'NNN', relay=False)
        self.assertIn(row['status'], ('worker_rejected', 'failed'))
        self.assertFalse(row['deadline_met'])

        def tamper(url, body, timeout=60, max_body=None):
            reply = bounded_http.post(url, body, timeout=timeout)
            if body.get('mode') == 'dag' and reply.get('receipts'):
                reply['receipts'][1]['input_sha256'] = '0' * 64
            return reply
        gen = CG.Generator(post=tamper)
        self.configure(gen, self.urls['N'])
        row, = self.trace(gen, 'tampered', 'NNN')
        self.assertEqual(row['status'], 'integrity_failed')
        self.assertIn('vlm input_sha256', row['error'])


if __name__ == '__main__':
    unittest.main()
