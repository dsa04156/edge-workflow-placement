"""Frozen design of the whole-server sensor job selection (GPU server vs Mobilint NPU server; stdlib only; collector, analyzer, tests).

Corrected scope (user, 2026-10-29): observe actual processing performance AND network speed, then place the WHOLE sensor-data
processing job on ONE server. No inter-server stage partitioning: the only placements are GGG and NNN. This is a whole-server
decision, NOT DAG placement or DAG optimization; the reviewed three-stage chain executor is reused only as the implementation
of one colocated job (its same-host stage hops are local HTTP on that server).

One job (one request = the frozen input image + its frozen question):
  source S (edge dev0003) -raw NPY-> [ image_pack -PNG-> vlm -VLM JSON-> result_format ] on G or N -final JSON-> S
Hosts: G = ser0003 GB10 server GPU (Qwen3-VL-2B-Instruct BF16 on CUDA), N = ser0004 (vendor W4V8 MXQ Qwen3-VL-2B on Mobilint ARIES).
image_pack/result_format are host-CPU support work on the chosen server; only vlm runs neural inference (CUDA or Mobilint,
never CPU). Different precisions (BF16 vs W4V8): no same-precision or quality-equivalence claim; quality is not evaluated.

Network conditions (both through the SAME owned gateway Pod for both servers; S is zone 'edge', G and N zone 'cloud'):
  relay      unshaped gateway control (no qdisc).
  npu_slow2  the unchanged real-topology-live net_control.py with cloud=[N Pod IP], edge=[]: one kernel 2 Mbit/s tbf on the
             gateway egress ONLY toward the owned NPU Pod; every other destination (G, the source replies) stays in the
             default prio band, unshaped. A shaping of an owned gateway netns, never a measured physical WAN/topology.
Calibration (profile, probes, colocated route qualification) per condition, then cost tables, decisions and the whole schedule
are frozen; evaluation runs one request per unique selected server per condition (at most MAX_MAIN_JOBS main jobs).
"""
import hashlib
import itertools
import json
import random

EXPERIMENT = 'gpu-mobilint-placement'
SEED = 20261029
STAGES = ('image_pack', 'vlm', 'result_format')
SUPPORT_STAGES = ('image_pack', 'result_format')
HOSTS = ('G', 'N')                       # deterministic tie order everywhere: G before N
ORIGIN = 'S'
ARM = {'G': 'cuda', 'N': 'mobilint'}     # gpu-mobilint-vlm protocol.ARMS keys
ZONE = {'S': 'edge', 'G': 'cloud', 'N': 'cloud'}
ORIGIN_NODE = 'etri-dev0003-raspi5'
PRECISION = {'G': 'Qwen/Qwen3-VL-2B-Instruct@89644892 BF16 on cuda:0 (torch)',
             'N': 'mobilint/Qwen3-VL-2B-Instruct@f4be563 W4V8 MXQ (vision+text) on ARIES via qbruntime'}
PLACEMENTS = tuple(h * len(STAGES) for h in HOSTS)  # GGG, NNN only: the whole job on one server

INPUT = 'cal-3733440'                     # 426x640 RGB uint8, raw NPY 818048 B
ALL_INPUTS = ('smoke-1713820', 'cal-3733440', 'cal-4556100', 'cal-3355890')  # all pass the in-Pod T1 roundtrip check

REGIMES = ('relay', 'npu_slow2')
NETWORK = {
    'relay': dict(relay=True, net=dict(action='shape', mbps=None, delay_ms=0),
                  label='unshaped gateway control (source -> G and source -> N both via the owned gateway, no qdisc)'),
    'npu_slow2': dict(relay=True, net=dict(action='shape', mbps=2, delay_ms=0),
                      label='same gateway path; kernel 2 Mbit/s tbf on the gateway egress toward the owned NPU Pod IP only'),
}
SHAPED_HOSTS = ('N',)  # net_control cloud=[these Pod IPs], edge=[]; G and the source replies stay in the default band
SLO_S = 5.0          # diagnostic SLO (deadline_met)
TIMEOUT_S = 40.0     # absolute request cancel budget from the scheduled arrival
MAX_INFLIGHT = 1     # sequential requests
REPEAT_COUNT = 1     # sequential requests per unique placement per regime per measurement block (release-bound)
MEASUREMENT_BLOCKS = 1  # temporal blocks over all regimes inside the same Pods (release-bound)
# No predeclared significance comparison: one observation per (condition, server), descriptive only.
PRIMARY = None
SECONDARY = None
MAX_MAIN_JOBS = len(REGIMES) * len(HOSTS)  # fixed_gpu/fixed_npu force both servers in each condition

POLICIES = ('fixed_gpu', 'fixed_npu', 'compute_only', 'compute_network')

BUDGETS = dict(
    campaign_s=30 * 60 + 900,    # whole run wall budget (30 min work + cleanup reserve); every Pod lifetime derives from it
    cleanup_reserve_s=900,       # kept at the end of the budget for UID-owned cleanup and verification
    helper_ready_s=300,          # gateway/generator readiness
    upload_s=1800,
    control_timeout_s=30,
    control_max_body_bytes=16 * 1024 * 1024,
    corpus_s=300,
    profile_warmup=1,            # warm qualification call per (stage, host, variant), kept and labelled, never a cost
    profile_reps=1,              # measured profile calls per (stage, host, variant)
    profile_job_s=1800,
    stage_call_s=320,            # one profiling call (VlmStage call deadline 300 s + margin)
    probe_reps=1,
    probe_timeout_s=60,
    probe_job_s=900,
    drain_s=90,                  # drain barrier before every request / regime change; failure aborts the run
    settle_s=2,
    poll_s=1,
    trace_slack_s=30,
    dag_max_active=96,           # worker HTTP admission (existing nested-forwarding baseline)
    gateway_upstream_cap_s=60,
    gateway_slots=96,
    net_exec_s=60,
)


def host_of(placement):
    """GGG -> G, NNN -> N; anything else (a mixed or malformed placement) is refused."""
    if placement not in PLACEMENTS:
        raise ValueError(f'placement {placement!r} refused: the whole job on one server (only {PLACEMENTS})')
    return placement[0]


def regime_orders(measurement_blocks):
    """Counterbalanced regime order per measurement block: the permutations in a seeded order, reused cyclically."""
    perms = list(itertools.permutations(REGIMES))
    random.Random(f'{SEED}-regime-orders').shuffle(perms)
    return [list(perms[(m - 1) % len(perms)]) for m in range(1, measurement_blocks + 1)]


def cells(choices, repeat_count=REPEAT_COUNT, measurement_blocks=MEASUREMENT_BLOCKS):
    """choices[regime] = {placement: [policy labels]} (chain_policy.aliases of that regime's frozen table). The complete
    frozen evaluation schedule: one request per cell. Per measurement block the regimes follow regime_orders(); inside a
    regime the unique placements follow a seeded shuffle (SEED, block, regime) and the REPEAT_COUNT requests interleave
    round-robin over them. Aliases ride as labels of the same observation. Nothing here depends on any result. Only whole-
    server placements are schedulable and at most MAX_MAIN_JOBS main jobs exist."""
    for regime_choices in choices.values():
        for placement in regime_choices:
            host_of(placement)
    out = []
    for m, order in enumerate(regime_orders(measurement_blocks), 1):
        for regime in order:
            unique = sorted(choices[regime].items())
            random.Random(f'{SEED}-{m}-{regime}').shuffle(unique)
            for r in range(1, repeat_count + 1):
                for placement, labels in unique:
                    out.append(dict(measurement_block=m, repeat=r, regime=regime, input_id=INPUT, placement=placement,
                                    policies=sorted(labels), arrivals=[dict(index=0, offset_s=0.0)]))
    if len(out) > MAX_MAIN_JOBS:
        raise ValueError(f'{len(out)} main jobs scheduled; at most {MAX_MAIN_JOBS} (one per condition and server)')
    for n, cell in enumerate(out):
        cell['label'] = f"c{n:04d}-m{cell['measurement_block']}-{cell['regime']}-{cell['placement']}-r{cell['repeat']}"
    return out


def design_dict(repeat_count=REPEAT_COUNT, measurement_blocks=MEASUREMENT_BLOCKS):
    """Everything the release binds besides code/assets: the conditions fixed before any result."""
    return dict(experiment=EXPERIMENT, seed=SEED, stages=STAGES, support_stages=SUPPORT_STAGES, hosts=HOSTS, arm=ARM, zone=ZONE,
                origin_node=ORIGIN_NODE, precision=PRECISION, placements=PLACEMENTS, input=INPUT, all_inputs=ALL_INPUTS,
                regimes=REGIMES, network=NETWORK, shaped_hosts=SHAPED_HOSTS, max_main_jobs=MAX_MAIN_JOBS,
                decision_unit='whole job on one server (GGG or NNN); not DAG placement', slo_s=SLO_S, timeout_s=TIMEOUT_S, max_inflight=MAX_INFLIGHT, policies=POLICIES,
                primary=PRIMARY, secondary=SECONDARY, budgets=BUDGETS, process_blocks=1, repeat_count=repeat_count, measurement_blocks=measurement_blocks)


def design_sha256(**kw):
    return hashlib.sha256(json.dumps(design_dict(**kw), sort_keys=True).encode()).hexdigest()
