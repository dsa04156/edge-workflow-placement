"""Whole-server sensor job selection (2026-10-29 corrected scope; no cluster): the entire image_pack/VLM/result_format job runs
on ONE server (GGG or NNN), never split across servers. Fixed cost fixtures only; no accelerator or network evidence.

Run (this directory):
  PYTHONPATH=.:../quality-network-baselines:../quality-network-heterogeneous:../real-topology-live \
    ../../../../gpu-mobilint-vlm-20261028/env/mblt-x86/bin/python -m unittest -v test_whole_server
"""
import json
import math
import tempfile
import unittest
from unittest import mock

import chain_live as L  # first: puts the staged sibling experiments on sys.path
import chain_analyze as A  # noqa: E402
import chain_design as D  # noqa: E402
import chain_generator as CG  # noqa: E402
import chain_policy as CP  # noqa: E402

NPY = 818048


def fixture(proc_g, proc_n, local_g, local_n, net_g, net_n):
    """proc_*: (T1, T2, T3) ms; local_*: (T1->T2, T2->T3) same-host HTTP ms; net_*: source -> server probe RTT ms."""
    proc, link = {}, {(D.ORIGIN, 'G', 0): net_g, (D.ORIGIN, 'N', 0): net_n}
    for host, values, local in (('G', proc_g, local_g), ('N', proc_n, local_n)):
        proc.update({(stage, host): v for stage, v in zip(D.STAGES, values)})
        link[(host, host, 1)], link[(host, host, 2)] = local
    return dict(proc=proc, link=link)


# processing: G 20+900+5 + 3+2 = 930, N 15+700+4 + 3+2 = 724  -> compute_only NNN
# relay:      + net G 40, N 45   -> G 970, N 769               -> compute_network NNN (no flip)
# npu_slow2:  + net G 40, N 3400 -> G 970, N 4124              -> compute_network GGG (genuine flip)
RELAY = fixture((20, 900, 5), (15, 700, 4), (3, 2), (3, 2), 40, 45)
SLOW = fixture((20, 900, 5), (15, 700, 4), (3, 2), (3, 2), 40, 3400)


def mirrored(table):
    swap = {'G': 'N', 'N': 'G', 'S': 'S'}
    return dict(proc={(s, swap[h]): v for (s, h), v in table['proc'].items()},
                link={(swap[a], swap[b], e): v for (a, b, e), v in table['link'].items()})


class ColocatedOnly(unittest.TestCase):
    def test_design_has_only_whole_server_placements_and_four_policies(self):
        self.assertEqual(D.PLACEMENTS, ('GGG', 'NNN'))
        self.assertEqual(D.POLICIES, ('fixed_gpu', 'fixed_npu', 'compute_only', 'compute_network'))
        self.assertEqual(D.REGIMES, ('relay', 'npu_slow2'))
        self.assertEqual([D.host_of(p) for p in D.PLACEMENTS], ['G', 'N'])
        for mixed in ('GNG', 'GGN', 'NNG', 'GN', 'GGGG', 'SSS', ''):
            with self.assertRaisesRegex(ValueError, 'whole job on one server'):
                D.host_of(mixed)

    def test_policy_boundary_refuses_mixed_placements(self):
        for mixed in ('GNG', 'NGN', 'GGN'):
            with self.assertRaisesRegex(CP.PolicyError, 'whole job on one server'):
                CP.parts(RELAY, mixed)
        with mock.patch.object(CP, 'choose', return_value=('GNN', False)):
            with self.assertRaisesRegex(CP.PolicyError, 'whole job on one server'):
                CP.decide(RELAY)

    def test_schedule_boundary_refuses_mixed_placements(self):
        with self.assertRaisesRegex(ValueError, 'whole job on one server'):
            D.cells({'relay': {'GNN': ['x']}, 'npu_slow2': {'GGG': ['y']}})

    def test_generator_entry_refuses_mixed_trace_and_inter_server_probe(self):
        gen = CG.Generator(post=mock.Mock(side_effect=AssertionError('nothing may be sent')))
        gen.config = dict(run_id='r', hosts={}, gateway_url='http://gw', origin_url='http://s')
        gen.inputs[D.INPUT] = b'x'
        for placement in ('GNG', 'GGN', 'NNG'):
            with self.assertRaisesRegex(ValueError, 'whole job on one server'):
                gen.start_trace(dict(label='t-'+placement, relay=True, placement=placement, input_id=D.INPUT, slo_s=5, timeout_s=40,
                                     max_inflight=1, arrivals=[dict(index=0, offset_s=0.0)]))
        self.assertEqual(gen.traces, {})
        for probe in (dict(src='G', dst='N', edge=1, bytes=10), dict(src='N', dst='G', edge=2, bytes=10), dict(src='S', dst='S', edge=0, bytes=1)):
            with self.assertRaisesRegex(ValueError, 'inter-server|source'):
                gen.start_probes(dict(job='p', relay=True, probes=[probe], reps=1, timeout_s=5))
        self.assertEqual(gen.jobs, {})
        self.assertFalse(hasattr(gen, 'two_flow'))

    def test_required_probes_are_source_to_server_and_same_host_only(self):
        probes = CP.required_probes(dict(npy=NPY, png={'G': 593966, 'N': 593970}, vlm={'G': 700, 'N': 710}))
        self.assertEqual(sorted((p['src'], p['dst'], p['edge']) for p in probes),
                         sorted([('S', 'G', 0), ('S', 'N', 0), ('G', 'G', 1), ('N', 'N', 1), ('G', 'G', 2), ('N', 'N', 2)]))
        self.assertEqual({p['bytes'] for p in probes if p['edge'] == 1 and p['src'] == 'N'}, {593970})
        with self.assertRaisesRegex(CP.PolicyError, 'inter-server'):
            CP.table_from(RELAY['proc'], [dict(src='G', dst='N', edge=1, median_ms=1.0)])


class Choices(unittest.TestCase):
    def test_processing_only_vs_processing_plus_network_genuine_flip(self):
        relay, slow = CP.decide(RELAY), CP.decide(SLOW)
        got = lambda d: {p: c['placement'] for p, c in d['choices'].items()}
        self.assertEqual(got(relay), dict(fixed_gpu='GGG', fixed_npu='NNN', compute_only='NNN', compute_network='NNN'))
        self.assertEqual(got(slow), dict(fixed_gpu='GGG', fixed_npu='NNN', compute_only='NNN', compute_network='GGG'))
        self.assertEqual((slow['processing_ms'], slow['network_ms']), ({'GGG': 930, 'NNN': 724}, {'GGG': 40, 'NNN': 3400}))
        self.assertEqual(slow['predicted_ms'], {'GGG': 970, 'NNN': 4124})
        self.assertEqual(slow['choices']['compute_only']['predicted_ms'], 724)      # the policy's own objective
        self.assertEqual(slow['choices']['compute_network']['predicted_ms'], 970)
        self.assertFalse(any(c['tie'] for c in slow['choices'].values()))

    def test_no_hardcoded_preferred_node_mirrored_costs_mirror_the_choice(self):
        swap = {'GGG': 'NNN', 'NNN': 'GGG'}
        for table in (RELAY, SLOW):
            d, m = CP.decide(table), CP.decide(mirrored(table))
            for policy in ('compute_only', 'compute_network'):
                self.assertEqual(m['choices'][policy]['placement'], swap[d['choices'][policy]['placement']], policy)

    def test_exact_tie_is_flagged_not_hidden(self):
        tie = fixture((10, 10, 10), (10, 10, 10), (1, 1), (1, 1), 5, 5)
        d = CP.decide(tie)
        self.assertTrue(d['choices']['compute_only']['tie'] and d['choices']['compute_network']['tie'])
        self.assertFalse(d['choices']['fixed_gpu']['tie'])

    def test_missing_or_invalid_costs_fail_closed(self):
        cases = []
        for key in list(SLOW['proc']):
            cases.append(('missing proc '+str(key), dict(proc={k: v for k, v in SLOW['proc'].items() if k != key}, link=dict(SLOW['link']))))
        for key in list(SLOW['link']):
            cases.append(('missing link '+str(key), dict(proc=dict(SLOW['proc']), link={k: v for k, v in SLOW['link'].items() if k != key})))
        for bad in (None, 0, -1.0, math.nan, math.inf, True, '12', [1]):
            cases.append((f'proc {bad!r}', dict(proc={**SLOW['proc'], ('vlm', 'N'): bad}, link=dict(SLOW['link']))))
            cases.append((f'link {bad!r}', dict(proc=dict(SLOW['proc']), link={**SLOW['link'], ('S', 'G', 0): bad})))
        for name, table in cases:
            with self.assertRaises(CP.PolicyError, msg=name):
                CP.decide(table)
            for policy in D.POLICIES:  # every policy, the fixed references included, refuses an incomplete/invalid table
                with self.assertRaises(CP.PolicyError, msg=(name, policy)):
                    CP.select(policy, table)

    def test_raw_probe_medians_are_validated_before_conversion_ingestion_to_decision(self):
        probes = [dict(src=a, dst=b, edge=e, median_ms=v) for (a, b, e), v in SLOW['link'].items()]
        got = CP.decide(CP.table_from(SLOW['proc'], probes))  # standard int/float medians still work
        self.assertEqual({p: c['placement'] for p, c in got['choices'].items()},
                         dict(fixed_gpu='GGG', fixed_npu='NNN', compute_only='NNN', compute_network='GGG'))
        self.assertEqual(got['predicted_ms'], {'GGG': 970, 'NNN': 4124})
        for bad in (True, False, '1.0', '3400', None, math.nan, math.inf, 0, -1.0, b'1'):
            raw = [dict(p, median_ms=bad) if (p['src'], p['dst'], p['edge']) == ('S', 'N', 0) else p for p in probes]
            with self.assertRaises(CP.PolicyError, msg=repr(bad)):
                CP.decide(CP.table_from(SLOW['proc'], raw))

    def test_raw_profile_timings_are_validated_before_conversion_ingestion_to_decision(self):
        from test_chain_live import Qualification as Rows
        probes = [dict(src=a, dst=b, edge=e, median_ms=v) for (a, b, e), v in SLOW['link'].items()]
        ids, rows = Rows().rows()
        proc, _, problems = L.profile_table(rows, ids, 'gmp-q', NPY)
        self.assertEqual(problems, [])
        CP.decide(CP.table_from(proc, probes))  # standard finite positive numeric timings still work
        for bad in (True, '1.0', '10', None, math.nan, math.inf, 0, -1.0):
            raw = json.loads(json.dumps(rows))
            next(r for r in raw if (r['stage'], r['host'], r['warmup']) == ('vlm', 'N', False))['receipt']['worker_wall_ms'] = bad
            proc, _, problems = L.profile_table(raw, ids, 'gmp-q', NPY)
            self.assertTrue(any('worker_wall_ms' in p for p in problems), (bad, problems))
            self.assertNotIn(('vlm', 'N'), proc, repr(bad))
            with self.assertRaises(CP.PolicyError, msg=repr(bad)):
                CP.decide(CP.table_from(proc, probes))

    def test_alias_sharing_and_four_main_jobs_maximum(self):
        choices = {'relay': CP.aliases(CP.decide(RELAY)), 'npu_slow2': CP.aliases(CP.decide(SLOW))}
        self.assertEqual(choices['relay'], {'GGG': ['fixed_gpu'], 'NNN': ['compute_network', 'compute_only', 'fixed_npu']})
        self.assertEqual(choices['npu_slow2'], {'GGG': ['compute_network', 'fixed_gpu'], 'NNN': ['compute_only', 'fixed_npu']})
        cells = D.cells(choices)
        self.assertEqual(len(cells), 4)
        self.assertEqual(D.MAX_MAIN_JOBS, 4)
        self.assertEqual(sorted((c['regime'], c['placement']) for c in cells),
                         [('npu_slow2', 'GGG'), ('npu_slow2', 'NNN'), ('relay', 'GGG'), ('relay', 'NNN')])
        self.assertTrue(all(sorted(p for c in cells if c['regime'] == r for p in c['policies']) == sorted(D.POLICIES) for r in D.REGIMES))
        with self.assertRaisesRegex(ValueError, 'main jobs'):
            D.cells(choices, repeat_count=2)
        for argv in (['--plan', '--repeat-count', '2'], ['--plan', '--measurement-blocks', '2']):
            with self.assertRaisesRegex(SystemExit, 'repeat-count and measurement-blocks must be 1'):
                L.main(argv)


def make_run():
    run = L.Run(L.Session(tempfile.mkdtemp(), 'gmp-net'), L.DEFAULTS['frozen'], None, dict(design={}), http=mock.Mock())
    run.ips = {'S': '10.0.0.1', 'G': '10.0.0.2', 'N': '10.0.0.3'}
    return run


class Network(unittest.TestCase):

    @staticmethod
    def applied(spec):
        shaped = spec['mbps'] is not None
        summary = ([dict(handle=0x10000, parent=0xffffffff, kind='prio', bytes=0), dict(handle=0x100000, parent=0x10001, kind='tbf', bytes=0),
                    dict(handle=0x200000, parent=0x10002, kind='tbf', bytes=0)] if shaped else
                   [dict(handle=0, parent=0xffffffff, kind='noqueue', bytes=0)])
        return dict(spec=spec, netns='net:[4026532999]', qdisc_summary=summary, qdiscs=[], filters=[], routes=[], links=[])

    def test_same_relay_both_conditions_and_only_n_shaped(self):
        self.assertTrue(all(D.NETWORK[r]['relay'] for r in D.REGIMES))
        self.assertEqual((D.NETWORK['relay']['net']['mbps'], D.NETWORK['npu_slow2']['net']['mbps']), (None, 2))
        self.assertEqual(D.SHAPED_HOSTS, ('N',))
        run = make_run()
        with mock.patch.object(run, 'drain'), mock.patch.object(L.Session, 'net', side_effect=lambda spec, *a: self.applied(spec)) as net:
            run.apply_network('relay')
            run.apply_network('npu_slow2')
        specs = [c[0][0] for c in net.call_args_list]
        self.assertEqual([(s['cloud'], s['edge'], s['mbps'], s['action']) for s in specs],
                         [(['10.0.0.3'], [], None, 'shape'), (['10.0.0.3'], [], 2, 'shape')])
        saved = json.loads((run.s.out/'network-002-npu_slow2.json').read_text())
        self.assertEqual((saved['netns'], saved['problems']), ('net:[4026532999]', []))
        gen = CG.Generator()
        gen.config = dict(run_id='r', hosts={h: dict(url='http://'+h) for h in 'GN'}, gateway_url='http://gw', origin_url='http://s')
        for host in 'GN':  # both servers are reached from the source through the same owned gateway in both conditions
            self.assertEqual(gen.route('S', host, True), (f'http://gw/to/{host}/run', 'gateway'))
            self.assertEqual(gen.route(host, host, True), (f'http://{host}/run', 'direct'))

    def test_wrong_qdisc_state_is_refused(self):
        run = make_run()
        unshaped = lambda spec, *a: self.applied(dict(spec, mbps=None))
        with mock.patch.object(run, 'drain'), mock.patch.object(L.Session, 'net', side_effect=unshaped):
            with self.assertRaisesRegex(RuntimeError, 'network npu_slow2'):
                run.apply_network('npu_slow2')

    def test_probe_evidence_reports_actual_bytes_and_derived_application_throughput(self):
        evidence = CP.probe_evidence([dict(src='S', dst='N', edge=0, kind='npy', bytes=NPY, route='gateway', median_ms=3272.192)])
        row, = evidence
        self.assertEqual((row['bytes'], row['route']), (NPY, 'gateway'))
        self.assertAlmostEqual(row['effective_app_mbps'], NPY * 8 / 3.272192 / 1e6)
        self.assertIn('HTTP/relay', row['note'])
        self.assertNotIn('nominal', json.dumps({k: v for k, v in row.items() if k != 'note'}))


class Qualification(unittest.TestCase):
    @staticmethod
    def row(host, first='gateway', hops=('direct', 'direct'), status='ok'):
        return dict(status=status, first_route=first, first_payload_bytes=NPY,
                    receipts=[dict(pod_uid='u'+host)] * 3,
                    hops=[dict(src=host, dst=host, route=hops[0], payload_bytes=593966), dict(src=host, dst=host, route=hops[1], payload_bytes=700)])

    @staticmethod
    def gateway(**body_bytes):
        return dict(active=0, counters={k: dict(requests=1, request_body_bytes=v, response_body_bytes=900, errors=0, timeouts=0)
                                        for k, v in body_bytes.items()})

    @staticmethod
    def snap(shaped_bytes, shaped=True):
        if not shaped:
            return dict(qdisc_summary=[dict(handle=0, parent=0xffffffff, kind='noqueue', bytes=0)])
        return dict(qdisc_summary=[dict(handle=0x10000, parent=0xffffffff, kind='prio', bytes=shaped_bytes),
                                   dict(handle=0x100000, parent=0x10001, kind='tbf', bytes=shaped_bytes)])

    def test_colocated_routes_and_counters_qualify(self):
        for regime, host, after in (('relay', 'G', 0), ('relay', 'N', 0), ('npu_slow2', 'G', 0), ('npu_slow2', 'N', NPY + 4000)):
            shaped = regime == 'npu_slow2'
            got = L.route_problems(self.row(host), self.gateway(**{host: NPY + 200}), regime, host, self.snap(0, shaped), self.snap(after, shaped))
            self.assertEqual(got, [], (regime, host))

    def test_mixed_route_bypass_or_wrong_band_is_refused(self):
        bad = self.row('G')
        bad['hops'][0]['dst'] = 'N'
        cases = [
            ('mixed', bad, self.gateway(G=NPY + 200), 'G', 0, 'same-host'),
            ('bypass', self.row('G', first='direct'), self.gateway(), 'G', 0, 'first route'),
            ('relayed hop', self.row('N', hops=('gateway', 'direct')), self.gateway(N=NPY + 200), 'N', NPY + 4000, 'hop routes'),
            ('other server relayed', self.row('N'), self.gateway(N=NPY + 200, G=900), 'N', NPY + 4000, 'relayed to'),
            ('short counter', self.row('N'), self.gateway(N=100), 'N', NPY + 4000, 'does not show'),
            ('N unshaped', self.row('N'), self.gateway(N=NPY + 200), 'N', 0, 'shaped band'),
            ('G shaped', self.row('G'), self.gateway(G=NPY + 200), 'G', NPY + 4000, 'shaped band'),
        ]
        for name, row, gw, host, after, expect in cases:
            got = L.route_problems(row, gw, 'npu_slow2', host, self.snap(0), self.snap(after))
            self.assertTrue(any(expect in p for p in got), (name, got))

    def test_qualify_runs_ggg_and_nnn_only(self):
        run = make_run()
        seen = []

        def request(cell):
            seen.append(cell['placement'])
            run.last_gateway = self.gateway(**{cell['placement'][0]: NPY + 200})
            return dict(rows=[dict(self.row(cell['placement'][0]), index=0)])
        run.npy_bytes = NPY
        with mock.patch.object(run, 'request', side_effect=request), \
                mock.patch.object(L.Session, 'net', side_effect=lambda spec, stem, t: self.snap(0, shaped=False)):
            run.qualify_route('relay')
        self.assertEqual(seen, ['GGG', 'NNN'])
        saved = json.loads((run.s.out/'qualification-relay.json').read_text())
        self.assertTrue(saved['qualified'])
        self.assertEqual(sorted(saved['placements']), ['GGG', 'NNN'])


class Release(unittest.TestCase):
    def test_release_includes_all_execution_code(self):
        draft = L.release_draft(L.DEFAULTS['frozen'], None, D.REPEAT_COUNT, D.MEASUREMENT_BLOCKS)
        code = draft['code']
        for name in ('chain_design.py', 'chain_policy.py', 'chain_live.py', 'chain_generator.py', 'chain_stages.py', 'chain_worker.py'):
            self.assertIn('experiments/gpu-mobilint-placement/'+name, code)
        self.assertIn('experiments/gpu-mobilint-vlm/live.py', code)  # dynamically loaded G.live.__file__ (critical regression)
        for shipped, path in L.SHIPPED.items():
            self.assertIn(str(path.resolve().relative_to(L.ROOT)), code, shipped)
        self.assertEqual(draft['design']['policies'], list(D.POLICIES))
        self.assertEqual(draft['design']['placements'], ['GGG', 'NNN'])
        self.assertIsNone(draft['approved_by'])

    def test_analyzer_names_whole_server_decision_and_disables_significance(self):
        text = json.dumps(A.LIMITATIONS)
        self.assertIn('whole job', text)
        self.assertIn('not DAG', text)
        self.assertIsNone(D.PRIMARY)
        self.assertIsNone(D.SECONDARY)


if __name__ == '__main__':
    unittest.main()
