"""Collector safety without a cluster: pure plan, stale release refused before any kubectl, fail-closed stream guard,
UID-owned cleanup protection, foreign accelerator holders, drain barrier, fail-closed profile qualification (2026-10-29:
the two-flow/shared-bottleneck verdict test was removed with the two-flow check itself; whole-server scope).

Run (repo root):
  PYTHONPATH=experiments/gpu-mobilint-placement .scratch/gpu-mobilint-vlm-20261028/env/mblt-x86/bin/python -m unittest -v test_chain_live
"""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import chain_design as D
import chain_live as L

REAL_LOAD = L.G.load_prepared


def fast_load(*args, **kw):
    return REAL_LOAD(*args, **dict(kw, hash_tar=False))


def pod(name, node, labels, uid='u1'):
    return dict(metadata=dict(name=name, uid=uid, labels=labels), spec=dict(nodeName=node), status=dict(podIP='10.0.0.9'))


class Plan(unittest.TestCase):
    def test_plan_is_pure_and_bounded(self):
        out = io.StringIO()
        with mock.patch.object(L.G, 'load_prepared', fast_load), mock.patch.object(L.collect.Session, 'call', side_effect=AssertionError('kubectl')), \
                contextlib.redirect_stdout(out):
            L.main(['--plan'])
        items = {i['metadata']['name']: i for i in json.loads(out.getvalue())['manifests']}
        self.assertTrue(all(i['metadata']['labels']['experiment'] == D.EXPERIMENT for i in items.values()))
        cuda, npu = items['gmp-plan-cuda'], items['gmp-plan-mobilint']
        for worker, node in ((cuda, L.P.JETSON), (npu, L.P.SERVER)):
            env = {e['name']: e.get('value') for e in worker['spec']['containers'][0]['env']}
            self.assertEqual((env['WORKER_MODULE'], env['STAGES'], env['DAG_MAX_ACTIVE']), ('chain_worker', 'image_pack,vlm,result_format', '96'))
            self.assertEqual(worker['spec']['affinity']['nodeAffinity']['requiredDuringSchedulingIgnoredDuringExecution']['nodeSelectorTerms'][0]
                             ['matchFields'][0]['values'], [node])
            self.assertEqual(worker['spec']['activeDeadlineSeconds'], D.BUDGETS['campaign_s'])
        self.assertEqual(env['RECIPE'], 'mobilint-x86_64-cp311')
        self.assertFalse(any('persistentVolumeClaim' in v for v in cuda['spec']['volumes']))  # staged: non-prepared, no PVC
        gw = items['gmp-plan-gateway']['spec']['containers']
        self.assertEqual(gw[1]['securityContext']['capabilities'], {'drop': ['ALL'], 'add': ['NET_ADMIN']})
        self.assertFalse(gw[1]['securityContext']['allowPrivilegeEscalation'])
        self.assertTrue(all(not c['securityContext'].get('privileged') for i in items.values() if i['kind'] == 'Pod' for c in i['spec']['containers']))
        self.assertTrue(all('hostNetwork' not in i.get('spec', {}) for i in items.values()))
        self.assertEqual(items['gmp-plan-generator']['spec']['affinity']['nodeAffinity']['requiredDuringSchedulingIgnoredDuringExecution']
                         ['nodeSelectorTerms'][0]['matchFields'][0]['values'], [D.ORIGIN_NODE])
        code = items['gmp-plan-code']['data']
        self.assertTrue({'chain_worker.py', 'chain_stages.py', 'chain_generator.py', 'dag_worker.py', 'gateway.py', 'net_control.py',
                         'vlm_stage.py', 'vlm_bootstrap.py', 'bootstrap.py', 'worker.py'} <= set(code))


class Release(unittest.TestCase):
    def draft(self):
        return L.release_draft(L.DEFAULTS['frozen'], None, D.REPEAT_COUNT, D.MEASUREMENT_BLOCKS)  # staged: non-prepared

    def test_stale_release_fails_before_any_kubectl_and_fresh_one_dry_runs(self):
        draft = self.draft()
        tmp = Path(tempfile.mkdtemp())
        fresh = dict(draft, approved_by='coordinator-test')
        stale = json.loads(json.dumps(fresh))
        first = next(iter(stale['code']))
        stale['code'][first] = '0' * 64
        changed = json.loads(json.dumps(fresh))
        changed['design']['repeat_count'] = 2
        for name, value in (('stale.json', stale), ('changed.json', changed), ('fresh.json', fresh)):
            (tmp/name).write_text(json.dumps(value))
        kubectl = mock.Mock(side_effect=AssertionError('kubectl must not run'))
        with mock.patch.object(L.G, 'load_prepared', fast_load), mock.patch.object(L.collect.Session, 'call', kubectl):
            for name in ('stale.json', 'changed.json'):
                with self.assertRaisesRegex(SystemExit, 'no kubectl was run'):
                    L.main(['--release', str(tmp/name), '--runs', str(tmp/'runs')])
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                L.main(['--dry-run', '--release', str(tmp/'fresh.json')])
        kubectl.assert_not_called()
        self.assertFalse((tmp/'runs').exists())
        self.assertEqual(json.loads(out.getvalue())['release'], 'ok')
        self.assertIn('approved_by', ' '.join(L.release_problems(draft, draft)))


class Guard(unittest.TestCase):
    def setUp(self):
        self.s = L.Session(tempfile.mkdtemp(), 'gmp-guard')
        for key in ('cache', 'gateway', 'cuda', 'generator'):
            self.s.resources.append(dict(kind='Pod', name=f'gmp-guard-{key}', uid='u1', owned_labels=True))
        self.objects = {f'gmp-guard-{k}': pod(f'gmp-guard-{k}', L.NODE[k], L.meta('gmp-guard', '', k)['labels']) for k in L.NODE}

    def call(self, args):
        with mock.patch.object(L.collect.Session, 'call', return_value='{}') as real, \
                mock.patch.object(L.Session, 'pod_state', side_effect=lambda name: self.objects[name]):
            try:
                return self.s.call('t', args), real.called
            except RuntimeError as error:
                return str(error), real.called

    def test_edge_streams_never_reach_kubectl(self):
        for args in (['exec', '-i', '-n', L.NS, 'gmp-guard-cuda', '-c', 'worker', '--', 'sh'], ['logs', '-n', L.NS, 'gmp-guard-generator'],
                     ['port-forward', 'gmp-guard-cuda', '8080']):
            result, reached = self.call(args)
            self.assertFalse(reached, args)
        self.assertEqual(len(list(self.s.out.glob('*.refused.json'))) + len(list(self.s.out.glob('*.skipped.json'))), 3)

    def test_server_exec_only_owned_cache_and_netctl_after_fresh_get(self):
        ok = ['exec', '-i', '-n', L.NS, 'gmp-guard-gateway', '-c', 'netctl', '--', 'python3']
        self.assertEqual(self.call(ok), ('{}', True))
        self.assertEqual(self.call(['exec', '-i', '-n', L.NS, 'gmp-guard-cache', '-c', 'worker', '--', 'python3'])[1], True)
        self.assertFalse(self.call(['exec', '-i', '-n', L.NS, 'gmp-guard-gateway', '-c', 'worker', '--', 'sh'])[1])
        self.objects['gmp-guard-gateway']['spec']['nodeName'] = L.P.JETSON  # moved/replaced object: refused
        self.assertFalse(self.call(ok)[1])
        self.objects['gmp-guard-gateway']['spec']['nodeName'] = L.P.SERVER
        self.objects['gmp-guard-gateway']['metadata']['labels'] = dict(self.objects['gmp-guard-gateway']['metadata']['labels'], **{'run-id': 'other'})
        self.assertFalse(self.call(ok)[1])
        self.assertFalse(self.call(['exec', '-i', '-n', L.NS, 'foreign-pod', '-c', 'worker', '--', 'sh'])[1])

    def test_replaced_uid_refused_by_fresh_get(self):
        with mock.patch.object(L.collect.Session, 'call', return_value=json.dumps(pod('gmp-guard-cache', L.P.SERVER, {}, uid='other'))):
            with self.assertRaisesRegex(RuntimeError, 'replaced'):
                self.s.pod_state('gmp-guard-cache')


class Cleanup(unittest.TestCase):
    def test_uid_mismatch_and_unresolved_are_reported_never_adopted(self):
        s = L.Session(tempfile.mkdtemp(), 'gmp-clean')
        s.resources = [dict(kind='Pod', name='gmp-clean-cuda', uid='u1')]
        s.unresolved = [dict(kind='Pod', name='gmp-clean-gateway', stem='pods')]

        def refuse(_session, stem, args, stdin=None, timeout=60):
            s.counter += 1
            (s.out/f'{s.counter:04d}-{stem}.stderr').write_text('Precondition failed: UID in precondition: u1, UID in object meta: u2')
            raise RuntimeError('rc=1')
        with mock.patch.object(L.collect.Session, "call", autospec=True, side_effect=refuse):
            s.delete_owned('cleanup', ['gmp-clean-cuda'])
        self.assertEqual(s.resources[0]['delete'], 'refused-uid-mismatch')
        with mock.patch.object(L.Session, 'owned_present', return_value=False):
            problems = L.verify_cleanup(s)
        self.assertTrue(any('refused-uid-mismatch' in p for p in problems) and any('unresolved' in p for p in problems))

    def test_foreign_accelerator_holder_blocks_preflight(self):
        node = lambda name, res: dict(metadata=dict(name=name), spec={}, status=dict(conditions=[dict(type='Ready', status='True')],
                                                                                    allocatable={res: '1'}))
        nodes = [node(L.P.SERVER, 'mobilint.com/npu'), node(L.P.JETSON, 'nvidia.com/gpu')]
        foreign = dict(metadata=dict(namespace='other', name='x', uid='f', labels={}), spec=dict(nodeName=L.P.SERVER, containers=[
            dict(resources=dict(limits={'mobilint.com/npu': '1'}))]), status=dict(phase='Running'))
        self.assertEqual(L.G.preflight_problems(nodes, [], 'gmp-x'), [])
        self.assertIn('held by', ' '.join(L.G.preflight_problems(nodes, [foreign], 'gmp-x')))


class Drain(unittest.TestCase):
    def run_with(self, busy_polls, error=False):
        clock = [0.0]
        calls = dict(n=0, resets=[])
        s = L.Session(tempfile.mkdtemp(), 'gmp-drain')

        def http(url, body=None, timeout=None):
            if url.endswith('/reset'):
                calls['resets'].append(body['label'])
                return dict(label=body['label'], counters={})
            if url.endswith('/status'):
                return dict(busy=False)
            if url.endswith('/health'):
                return dict(active=0)
            calls['n'] += 1
            if error:
                raise TimeoutError('queue observation failed')
            busy = calls['n'] <= busy_polls
            return dict(waiting=0, active=int(busy), joins_open=0, inflight=int(busy), completed=5, dag_requests=5)
        run = L.Run(s, L.DEFAULTS['frozen'], None, dict(design=dict(repeat_count=1, measurement_blocks=1)), http=http,
                    clock=lambda: clock[0], sleep=lambda dt: clock.__setitem__(0, clock[0] + dt))
        run.urls = {'G': 'http://g', 'N': 'http://n', 'gateway': 'http://gw', 'generator': 'http://gen'}
        return run, calls, clock

    def test_drain_waits_for_stable_idle_then_resets_gateway(self):
        run, calls, clock = self.run_with(busy_polls=6)
        run.drain('before-x')
        self.assertEqual(calls['resets'], ['before-x'])
        self.assertGreaterEqual(clock[0], D.BUDGETS['settle_s'])

    def test_never_idle_or_unobservable_aborts(self):
        for kwargs in (dict(busy_polls=10**9), dict(busy_polls=0, error=True)):
            run, calls, clock = self.run_with(**kwargs)
            with self.assertRaisesRegex(RuntimeError, 'not drained'):
                run.drain('before-y')
            self.assertEqual(calls['resets'], [])
            self.assertGreaterEqual(clock[0], D.BUDGETS['drain_s'])


class Qualification(unittest.TestCase):
    def rows(self):
        ids = {h: dict(pod_uid=f'u{h}', node=f'n{h}', device=L.EXPECTED_DEVICE[h], model_sha256={'w': h}) for h in D.HOSTS}
        rows = []
        for host in D.HOSTS:
            for i in D.ALL_INPUTS:
                rows.append(self.row(ids, host, 'image_pack', 'roundtrip', False, f'rt-{host}-{i}', dict(roundtrip_identical=True), 593966, i))
            for stage, size in (('image_pack', 593966), ('vlm', 700), ('result_format', 300)):
                for warm in (True, False):
                    timing = dict(roundtrip_identical=True) if stage == 'image_pack' else dict(input_id=D.INPUT) if stage == 'vlm' else {}
                    rows.append(self.row(ids, host, stage, 'profile', warm, f'p-{host}-{stage}-{warm}', timing, size, D.INPUT))
        return ids, rows

    @staticmethod
    def row(ids, host, stage, purpose, warm, rid, timing, size, input_id):
        receipt = dict(pod_uid=ids[host]['pod_uid'], node=ids[host]['node'], run_id='gmp-q', request_id=rid, stage=stage,
                       device=ids[host]['device'] if stage == 'vlm' else 'host-cpu', input_sha256='i', output_sha256='o',
                       model_sha256=ids[host]['model_sha256'] if stage == 'vlm' else None, worker_wall_ms=100.0 if warm else 10.0, timing=timing)
        return dict(stage=stage, host=host, input_id=input_id, purpose=purpose, warmup=warm, request_id=rid, status='ok', receipt=receipt,
                    input_sha256='i', output_sha256='o', output_bytes=size)

    def test_profile_table_excludes_warmup_and_fails_closed(self):
        ids, rows = self.rows()
        proc, sizes, problems = L.profile_table(rows, ids, 'gmp-q', 818048)
        self.assertEqual(problems, [])
        self.assertEqual(proc[('vlm', 'G')], 10.0)  # warm-up (100 ms) excluded
        self.assertEqual(sizes, dict(npy=818048, png={'G': 593966, 'N': 593966}, vlm={'G': 700, 'N': 700}, final={'G': 300, 'N': 300}))
        bad = json.loads(json.dumps(rows))
        next(r for r in bad if r['stage'] == 'vlm' and r['host'] == 'N')['receipt']['device'] = 'cpu'
        bad = [r for r in bad if not (r['purpose'] == 'roundtrip' and r['input_id'] == 'cal-4556100' and r['host'] == 'G')]
        _, _, problems = L.profile_table(bad, ids, 'gmp-q', 818048)
        self.assertTrue(any("['device']" in p for p in problems) and any('cal-4556100@G: roundtrip missing' in p for p in problems))



if __name__ == '__main__':
    unittest.main()
