"""Whole-server selection policies for the sensor job, one frozen cost table per network condition (stdlib only).

Decision unit: the WHOLE job (image_pack -> vlm -> result_format) on one server, GGG or NNN. Never a mixed/split placement and
never DAG placement; the three stage costs are summed only to price one colocated server.
Cost table (measured in the calibration phase, frozen before any evaluation request):
  proc[(stage, host)]      closed-loop stage processing time (worker receipt worker_wall_ms, no queue; warm-up excluded)
  link[(S, host, 0)]       source -> server: median application-path probe RTT of a size-matched SYNTHETIC payload (random
                           bytes, the raw NPY's byte count; not the sensor content) from the source's network position over the
                           condition's route (the owned gateway) to a sink on the server; HTTP/relay overhead included: an
                           application path cost, never a pure network time. Main jobs always send the frozen sensor input.
  link[(host, host, 1|2)]  same-host local stage HTTP (PNG, VLM JSON) on that server; part of the server's processing cost.
  There is no inter-server link: a probe/key between G and N is refused.
  processing(h) = T1(h) + local(h,1) + T2(h) + local(h,2) + T3(h);   network(h) = link(S, h, 0).
The final answer returns as the nested reply (small-response approximation; not separately modeled).
Policies (honest baselines; choosing between two servers is not a new algorithm):
  fixed_gpu        GGG: a fixed GPU-first rule over the resource-eligible servers (both verified at preflight). Never the
                   actual kube-scheduler.
  fixed_npu        NNN reference.
  compute_only     argmin processing(h).
  compute_network  argmin processing(h) + network(h).
Every policy validates the whole table first: a missing, non-numeric, non-finite or non-positive cost fails closed.
Exact ties resolve in chain_design.HOSTS order (G before N) and are flagged (tie=True), never hidden. Predicted costs are
selection inputs, never results.
"""
import math
import time

import chain_design as D


class PolicyError(RuntimeError):
    pass


def is_measurement(value):
    """A raw measured ms is a finite positive int/float; bool, numeric strings and anything else are refused (check BEFORE
    any float() conversion, which would turn True or '1.0' into a valid-looking 1.0)."""
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value) and value > 0


def _cost(table, kind, key):
    try:
        value = table[kind][key]
    except (KeyError, TypeError):
        raise PolicyError(f'cost table lacks {kind}{key!r}') from None
    if not is_measurement(value):
        raise PolicyError(f'cost {kind}{key!r}={value!r} is not a finite positive measurement')
    return value


def _host(placement):
    try:
        return D.host_of(placement)
    except ValueError as error:
        raise PolicyError(str(error)) from None


def parts(table, placement):
    """Per-leg predicted costs of one whole-server placement: [(name, ms)] in execution order."""
    h = _host(placement)
    return [('S->T1', _cost(table, 'link', (D.ORIGIN, h, 0))), ('T1', _cost(table, 'proc', ('image_pack', h))),
            ('T1->T2', _cost(table, 'link', (h, h, 1))), ('T2', _cost(table, 'proc', ('vlm', h))),
            ('T2->T3', _cost(table, 'link', (h, h, 2))), ('T3', _cost(table, 'proc', ('result_format', h)))]


def network(table, placement):
    return parts(table, placement)[0][1]


def processing(table, placement):
    return sum(ms for _, ms in parts(table, placement)[1:])


def total(table, placement):
    return sum(ms for _, ms in parts(table, placement))


def validate(table):
    for placement in D.PLACEMENTS:
        parts(table, placement)


def _argmin(score):
    """-> (placement, tie): first minimum in PLACEMENTS (HOSTS) order; tie says another placement had the same score."""
    scores = [(score(p), p) for p in D.PLACEMENTS]
    best = min(v for v, _ in scores)
    winners = [p for v, p in scores if v == best]
    return winners[0], len(winners) > 1


OBJECTIVE = dict(fixed_gpu=total, fixed_npu=total, compute_only=processing, compute_network=total)


def choose(policy, table):
    """-> (placement, tie) after validating the whole table."""
    validate(table)
    if policy == 'fixed_gpu':
        return 'GGG', False
    if policy == 'fixed_npu':
        return 'NNN', False
    if policy == 'compute_only':
        return _argmin(lambda p: processing(table, p))
    if policy == 'compute_network':
        return _argmin(lambda p: total(table, p))
    raise PolicyError(f'unknown policy {policy!r}')


def select(policy, table):
    return choose(policy, table)[0]


def decide(table):
    """Every policy's frozen choice for one table: placement, the policy's own objective value (predicted_ms), the
    processing/network split, a tie flag and selection time; plus each placement's processing/network/total and legs."""
    started = time.perf_counter()
    validate(table)
    choices = {}
    for policy in D.POLICIES:
        t0 = time.perf_counter()
        placement, tie = choose(policy, table)
        _host(placement)  # the policy/schedule boundary: never a mixed placement
        choices[policy] = dict(placement=placement, predicted_ms=OBJECTIVE[policy](table, placement), tie=tie,
                               processing_ms=processing(table, placement), network_ms=network(table, placement),
                               selection_ms=(time.perf_counter()-t0)*1000)
    return dict(choices=choices, predicted_ms={p: total(table, p) for p in D.PLACEMENTS},
                processing_ms={p: processing(table, p) for p in D.PLACEMENTS}, network_ms={p: network(table, p) for p in D.PLACEMENTS},
                parts={p: parts(table, p) for p in D.PLACEMENTS}, decision_unit='whole job on one server; not DAG placement',
                decide_ms=(time.perf_counter()-started)*1000)


def aliases(decision):
    """{placement: [policy labels]}: one executed plan per distinct placement (alias labels share one observation)."""
    out = {}
    for policy, choice in decision['choices'].items():
        out.setdefault(choice['placement'], []).append(policy)
    return {p: sorted(labels) for p, labels in out.items()}


def required_probes(sizes):
    """sizes = {'npy': n, 'png': {G: n, N: n}, 'vlm': {G: n, N: n}} (measured task payload bytes) -> the 6 probes the two
    whole-server placements read: source -> each server (raw NPY) and each server's own local stage HTTP (its PNG, its VLM
    JSON). No inter-server probe. [dict(src, dst, edge, kind, bytes)]"""
    out = [dict(src=D.ORIGIN, dst=h, edge=0, kind='npy', bytes=int(sizes['npy'])) for h in D.HOSTS]
    for edge, kind in ((1, 'png'), (2, 'vlm')):
        out += [dict(src=h, dst=h, edge=edge, kind=kind, bytes=int(sizes[kind][h])) for h in D.HOSTS]
    return out


def table_from(proc, probes):
    """proc {(stage, host): ms}; probes [dict(src, dst, edge, median_ms)] -> cost table (tuple keys). Inter-server probes and
    a raw median that is not a finite positive measurement are refused before conversion."""
    for p in probes:
        if p['src'] != D.ORIGIN and p['src'] != p['dst']:
            raise PolicyError(f"inter-server probe {p['src']}->{p['dst']} refused: the whole job runs on one server")
        if not is_measurement(p.get('median_ms')):
            raise PolicyError(f"probe {p['src']}->{p['dst']}#{p['edge']} median_ms={p.get('median_ms')!r} is not a finite positive measurement")
    return dict(proc=dict(proc), link={(p['src'], p['dst'], p['edge']): float(p['median_ms']) for p in probes})


def probe_evidence(probes):
    """Actual probe bytes and RTT per route; effective_app_mbps is DERIVED (bytes*8 / median RTT) and includes HTTP/relay
    processing and the small sink reply: an application-path figure, never the configured shaping rate or a link capacity."""
    out = []
    for p in probes:
        ms = p.get('median_ms')
        out.append(dict(src=p['src'], dst=p['dst'], edge=p['edge'], kind=p.get('kind'), bytes=p['bytes'], route=p.get('route'), median_ms=ms,
                        effective_app_mbps=p['bytes'] * 8 / (ms / 1000) / 1e6 if ms else None,
                        note='derived from actual size-matched synthetic probe bytes / probe RTT incl. HTTP/relay processing; not a link capacity'))
    return out


def table_to_json(table):
    return dict(proc={f'{s}@{h}': v for (s, h), v in table['proc'].items()},
                link={f'{a}->{b}#{e}': v for (a, b, e), v in table['link'].items()})
